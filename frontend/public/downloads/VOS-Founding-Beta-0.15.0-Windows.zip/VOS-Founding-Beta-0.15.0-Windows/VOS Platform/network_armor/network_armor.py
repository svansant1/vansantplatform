"""VOS Network Armor posture agent. This baseline is visibility, not a VPN."""

from __future__ import annotations

import argparse
import ctypes
import json
import os
import subprocess
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
CONFIG_PATH = ROOT / "config" / "network_armor.json"
STATE_PATH = ROOT / "runtime" / "network_armor_state.json"
PID_PATH = ROOT / "runtime" / "network_armor.pid"
MODULE_ID = "network-armor"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2), encoding="utf-8")
    temp.replace(path)


class GuardianApi:
    def __init__(self) -> None:
        self.base_url = os.environ.get("VOS_GUARDIAN_URL", "http://127.0.0.1:8765").rstrip("/")
        self.token = os.environ.get("VOS_GUARDIAN_TOKEN", "")

    def request(self, method: str, path: str, payload: dict[str, Any] | None = None) -> Any:
        data = None if payload is None else json.dumps(payload).encode()
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        request = urllib.request.Request(self.base_url + path, data=data, headers=headers, method=method)
        with urllib.request.urlopen(request, timeout=5) as response:
            body = response.read().decode()
            return json.loads(body) if body else {}

    def heartbeat(self, state: str, details: dict[str, Any]) -> None:
        self.request("POST", f"/v1/modules/{MODULE_ID}/heartbeat", {"version": "0.13.1", "state": state, "details": details})

    def evidence(self, severity: str, summary: str, details: dict[str, Any]) -> None:
        self.request("POST", "/v1/evidence", {"module_id": MODULE_ID, "severity": severity, "kind": "network-posture", "summary": summary, "details": details})

    def commands(self) -> list[dict[str, Any]]:
        return self.request("GET", f"/v1/modules/{MODULE_ID}/commands?status=queued").get("commands", [])

    def complete(self, command_id: str, status: str, result: dict[str, Any]) -> None:
        severity = "info" if status == "completed" else "medium"
        self.request("POST", "/v1/evidence", {
            "module_id": MODULE_ID, "severity": severity, "kind": f"command-{status}",
            "summary": f"Network Armor command {status}", "details": {"command_id": command_id, "result": result},
        })


def powershell_json(script: str) -> Any:
    completed = subprocess.run(
        ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
        capture_output=True, text=True, timeout=20, check=False,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if completed.returncode:
        raise RuntimeError(completed.stderr.strip() or "PowerShell network query failed")
    return json.loads(completed.stdout.strip() or "{}")


def capture_snapshot() -> dict[str, Any]:
    script = r"""
$fw = @(Get-NetFirewallProfile -ErrorAction SilentlyContinue | Select-Object Name,Enabled)
$dns = @(Get-DnsClientServerAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object {$_.ServerAddresses.Count -gt 0} | Select-Object InterfaceAlias,ServerAddresses)
$connections = @(Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue)
$byProcess = @($connections | Group-Object OwningProcess | ForEach-Object {
  $processName='unknown'; try {$processName=(Get-Process -Id ([int]$_.Name) -ErrorAction Stop).ProcessName} catch {}
  [pscustomobject]@{process=$processName;connection_count=$_.Count}
} | Sort-Object connection_count -Descending | Select-Object -First 20)
[pscustomobject]@{firewall_profiles=$fw;dns_interfaces=$dns;established_connection_count=$connections.Count;connection_processes=$byProcess} | ConvertTo-Json -Depth 6 -Compress
"""
    try:
        snapshot = powershell_json(script)
        snapshot.update({"captured_at": utc_now(), "remote_destinations_recorded": False})
        return snapshot
    except Exception as exc:
        return {"captured_at": utc_now(), "error": str(exc), "firewall_profiles": [], "dns_interfaces": [], "established_connection_count": None, "connection_processes": [], "remote_destinations_recorded": False}


def posture(snapshot: dict[str, Any]) -> tuple[str, str]:
    if snapshot.get("error"):
        return "medium", "Network posture collection failed"
    disabled = [item.get("Name", "Unknown") for item in snapshot.get("firewall_profiles", []) if not item.get("Enabled")]
    if disabled:
        return "high", "Windows Firewall disabled for: " + ", ".join(disabled)
    if not snapshot.get("dns_interfaces"):
        return "medium", "No active IPv4 DNS configuration was detected"
    return "info", "Network posture snapshot completed"


def process_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
    if not handle:
        return False
    ctypes.windll.kernel32.CloseHandle(handle)
    return True


def claim_instance() -> bool:
    try:
        existing = int(PID_PATH.read_text(encoding="utf-8").strip())
        if existing != os.getpid() and process_alive(existing):
            return False
    except (OSError, ValueError):
        pass
    PID_PATH.parent.mkdir(parents=True, exist_ok=True)
    PID_PATH.write_text(str(os.getpid()), encoding="utf-8")
    return True


def release_instance() -> None:
    try:
        if int(PID_PATH.read_text(encoding="utf-8").strip()) == os.getpid():
            PID_PATH.unlink(missing_ok=True)
    except (OSError, ValueError):
        pass


class NetworkArmor:
    def __init__(self) -> None:
        self.api = GuardianApi()
        self.config = read_json(CONFIG_PATH, {})
        self.state = read_json(STATE_PATH, {"emergency_bypass": False})

    def status(self, snapshot: dict[str, Any] | None = None) -> dict[str, Any]:
        snapshot = snapshot or self.state.get("last_snapshot", {})
        tunnel = self.config.get("tunnel", {})
        return {
            "consent_accepted": bool(self.config.get("consent", {}).get("accepted")),
            "monitoring_enabled": bool(self.config.get("monitoring_enabled", True)),
            "emergency_bypass": bool(self.state.get("emergency_bypass", False)),
            "tunnel_provider": tunnel.get("provider", "not-configured"),
            "tunnel_connected": False,
            "protective_dns_mode": self.config.get("protective_dns", {}).get("mode", "observe-only"),
            "retention_hours": self.config.get("retention_hours", 24),
            "firewall_profiles": snapshot.get("firewall_profiles", []),
            "dns_interface_count": len(snapshot.get("dns_interfaces", [])),
            "established_connection_count": snapshot.get("established_connection_count"),
            "remote_destinations_recorded": False,
        }

    def save(self, snapshot: dict[str, Any] | None = None) -> None:
        if snapshot is not None:
            self.state["last_snapshot"] = snapshot
        self.state.update({"updated_at": utc_now(), "status": self.status(snapshot)})
        write_json(STATE_PATH, self.state)

    def publish_snapshot(self) -> dict[str, Any]:
        snapshot = capture_snapshot()
        severity, summary = posture(snapshot)
        self.save(snapshot)
        details = self.status(snapshot)
        details["connection_processes"] = snapshot.get("connection_processes", [])
        self.api.evidence(severity, summary, details)
        return {"summary": summary, "severity": severity, "status": details}

    def handle(self, item: dict[str, Any]) -> dict[str, Any]:
        action = item.get("action")
        if action == "report-status":
            return {"status": self.status(), "note": "Consent is required before a network snapshot." if not self.status()["consent_accepted"] else "Monitoring active."}
        if action == "network-snapshot":
            if not self.status()["consent_accepted"]:
                raise PermissionError("Network monitoring consent has not been accepted in VOS Desktop.")
            return self.publish_snapshot()
        if action == "emergency-bypass":
            self.state["emergency_bypass"] = True
            self.save()
            self.api.evidence("medium", "Network Armor emergency bypass enabled", self.status())
            return {"emergency_bypass": True, "note": "No tunnel was active; monitoring remains visible."}
        if action == "resume-monitoring":
            self.state["emergency_bypass"] = False
            self.save()
            self.api.evidence("info", "Network Armor monitoring resumed", self.status())
            return {"emergency_bypass": False}
        raise ValueError(f"Unsupported command: {action}")

    def run_once(self) -> dict[str, Any]:
        if not self.status()["consent_accepted"]:
            self.save()
            self.api.heartbeat("consent-required", self.status())
            return {"summary": "Consent required", "status": self.status()}
        result = self.publish_snapshot()
        self.api.heartbeat("monitoring-not-tunneled", self.status())
        return result

    def run(self) -> None:
        heartbeat_at = snapshot_at = 0.0
        while True:
            now = time.monotonic()
            try:
                current = self.status()
                if now - heartbeat_at >= 10:
                    state = "consent-required" if not current["consent_accepted"] else ("bypassed" if current["emergency_bypass"] else "monitoring-not-tunneled")
                    self.api.heartbeat(state, current); heartbeat_at = now
                if current["consent_accepted"] and not current["emergency_bypass"] and now - snapshot_at >= 300:
                    self.publish_snapshot(); snapshot_at = now
                for item in self.api.commands():
                    try:
                        self.api.complete(item["id"], "completed", self.handle(item))
                    except Exception as exc:
                        self.api.complete(item.get("id", "unknown"), "failed", {"error": str(exc)})
            except (urllib.error.URLError, TimeoutError):
                pass
            time.sleep(3)


def main() -> int:
    parser = argparse.ArgumentParser(description="VOS Network Armor posture agent")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    agent = NetworkArmor()
    if args.check:
        print(json.dumps(agent.run_once(), indent=2)); return 0
    if not claim_instance():
        print("Network Armor is already running.")
        return 0
    try:
        agent.run()
    except KeyboardInterrupt:
        pass
    finally:
        release_instance()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
