#!/usr/bin/env python3
"""VOS Guardian Core: local module coordination and evidence runtime."""

from __future__ import annotations

import argparse
import json
import logging
import re
import secrets
import threading
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlsplit

VERSION = "0.13.1"
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8765
HEARTBEAT_STALE_SECONDS = 20

CORE_DIR = Path(__file__).resolve().parent
IDENTITY_ROOT = CORE_DIR.parents[1]
CONFIG_PATH = IDENTITY_ROOT / "config" / "modules.json"
RUNTIME_DIR = IDENTITY_ROOT / "runtime"
TOKEN_PATH = RUNTIME_DIR / "guardian.token"
PID_PATH = RUNTIME_DIR / "guardian.pid"
LOG_PATH = RUNTIME_DIR / "guardian.log"
EVIDENCE_PATH = RUNTIME_DIR / "evidence.jsonl"
STATE_PATH = RUNTIME_DIR / "state.json"
INCIDENTS_PATH = RUNTIME_DIR / "incidents.json"
ACTIONS_PATH = RUNTIME_DIR / "actions.jsonl"

SEVERITY_RANK = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_registry(path: Path = CONFIG_PATH) -> list[dict[str, Any]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    modules = payload.get("modules")
    if not isinstance(modules, list):
        raise ValueError("Module registry must contain a modules list")
    seen: set[str] = set()
    result: list[dict[str, Any]] = []
    for item in modules:
        module_id = str(item.get("id", "")).strip()
        if not module_id or module_id in seen or not re.fullmatch(r"[a-z0-9-]+", module_id):
            raise ValueError(f"Invalid or duplicate module id: {module_id!r}")
        seen.add(module_id)
        result.append(dict(item))
    return result


def ensure_token() -> str:
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    if TOKEN_PATH.exists():
        token = TOKEN_PATH.read_text(encoding="utf-8").strip()
        if token:
            return token
    token = secrets.token_urlsafe(32)
    TOKEN_PATH.write_text(token, encoding="utf-8")
    return token


class GuardianState:
    def __init__(self, registry_path: Path = CONFIG_PATH) -> None:
        self.started_at = utc_now()
        self.lock = threading.RLock()
        self.modules = {item["id"]: item for item in load_registry(registry_path)}
        self.heartbeats: dict[str, dict[str, Any]] = {}
        self.commands: dict[str, list[dict[str, Any]]] = {key: [] for key in self.modules}
        self.evidence: list[dict[str, Any]] = self._load_jsonl(EVIDENCE_PATH, 2000)
        self.evidence_count = len(self.evidence)
        self.incidents: list[dict[str, Any]] = self._load_incidents()
        self.actions: list[dict[str, Any]] = self._load_jsonl(ACTIONS_PATH, 1000)

    def module_snapshot(self) -> list[dict[str, Any]]:
        now = datetime.now(timezone.utc)
        snapshots: list[dict[str, Any]] = []
        with self.lock:
            for module_id, definition in self.modules.items():
                heartbeat = self.heartbeats.get(module_id)
                status = "available"
                age_seconds = None
                if heartbeat:
                    observed = datetime.fromisoformat(heartbeat["observed_at"])
                    age_seconds = max(0, int((now - observed).total_seconds()))
                    status = "online" if age_seconds <= HEARTBEAT_STALE_SECONDS else "offline"
                snapshots.append({
                    **definition,
                    "status": status,
                    "last_heartbeat": heartbeat,
                    "heartbeat_age_seconds": age_seconds,
                    "pending_commands": len(self.commands.get(module_id, [])),
                })
        return snapshots

    def heartbeat(self, module_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        if module_id not in self.modules:
            raise KeyError(module_id)
        record = {
            "observed_at": utc_now(),
            "version": str(payload.get("version", "unknown"))[:80],
            "state": str(payload.get("state", "running"))[:80],
            "details": payload.get("details") if isinstance(payload.get("details"), dict) else {},
        }
        with self.lock:
            self.heartbeats[module_id] = record
            self._save_state()
        return record

    def add_command(self, module_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        if module_id not in self.modules:
            raise KeyError(module_id)
        action = str(payload.get("action", "")).strip()[:80]
        if not action:
            raise ValueError("Command action is required")
        command = {
            "id": secrets.token_hex(8),
            "module_id": module_id,
            "action": action,
            "payload": payload.get("payload") if isinstance(payload.get("payload"), dict) else {},
            "created_at": utc_now(),
        }
        with self.lock:
            self.commands[module_id].append(command)
        return command

    def take_commands(self, module_id: str) -> list[dict[str, Any]]:
        if module_id not in self.modules:
            raise KeyError(module_id)
        with self.lock:
            commands = list(self.commands[module_id])
            self.commands[module_id].clear()
        return commands

    def add_evidence(self, payload: dict[str, Any]) -> dict[str, Any]:
        module_id = str(payload.get("module_id", "")).strip()
        if module_id not in self.modules:
            raise KeyError(module_id)
        severity = str(payload.get("severity", "info")).lower()
        if severity not in {"info", "low", "medium", "high", "critical"}:
            raise ValueError("Invalid evidence severity")
        record = {
            "id": secrets.token_hex(12),
            "observed_at": utc_now(),
            "module_id": module_id,
            "kind": str(payload.get("kind", "operational"))[:80],
            "severity": severity,
            "summary": str(payload.get("summary", ""))[:500],
            "details": payload.get("details") if isinstance(payload.get("details"), dict) else {},
        }
        if not record["summary"]:
            raise ValueError("Evidence summary is required")
        with self.lock:
            with EVIDENCE_PATH.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(record, separators=(",", ":")) + "\n")
            self.evidence.append(record)
            if len(self.evidence) > 2000:
                self.evidence = self.evidence[-2000:]
            self.evidence_count += 1
            incident = self._correlate_incident(record)
            if incident:
                record["incident_id"] = incident["id"]
        return record

    def list_evidence(self, *, limit: int = 100, module_id: str = "", severity: str = "") -> list[dict[str, Any]]:
        with self.lock:
            records = self.evidence
            if module_id:
                records = [item for item in records if item.get("module_id") == module_id]
            if severity:
                minimum = SEVERITY_RANK.get(severity, 0)
                records = [item for item in records if SEVERITY_RANK.get(str(item.get("severity")), 0) >= minimum]
            return [dict(item) for item in reversed(records[-max(1, min(limit, 500)):])]

    def list_incidents(self, *, status: str = "", limit: int = 100) -> list[dict[str, Any]]:
        with self.lock:
            incidents = self.incidents
            if status:
                incidents = [item for item in incidents if item.get("status") == status]
            return [dict(item) for item in reversed(incidents[-max(1, min(limit, 500)):])]

    def list_actions(self, *, limit: int = 100) -> list[dict[str, Any]]:
        with self.lock:
            return [dict(item) for item in reversed(self.actions[-max(1, min(limit, 500)):])]

    def apply_incident_action(self, incident_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        action_name = str(payload.get("action", "")).strip().lower()[:80]
        allowed = {
            "acknowledge", "resolve", "dismiss", "request-status",
            "ask-guide", "run-diagnostic", "rescan-files",
        }
        if action_name not in allowed:
            raise ValueError("Unsupported incident action")
        with self.lock:
            incident = next((item for item in self.incidents if item.get("id") == incident_id), None)
            if not incident:
                raise KeyError(incident_id)
            if action_name == "acknowledge":
                incident["status"] = "acknowledged"
            elif action_name in {"resolve", "dismiss"}:
                incident["status"] = "dismissed" if action_name == "dismiss" else "resolved"
            elif action_name == "request-status":
                self.add_command(str(incident["module_id"]), {"action": "report-status"})
            elif action_name == "ask-guide":
                self.add_command("svansai-guide", {
                    "action": "explain-incident",
                    "payload": self._safe_incident_payload(incident),
                })
            elif action_name == "run-diagnostic":
                self.add_command("debugger-guide", {
                    "action": "scan-network",
                    "payload": {"incident_id": incident_id},
                })
            elif action_name == "rescan-files":
                self.add_command("file-armor", {
                    "action": "quick-scan",
                    "payload": {"incident_id": incident_id},
                })
            incident["updated_at"] = utc_now()
            action = {
                "id": secrets.token_hex(10),
                "incident_id": incident_id,
                "action": action_name,
                "created_at": utc_now(),
                "result": "queued" if action_name.startswith(("request", "ask", "run", "rescan")) else "applied",
            }
            incident.setdefault("actions", []).append(action["id"])
            self.actions.append(action)
            with ACTIONS_PATH.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(action, separators=(",", ":")) + "\n")
            self._save_incidents()
            return {"action": action, "incident": dict(incident)}

    def _correlate_incident(self, evidence: dict[str, Any]) -> dict[str, Any] | None:
        if SEVERITY_RANK.get(str(evidence.get("severity")), 0) < SEVERITY_RANK["medium"]:
            return None
        key = f"{evidence['module_id']}:{evidence['kind']}"
        incident = next(
            (item for item in reversed(self.incidents) if item.get("correlation_key") == key and item.get("status") in {"open", "acknowledged"}),
            None,
        )
        if incident:
            incident["updated_at"] = evidence["observed_at"]
            incident["severity"] = max(
                (str(incident.get("severity", "info")), str(evidence["severity"])),
                key=lambda value: SEVERITY_RANK.get(value, 0),
            )
            incident["summary"] = evidence["summary"]
            incident.setdefault("evidence_ids", []).append(evidence["id"])
        else:
            incident = {
                "id": "inc-" + secrets.token_hex(8),
                "correlation_key": key,
                "module_id": evidence["module_id"],
                "kind": evidence["kind"],
                "severity": evidence["severity"],
                "status": "open",
                "summary": evidence["summary"],
                "created_at": evidence["observed_at"],
                "updated_at": evidence["observed_at"],
                "evidence_ids": [evidence["id"]],
                "actions": [],
            }
            self.incidents.append(incident)
        self._save_incidents()
        return incident

    @staticmethod
    def _safe_incident_payload(incident: dict[str, Any]) -> dict[str, Any]:
        return {
            "incident_id": incident.get("id"),
            "module_id": incident.get("module_id"),
            "kind": incident.get("kind"),
            "severity": incident.get("severity"),
            "summary": incident.get("summary"),
            "created_at": incident.get("created_at"),
        }

    @staticmethod
    def _load_jsonl(path: Path, limit: int) -> list[dict[str, Any]]:
        if not path.exists():
            return []
        records: list[dict[str, Any]] = []
        for line in path.read_text(encoding="utf-8").splitlines()[-limit:]:
            try:
                item = json.loads(line)
                if isinstance(item, dict):
                    records.append(item)
            except json.JSONDecodeError:
                continue
        return records

    @staticmethod
    def _load_incidents() -> list[dict[str, Any]]:
        if not INCIDENTS_PATH.exists():
            return []
        try:
            payload = json.loads(INCIDENTS_PATH.read_text(encoding="utf-8"))
            return payload if isinstance(payload, list) else []
        except (OSError, json.JSONDecodeError):
            return []

    def _save_incidents(self) -> None:
        temporary = INCIDENTS_PATH.with_suffix(".tmp")
        temporary.write_text(json.dumps(self.incidents, indent=2), encoding="utf-8")
        temporary.replace(INCIDENTS_PATH)

    def _save_state(self) -> None:
        state = {"updated_at": utc_now(), "heartbeats": self.heartbeats}
        temporary = STATE_PATH.with_suffix(".tmp")
        temporary.write_text(json.dumps(state, indent=2), encoding="utf-8")
        temporary.replace(STATE_PATH)


class GuardianServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address: tuple[str, int], token: str, state: GuardianState):
        super().__init__(address, GuardianHandler)
        self.token = token
        self.state = state


class GuardianHandler(BaseHTTPRequestHandler):
    server: GuardianServer

    def log_message(self, format: str, *args: Any) -> None:
        logging.info("%s - %s", self.client_address[0], format % args)

    def _json(self, status: int, payload: dict[str, Any] | list[Any]) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _authenticated(self) -> bool:
        supplied = self.headers.get("Authorization", "")
        expected = f"Bearer {self.server.token}"
        return secrets.compare_digest(supplied, expected)

    def _require_auth(self) -> bool:
        if self._authenticated():
            return True
        self._json(HTTPStatus.UNAUTHORIZED, {"ok": False, "error": "Authentication required"})
        return False

    def _body(self) -> dict[str, Any]:
        length = min(int(self.headers.get("Content-Length", "0") or 0), 1_000_000)
        if not length:
            return {}
        payload = json.loads(self.rfile.read(length).decode("utf-8"))
        if not isinstance(payload, dict):
            raise ValueError("JSON object required")
        return payload

    def do_GET(self) -> None:
        parsed = urlsplit(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        if path == "/v1/health":
            self._json(HTTPStatus.OK, {
                "ok": True,
                "service": "VOS Guardian Core",
                "version": VERSION,
                "started_at": self.server.state.started_at,
            })
            return
        if not self._require_auth():
            return
        if path == "/v1/modules":
            self._json(HTTPStatus.OK, {"ok": True, "modules": self.server.state.module_snapshot()})
            return
        if path == "/v1/evidence":
            records = self.server.state.list_evidence(
                limit=int(query.get("limit", ["100"])[0]),
                module_id=str(query.get("module_id", [""])[0]),
                severity=str(query.get("severity", [""])[0]),
            )
            self._json(HTTPStatus.OK, {"ok": True, "evidence": records})
            return
        if path == "/v1/incidents":
            records = self.server.state.list_incidents(
                status=str(query.get("status", [""])[0]),
                limit=int(query.get("limit", ["100"])[0]),
            )
            self._json(HTTPStatus.OK, {"ok": True, "incidents": records})
            return
        if path == "/v1/actions":
            records = self.server.state.list_actions(limit=int(query.get("limit", ["100"])[0]))
            self._json(HTTPStatus.OK, {"ok": True, "actions": records})
            return
        match = re.fullmatch(r"/v1/modules/([a-z0-9-]+)/commands", path)
        if match:
            try:
                commands = self.server.state.take_commands(match.group(1))
                self._json(HTTPStatus.OK, {"ok": True, "commands": commands})
            except KeyError:
                self._json(HTTPStatus.NOT_FOUND, {"ok": False, "error": "Unknown module"})
            return
        self._json(HTTPStatus.NOT_FOUND, {"ok": False, "error": "Route not found"})

    def do_POST(self) -> None:
        if not self._require_auth():
            return
        path = self.path.split("?", 1)[0]
        try:
            payload = self._body()
            heartbeat = re.fullmatch(r"/v1/modules/([a-z0-9-]+)/heartbeat", path)
            command = re.fullmatch(r"/v1/modules/([a-z0-9-]+)/commands", path)
            if heartbeat:
                record = self.server.state.heartbeat(heartbeat.group(1), payload)
                self._json(HTTPStatus.OK, {"ok": True, "heartbeat": record})
                return
            if command:
                record = self.server.state.add_command(command.group(1), payload)
                self._json(HTTPStatus.CREATED, {"ok": True, "command": record})
                return
            if path == "/v1/evidence":
                record = self.server.state.add_evidence(payload)
                self._json(HTTPStatus.CREATED, {"ok": True, "evidence": record})
                return
            incident_action = re.fullmatch(r"/v1/incidents/(inc-[a-f0-9]+)/actions", path)
            if incident_action:
                result = self.server.state.apply_incident_action(incident_action.group(1), payload)
                self._json(HTTPStatus.CREATED, {"ok": True, **result})
                return
            self._json(HTTPStatus.NOT_FOUND, {"ok": False, "error": "Route not found"})
        except KeyError:
            self._json(HTTPStatus.NOT_FOUND, {"ok": False, "error": "Unknown module"})
        except (ValueError, json.JSONDecodeError) as error:
            self._json(HTTPStatus.BAD_REQUEST, {"ok": False, "error": str(error)})
        except Exception:
            logging.exception("Guardian request failed")
            self._json(HTTPStatus.INTERNAL_SERVER_ERROR, {"ok": False, "error": "Internal error"})


def run(host: str = DEFAULT_HOST, port: int = DEFAULT_PORT) -> None:
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=[logging.FileHandler(LOG_PATH, encoding="utf-8"), logging.StreamHandler()],
    )
    token = ensure_token()
    state = GuardianState()
    server = GuardianServer((host, port), token, state)
    PID_PATH.write_text(str(__import__("os").getpid()), encoding="utf-8")
    logging.info("VOS Guardian Core %s listening at http://%s:%s", VERSION, host, port)
    try:
        server.serve_forever(poll_interval=0.25)
    finally:
        server.server_close()
        PID_PATH.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="VOS Guardian Core")
    parser.add_argument("--host", default=DEFAULT_HOST)
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--check", action="store_true", help="validate configuration and exit")
    args = parser.parse_args()
    if args.host not in {"127.0.0.1", "localhost"}:
        parser.error("Guardian Core must bind to the local machine")
    if args.check:
        modules = load_registry()
        print(f"VOS Guardian Core {VERSION} ready | {len(modules)} modules registered")
        return 0
    run(args.host, args.port)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
