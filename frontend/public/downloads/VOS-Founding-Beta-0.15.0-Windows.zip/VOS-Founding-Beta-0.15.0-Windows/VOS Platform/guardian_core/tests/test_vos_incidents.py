import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import vos_guardian


class GuardianIncidentTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        root = Path(self.temporary.name)
        vos_guardian.EVIDENCE_PATH = root / "evidence.jsonl"
        vos_guardian.INCIDENTS_PATH = root / "incidents.json"
        vos_guardian.ACTIONS_PATH = root / "actions.jsonl"
        vos_guardian.STATE_PATH = root / "state.json"
        registry = root / "modules.json"
        registry.write_text(json.dumps({"modules": [
            {"id": "file-armor", "name": "File Armor", "role": "file-armor"},
            {"id": "svansai-guide", "name": "Guide", "role": "system-guide"},
            {"id": "debugger-guide", "name": "Debugger", "role": "device-guide"},
        ]}), encoding="utf-8")
        self.state = vos_guardian.GuardianState(registry)

    def tearDown(self):
        self.temporary.cleanup()

    def test_medium_evidence_creates_and_correlates_incident(self):
        first = self.state.add_evidence({
            "module_id": "file-armor", "kind": "file-scan", "severity": "medium", "summary": "One finding",
        })
        second = self.state.add_evidence({
            "module_id": "file-armor", "kind": "file-scan", "severity": "high", "summary": "Escalated finding",
        })
        self.assertEqual(first["incident_id"], second["incident_id"])
        self.assertEqual(len(self.state.incidents), 1)
        self.assertEqual(self.state.incidents[0]["severity"], "high")
        self.assertEqual(len(self.state.incidents[0]["evidence_ids"]), 2)

    def test_incident_actions_are_safe_and_queue_module_work(self):
        evidence = self.state.add_evidence({
            "module_id": "file-armor", "kind": "file-scan", "severity": "high", "summary": "Threat found",
        })
        incident_id = evidence["incident_id"]
        self.state.apply_incident_action(incident_id, {"action": "acknowledge"})
        self.state.apply_incident_action(incident_id, {"action": "ask-guide"})
        self.state.apply_incident_action(incident_id, {"action": "run-diagnostic"})
        self.state.apply_incident_action(incident_id, {"action": "rescan-files"})
        self.assertEqual(self.state.incidents[0]["status"], "acknowledged")
        self.assertEqual(self.state.commands["svansai-guide"][0]["action"], "explain-incident")
        self.assertEqual(self.state.commands["debugger-guide"][0]["action"], "scan-network")
        self.assertEqual(self.state.commands["file-armor"][0]["action"], "quick-scan")
        self.assertEqual(len(self.state.actions), 4)


if __name__ == "__main__":
    unittest.main()
