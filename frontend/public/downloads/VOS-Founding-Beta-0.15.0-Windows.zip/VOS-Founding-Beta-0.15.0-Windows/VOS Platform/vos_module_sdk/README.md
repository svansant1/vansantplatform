# VOS Module SDK

`@vos/module-sdk` is the trusted server/main-process integration layer for VOS Guides and Armors.

It standardizes module identity, heartbeat health, structured evidence, queued commands, command completion, and failure reporting. Guardian credentials must only be supplied to a trusted server or desktop main process—never browser JavaScript or an Electron renderer.
