import test from "node:test";
import assert from "node:assert/strict";
import { createVOSModuleClient, validateEvidence, validateModuleManifest, VOSContractError } from "../src/index.js";

const manifest = { id: "debugger-guide", name: "Debugger", role: "device-guide", version: "1.0.0", capabilities: ["diagnostics"] };

test("validates and normalizes module manifests", () => {
  assert.deepEqual(validateModuleManifest(manifest), manifest);
  assert.throws(() => validateModuleManifest({ ...manifest, id: "Bad ID" }), VOSContractError);
});

test("rejects invalid evidence", () => {
  assert.throws(() => validateEvidence({ summary: "", severity: "high" }), /summary is required/);
  assert.throws(() => validateEvidence({ summary: "issue", severity: "extreme" }), /severity/);
});

test("heartbeat, evidence, and commands use authenticated contracts", async () => {
  const requests = [];
  const fetchImpl = async (url, options) => {
    requests.push({ url, options });
    const commands = url.endsWith("/commands") && options.method === "GET"
      ? [{ id: "cmd-1", module_id: "debugger-guide", action: "report-status", payload: {}, created_at: new Date().toISOString() }]
      : undefined;
    return { ok: true, status: 200, json: async () => commands ? { ok: true, commands } : { ok: true } };
  };
  let handled = false;
  const client = createVOSModuleClient({ manifest, token: "secret", fetchImpl });
  client.onCommand("report-status", () => { handled = true; });
  await client.heartbeat();
  await client.evidence({ summary: "scan complete" });
  await client.pollCommands();
  assert.equal(handled, true);
  assert.ok(requests.every((item) => item.options.headers.Authorization === "Bearer secret"));
  assert.ok(requests.some((item) => item.url.endsWith("/v1/evidence")));
});
