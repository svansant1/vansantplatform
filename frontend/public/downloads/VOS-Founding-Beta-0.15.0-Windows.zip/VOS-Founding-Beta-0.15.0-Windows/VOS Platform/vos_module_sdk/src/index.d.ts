export type VOSSeverity = "info" | "low" | "medium" | "high" | "critical";
export type VOSModuleManifest = { id: string; name: string; role: string; version: string; capabilities: string[] };
export type VOSHeartbeat = { version: string; state: string; details: Record<string, unknown> };
export type VOSEvidence = { kind?: string; severity?: VOSSeverity; summary: string; details?: Record<string, unknown> };
export type VOSCommand = { id: string; module_id: string; action: string; payload: Record<string, unknown>; created_at: string };
export type VOSModuleStatus = { connected: boolean; module: VOSModuleManifest; guardianUrl: string; lastHeartbeatAt: string | null; lastError: string | null };
export class VOSContractError extends Error {}
export function validateModuleManifest(value: unknown): VOSModuleManifest;
export function validateHeartbeat(value: unknown): VOSHeartbeat;
export function validateEvidence(value: unknown): Required<Omit<VOSEvidence, "details">> & { details: Record<string, unknown> };
export function validateCommand(value: unknown): VOSCommand;
export class VOSModuleClient {
  constructor(options: { manifest: VOSModuleManifest; baseUrl?: string; token?: string; fetchImpl?: typeof fetch; heartbeatIntervalMs?: number; commandIntervalMs?: number });
  readonly manifest: VOSModuleManifest;
  setToken(token: string): void;
  onCommand(action: string, handler: (command: VOSCommand) => void | Promise<void>): this;
  request(method: string, path: string, body?: Record<string, unknown>): Promise<Record<string, any>>;
  heartbeat(state?: string, details?: Record<string, unknown>): Promise<Record<string, any>>;
  evidence(evidence: VOSEvidence): Promise<Record<string, any>>;
  pollCommands(): Promise<VOSCommand[]>;
  start(): Promise<VOSModuleStatus>;
  stop(): Promise<void>;
  status(): VOSModuleStatus;
}
export function createVOSModuleClient(options: ConstructorParameters<typeof VOSModuleClient>[0]): VOSModuleClient;
