const MODULE_ID = /^[a-z0-9-]+$/;
const SEVERITIES = new Set(["info", "low", "medium", "high", "critical"]);

export class VOSContractError extends Error {
  constructor(message) {
    super(message);
    this.name = "VOSContractError";
  }
}

function requiredText(value, field, maxLength = 500) {
  const text = typeof value === "string" ? value.trim() : "";
  if (!text) throw new VOSContractError(`${field} is required`);
  if (text.length > maxLength) throw new VOSContractError(`${field} exceeds ${maxLength} characters`);
  return text;
}

function details(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

export function validateModuleManifest(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new VOSContractError("Module manifest must be an object");
  }
  const id = requiredText(value.id, "id", 80);
  if (!MODULE_ID.test(id)) throw new VOSContractError("id must use lowercase letters, numbers, and hyphens");
  const capabilities = Array.isArray(value.capabilities)
    ? [...new Set(value.capabilities.map((item) => requiredText(item, "capability", 80)))]
    : [];
  return {
    id,
    name: requiredText(value.name, "name", 120),
    role: requiredText(value.role, "role", 80),
    version: requiredText(value.version, "version", 40),
    capabilities,
  };
}

export function validateHeartbeat(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new VOSContractError("Heartbeat must be an object");
  }
  return {
    version: requiredText(value.version, "version", 40),
    state: requiredText(value.state ?? "running", "state", 80),
    details: details(value.details),
  };
}

export function validateEvidence(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new VOSContractError("Evidence must be an object");
  }
  const severity = String(value.severity ?? "info").toLowerCase();
  if (!SEVERITIES.has(severity)) throw new VOSContractError("Invalid evidence severity");
  return {
    kind: requiredText(value.kind ?? "operational", "kind", 80),
    severity,
    summary: requiredText(value.summary, "summary", 500),
    details: details(value.details),
  };
}

export function validateCommand(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new VOSContractError("Command must be an object");
  }
  return {
    id: requiredText(value.id, "id", 80),
    module_id: requiredText(value.module_id, "module_id", 80),
    action: requiredText(value.action, "action", 80),
    payload: details(value.payload),
    created_at: requiredText(value.created_at, "created_at", 80),
  };
}

export class VOSModuleClient {
  constructor(options) {
    this.manifest = validateModuleManifest(options?.manifest);
    this.baseUrl = String(options?.baseUrl || process.env.VOS_GUARDIAN_URL || "http://127.0.0.1:8765").replace(/\/$/, "");
    this.token = options?.token || process.env.VOS_GUARDIAN_TOKEN || "";
    this.fetchImpl = options?.fetchImpl || globalThis.fetch;
    if (typeof this.fetchImpl !== "function") throw new VOSContractError("A fetch implementation is required");
    this.heartbeatIntervalMs = Math.max(5000, Number(options?.heartbeatIntervalMs || 10000));
    this.commandIntervalMs = Math.max(1000, Number(options?.commandIntervalMs || 3000));
    this.commandHandlers = new Map();
    this.heartbeatTimer = null;
    this.commandTimer = null;
    this.started = false;
    this.lastError = null;
    this.lastHeartbeatAt = null;
  }

  setToken(token) {
    this.token = String(token || "");
  }

  onCommand(action, handler) {
    this.commandHandlers.set(requiredText(action, "action", 80), handler);
    return this;
  }

  async request(method, path, body) {
    if (!this.token) throw new VOSContractError("Guardian token is not configured");
    const response = await this.fetchImpl(`${this.baseUrl}${path}`, {
      method,
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${this.token}`,
        ...(body ? { "Content-Type": "application/json" } : {}),
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || `Guardian request failed (${response.status})`);
    return payload;
  }

  async heartbeat(state = "running", heartbeatDetails = {}) {
    const payload = validateHeartbeat({ version: this.manifest.version, state, details: heartbeatDetails });
    const result = await this.request("POST", `/v1/modules/${this.manifest.id}/heartbeat`, payload);
    this.lastHeartbeatAt = new Date().toISOString();
    this.lastError = null;
    return result;
  }

  async evidence(evidence) {
    const payload = validateEvidence(evidence);
    return await this.request("POST", "/v1/evidence", { module_id: this.manifest.id, ...payload });
  }

  async pollCommands() {
    const response = await this.request("GET", `/v1/modules/${this.manifest.id}/commands`);
    const commands = Array.isArray(response.commands) ? response.commands.map(validateCommand) : [];
    for (const command of commands) {
      const handler = this.commandHandlers.get(command.action);
      try {
        if (handler) {
          await handler(command);
          await this.evidence({ kind: "command-completed", severity: "info", summary: `Completed VOS command: ${command.action}`, details: { commandId: command.id } });
        } else {
          await this.evidence({ kind: "command-unsupported", severity: "low", summary: `Unsupported VOS command: ${command.action}`, details: { commandId: command.id } });
        }
      } catch (error) {
        await this.evidence({ kind: "command-failed", severity: "medium", summary: `VOS command failed: ${command.action}`, details: { commandId: command.id, error: error instanceof Error ? error.message.slice(0, 300) : "Unknown error" } }).catch(() => {});
      }
    }
    return commands;
  }

  async start() {
    if (this.started) return this.status();
    this.started = true;
    try {
      await this.heartbeat("running", { capabilities: this.manifest.capabilities });
      await this.pollCommands();
    } catch (error) {
      this.lastError = error instanceof Error ? error.message : String(error);
      this.started = false;
      throw error;
    }
    this.heartbeatTimer = setInterval(() => {
      void this.heartbeat("running", { capabilities: this.manifest.capabilities }).catch((error) => { this.lastError = error instanceof Error ? error.message : String(error); });
    }, this.heartbeatIntervalMs);
    this.commandTimer = setInterval(() => {
      void this.pollCommands().catch((error) => { this.lastError = error instanceof Error ? error.message : String(error); });
    }, this.commandIntervalMs);
    this.heartbeatTimer.unref?.();
    this.commandTimer.unref?.();
    return this.status();
  }

  async stop() {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    if (this.commandTimer) clearInterval(this.commandTimer);
    this.heartbeatTimer = null;
    this.commandTimer = null;
    if (this.started) await this.heartbeat("stopped").catch(() => {});
    this.started = false;
  }

  status() {
    return {
      connected: this.started && !this.lastError,
      module: this.manifest,
      guardianUrl: this.baseUrl,
      lastHeartbeatAt: this.lastHeartbeatAt,
      lastError: this.lastError,
    };
  }
}

export function createVOSModuleClient(options) {
  return new VOSModuleClient(options);
}
