export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    const { ensureVOSGuideConnected } = await import("@/lib/platform/vos-integration");
    await ensureVOSGuideConnected();
  }
}
