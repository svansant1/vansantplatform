import {
  createVOSModuleClient,
  type VOSCommand,
  type VOSModuleClient,
} from "@vos/module-sdk";

const globalVOS = globalThis as typeof globalThis & {
  __svansaiVOSClient?: VOSModuleClient;
  __svansaiVOSInbox?: Array<{ receivedAt: string; command: VOSCommand }>;
};

function inbox() {
  globalVOS.__svansaiVOSInbox ??= [];
  return globalVOS.__svansaiVOSInbox;
}

function buildClient() {
  const client = createVOSModuleClient({
    manifest: {
      id: "svansai-guide",
      name: "SVANSAI Guide",
      role: "system-guide",
      version: "1.0.0",
      capabilities: [
        "guidance",
        "explanations",
        "recommendations",
        "incident-explanation",
        "module-routing",
      ],
    },
  });

  client.onCommand("report-status", async () => {
    await client.evidence({
      kind: "guide-status",
      severity: "info",
      summary: "SVANSAI Guide is connected and ready",
      details: { capabilities: client.manifest.capabilities },
    });
  });

  client.onCommand("explain-incident", async (command) => {
    const queue = inbox();
    queue.unshift({ receivedAt: new Date().toISOString(), command });
    if (queue.length > 20) queue.length = 20;
  });

  return client;
}

export function getVOSGuideClient() {
  globalVOS.__svansaiVOSClient ??= buildClient();
  return globalVOS.__svansaiVOSClient;
}

export async function ensureVOSGuideConnected() {
  const client = getVOSGuideClient();
  if (!process.env.VOS_GUARDIAN_TOKEN) return client.status();
  if (!client.status().connected) {
    await client.start().catch(() => undefined);
  }
  return client.status();
}

export async function reportVOSGuideOutcome(outcome: {
  requestId: string;
  route: string;
  latencyMs: number;
  recommendedModules: string[];
  qualityScore?: number;
  fallbackUsed: boolean;
}) {
  const client = getVOSGuideClient();
  if (!client.status().connected) return;
  await client.evidence({
    kind: "guide-orchestration",
    severity: outcome.fallbackUsed ? "low" : "info",
    summary: `SVANSAI completed a ${outcome.route} guidance request`,
    details: outcome,
  });
}

export function getVOSGuideStatus() {
  return {
    ...getVOSGuideClient().status(),
    pendingIncidentExplanations: inbox().length,
  };
}
