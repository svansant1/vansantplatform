import { NextResponse } from "next/server";
import { buildReadinessReport } from "@/lib/platform/readiness";
import {
  ensureVOSGuideConnected,
  getVOSGuideStatus,
} from "@/lib/platform/vos-integration";

export async function GET() {
  const [report] = await Promise.all([
    buildReadinessReport(),
    ensureVOSGuideConnected(),
  ]);
  const vos = getVOSGuideStatus();
  return NextResponse.json({ ...report, vos }, {
    status: report.ok ? 200 : 503,
    headers: { "Cache-Control": "no-store" },
  });
}
