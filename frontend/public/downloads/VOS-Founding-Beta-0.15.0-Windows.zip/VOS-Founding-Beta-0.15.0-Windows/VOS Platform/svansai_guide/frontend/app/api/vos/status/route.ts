import { NextResponse } from "next/server";
import {
  ensureVOSGuideConnected,
  getVOSGuideStatus,
} from "@/lib/platform/vos-integration";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  await ensureVOSGuideConnected();
  const status = getVOSGuideStatus();
  return NextResponse.json(status, {
    status: status.connected ? 200 : 503,
    headers: { "Cache-Control": "no-store" },
  });
}
