import type { NextConfig } from "next";
import path from "node:path";

const nextConfig: NextConfig = {
  turbopack: {
    // Include the shared VOS SDK while keeping the application itself isolated.
    root: path.resolve(process.cwd(), "../.."),
  },
  images: {
    unoptimized: true,
  },
};

export default nextConfig;
