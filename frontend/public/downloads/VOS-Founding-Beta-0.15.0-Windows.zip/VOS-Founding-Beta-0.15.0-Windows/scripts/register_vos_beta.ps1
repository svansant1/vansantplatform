param([switch]$Remove)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$StartScript = Join-Path $Root 'scripts\start_vos.ps1'
$ShortcutPath = Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs\VOS Founding Beta.lnk'
if ($Remove) {
  Remove-Item -LiteralPath $ShortcutPath -Force -ErrorAction SilentlyContinue
  Write-Output 'VOS Founding Beta shortcut removed. User data was retained.'
  exit 0
}
$Shell = New-Object -ComObject WScript.Shell
$Shortcut = $Shell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = 'powershell.exe'
$Shortcut.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $StartScript + '"'
$Shortcut.WorkingDirectory = $Root
$Shortcut.Description = 'Vansant Operating System Founding Beta'
$Shortcut.Save()
Write-Output "Registered VOS Founding Beta in the current user's Start menu."
