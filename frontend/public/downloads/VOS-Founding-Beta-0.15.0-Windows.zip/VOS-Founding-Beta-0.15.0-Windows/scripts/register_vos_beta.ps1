param([switch]$Remove)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$HiddenLauncher = Join-Path $PSScriptRoot 'launch_vos.vbs'
$ShortcutPath = Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs\VOS Founding Beta.lnk'
$ProtocolKey = 'HKCU:\Software\Classes\vansantos'

if ($Remove) {
  Remove-Item -LiteralPath $ShortcutPath -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $ProtocolKey -Recurse -Force -ErrorAction SilentlyContinue
  Write-Output 'VOS Founding Beta shortcut and website launcher removed. User data was retained.'
  exit 0
}

$Shell = New-Object -ComObject WScript.Shell
$Shortcut = $Shell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = "$env:WINDIR\System32\wscript.exe"
$Shortcut.Arguments = '"' + $HiddenLauncher + '"'
$Shortcut.WorkingDirectory = $Root
$Shortcut.Description = 'Vansant Operating System Founding Beta'
$Shortcut.WindowStyle = 7
$Shortcut.Save()

New-Item -Path $ProtocolKey -Force | Out-Null
Set-Item -LiteralPath $ProtocolKey -Value 'URL:Vansant Operating System Protocol'
New-ItemProperty -Path $ProtocolKey -Name 'URL Protocol' -Value '' -PropertyType String -Force | Out-Null
$CommandKey = Join-Path $ProtocolKey 'shell\open\command'
New-Item -Path $CommandKey -Force | Out-Null
$ProtocolCommand = '"' + "$env:WINDIR\System32\wscript.exe" + '" "' + $HiddenLauncher + '" "%1"'
Set-Item -LiteralPath $CommandKey -Value $ProtocolCommand

Write-Output 'Registered VOS Founding Beta in the Start menu and enabled website launch links.'
