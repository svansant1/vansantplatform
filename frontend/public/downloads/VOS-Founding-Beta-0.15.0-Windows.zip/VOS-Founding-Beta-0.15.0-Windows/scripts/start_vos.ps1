param([string]$LaunchUri = '')

$ErrorActionPreference = 'Stop'
$identityRoot = Split-Path -Parent $PSScriptRoot
$desktop = Join-Path $identityRoot 'VOS Desktop\vos\desktop.py'
$networkArmor = Join-Path $identityRoot 'VOS Platform\network_armor\network_armor.py'
$runtime = Join-Path $identityRoot 'runtime'

function Resolve-VosPython {
  $python = Get-Command python.exe -ErrorAction SilentlyContinue
  if (-not $python) { throw 'Python is required to start VOS.' }
  $pythonw = Join-Path (Split-Path -Parent $python.Source) 'pythonw.exe'
  if (Test-Path -LiteralPath $pythonw) { return $pythonw }
  return $python.Source
}

New-Item -ItemType Directory -Force -Path $runtime | Out-Null
$pythonExecutable = Resolve-VosPython
$desktopArguments = @(('"{0}"' -f $desktop))

# Guardian is a single local security authority. Stop only Guardian processes
# from VOS installations before this installation claims the fixed local port;
# otherwise a different copy can answer health checks while rejecting this
# desktop's token with HTTP 401.
$guardianProcesses = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
  $_.Name -in @('python.exe', 'pythonw.exe') -and $_.CommandLine -like '*vos_guardian.py*'
}
foreach ($guardianProcess in $guardianProcesses) {
  Stop-Process -Id $guardianProcess.ProcessId -Force -ErrorAction SilentlyContinue
}
for ($attempt = 0; $attempt -lt 30; $attempt++) {
  $listener = Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue
  if (-not $listener) { break }
  Start-Sleep -Milliseconds 100
}

if ($LaunchUri) {
  $uri = [Uri]$LaunchUri
  if ($uri.Scheme -ne 'vansantos') { throw 'Unsupported VOS launch protocol.' }
  $desktopArguments += '--pair-from-site'
}

# Website launches enter the VOS pairing lock first. Normal Start-menu launches
# open the local desktop directly. Both paths remain free of console windows.
$desktopProcess = Start-Process -FilePath $pythonExecutable -ArgumentList $desktopArguments -WindowStyle Hidden -PassThru
for ($attempt = 0; $attempt -lt 30; $attempt++) {
  $tokenPath = Join-Path $runtime 'guardian.token'
  if (Test-Path -LiteralPath $tokenPath) { break }
  Start-Sleep -Milliseconds 250
}
if (Test-Path -LiteralPath $tokenPath) {
  $env:VOS_GUARDIAN_TOKEN = (Get-Content -LiteralPath $tokenPath -Raw).Trim()
  $env:VOS_GUARDIAN_URL = 'http://127.0.0.1:8765'
  $networkPidPath = Join-Path $runtime 'network_armor.pid'
  $networkRunning = $false
  if (Test-Path -LiteralPath $networkPidPath) {
    $networkPid = [int](Get-Content -LiteralPath $networkPidPath -Raw)
    $networkRunning = $null -ne (Get-Process -Id $networkPid -ErrorAction SilentlyContinue)
  }
  if (-not $networkRunning) {
    Start-Process -FilePath $pythonExecutable -ArgumentList ('"{0}"' -f $networkArmor) -WindowStyle Hidden | Out-Null
  }
}
Wait-Process -Id $desktopProcess.Id
