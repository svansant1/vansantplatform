$ErrorActionPreference = 'Stop'
$identityRoot = Split-Path -Parent $PSScriptRoot
$desktop = Join-Path $identityRoot 'VOS Desktop\vos\desktop.py'
$networkArmor = Join-Path $identityRoot 'VOS Platform\network_armor\network_armor.py'
$runtime = Join-Path $identityRoot 'runtime'

# VOS Desktop starts Guardian Core. Network Armor then joins as a consent-gated
# background posture agent; it does not activate a VPN tunnel.
$desktopProcess = Start-Process python -ArgumentList ('"{0}"' -f $desktop) -PassThru
for ($attempt = 0; $attempt -lt 30; $attempt++) {
  $tokenPath = Join-Path $runtime 'guardian.token'
  if (Test-Path -LiteralPath $tokenPath) { break }
  Start-Sleep -Milliseconds 250
}
if (Test-Path -LiteralPath $tokenPath) {
  $env:VOS_GUARDIAN_TOKEN = (Get-Content -LiteralPath $tokenPath -Raw).Trim()
  $env:VOS_GUARDIAN_URL = 'http://127.0.0.1:8765'
  $networkPidPath = Join-Path $runtime 'network_armor.pid'
  $networkRunning = $false
  if (Test-Path -LiteralPath $networkPidPath) {
    $networkPid = [int](Get-Content -LiteralPath $networkPidPath -Raw)
    $networkRunning = $null -ne (Get-Process -Id $networkPid -ErrorAction SilentlyContinue)
  }
  if (-not $networkRunning) {
    Start-Process python -ArgumentList ('"{0}"' -f $networkArmor) -WindowStyle Hidden | Out-Null
  }
}
Wait-Process -Id $desktopProcess.Id
