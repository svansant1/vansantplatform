param(
  [string]$OutputDirectory = (Join-Path (Split-Path -Parent $PSScriptRoot) 'release\website')
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$Version = (Get-Content -LiteralPath (Join-Path $Root 'vos_identity.json') -Raw | ConvertFrom-Json).version
$ReleaseName = "VOS-Founding-Beta-$Version-Windows"
$CoreArchive = Join-Path $OutputDirectory "$ReleaseName.zip"
$Project = Join-Path $Root 'VOS Installer\VOSInstaller.csproj'
$Payload = Join-Path $Root 'VOS Installer\payload\VOS-Core.zip'
$PublishDirectory = Join-Path $Root 'VOS Installer\publish'
$Installer = Join-Path $OutputDirectory "$ReleaseName-Setup-R5.exe"

if (-not (Test-Path -LiteralPath $CoreArchive)) {
  & (Join-Path $PSScriptRoot 'build_vos_portable.ps1') -OutputDirectory $OutputDirectory
}

New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Payload),$OutputDirectory | Out-Null
Copy-Item -LiteralPath $CoreArchive -Destination $Payload -Force
if (Test-Path -LiteralPath $PublishDirectory) { Remove-Item -LiteralPath $PublishDirectory -Recurse -Force }

& dotnet publish $Project -c Release -p:DebugType=None -p:DebugSymbols=false -o $PublishDirectory
if ($LASTEXITCODE -ne 0) { throw 'The VOS installer build failed.' }

$BuiltInstaller = Join-Path $PublishDirectory 'VOS Founding Beta Setup.exe'
if (-not (Test-Path -LiteralPath $BuiltInstaller)) { throw 'The VOS installer executable was not created.' }
Copy-Item -LiteralPath $BuiltInstaller -Destination $Installer -Force

$Hash = Get-FileHash -Algorithm SHA256 -LiteralPath $Installer
$Hash.Hash | Set-Content -LiteralPath "$Installer.sha256" -Encoding ascii
Write-Output $Installer
Write-Output "$([math]::Round((Get-Item -LiteralPath $Installer).Length / 1MB, 1)) MB"
Write-Output "SHA256 $($Hash.Hash)"
