param([switch]$VerifyOnly)

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$DownloadBase = if ($env:VOS_DOWNLOAD_BASE_URL) { $env:VOS_DOWNLOAD_BASE_URL.TrimEnd('/') } else { 'https://vansantplatform.com/downloads' }

function Resolve-VosPython {
  $python = Get-Command python.exe -ErrorAction SilentlyContinue
  if ($python) {
    return [pscustomobject]@{ Executable = $python.Source; Arguments = @() }
  }
  $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
  if ($launcher) {
    return [pscustomobject]@{ Executable = $launcher.Source; Arguments = @('-3') }
  }
  throw 'Python 3.10 or newer is required. Install Python from python.org, enable Add Python to PATH, and run this installer again.'
}

$Python = Resolve-VosPython
$Executable = $Python.Executable
$Prefix = @($Python.Arguments)
$VersionOutput = & $Executable @Prefix -c 'import sys; print(sys.version_info[0], sys.version_info[1], sys.version_info[2], sep=chr(46))'
$VersionExitCode = $LASTEXITCODE
$Version = ([string]$VersionOutput).Trim()
if ($VersionExitCode -ne 0 -or [string]::IsNullOrWhiteSpace($Version)) {
  throw 'VOS found Python but could not query its version.'
}
& $Executable @Prefix -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)'
if ($LASTEXITCODE -ne 0) { throw "VOS requires Python 3.10 or newer. Found Python $Version." }

Write-Output "Using Python $Version"
& $Executable @Prefix -c 'import PIL' 2>$null
if ($LASTEXITCODE -ne 0) {
  if ($VerifyOnly) { throw 'Pillow is not installed for the selected Python runtime.' }
  Write-Output 'Installing the VOS desktop image dependency...'
  & $Executable @Prefix -m pip install --user Pillow
  if ($LASTEXITCODE -ne 0) { throw 'Pillow could not be installed. Check your internet connection and retry.' }
}

& $Executable @Prefix -c 'import winpty' 2>$null
if ($LASTEXITCODE -ne 0) {
  if ($VerifyOnly) { throw 'The interactive terminal dependency is not installed for the selected Python runtime.' }
  Write-Output 'Installing the VOS interactive terminal dependency...'
  & $Executable @Prefix -m pip install --user pywinpty
  if ($LASTEXITCODE -ne 0) { throw 'The interactive terminal component could not be installed. Check your internet connection and retry.' }
}

if ($VerifyOnly) {
  Write-Output "VOS setup verification passed with Python $Version."
  exit 0
}

$Modules = @(
  @{ Name = 'VOS Sandbox'; File = 'Vansant-Sandbox.exe'; Destination = 'VOS Platform\sandbox_armor\release\win-unpacked\VOS Sandbox Armor.exe' },
  @{ Name = 'SVANSAI Debugger'; File = 'SVANSAI-Debugger-Agent.exe'; Destination = 'VOS Platform\debugger_guide\release\win-unpacked\SVANSAI Debugger - VOS Device Guide.exe' },
  @{ Name = 'SVANS Shield'; File = 'SVANS-Shield.exe'; Destination = 'VOS Platform\file_armor\desktop\dist\VOS-File-Armor.exe' },
  @{ Name = 'SV Browser'; File = 'SV-Browser.exe'; Destination = 'SV Browser\publish-v17\SV Browser.exe' }
)

foreach ($Module in $Modules) {
  $Destination = Join-Path $Root $Module.Destination
  if ((Test-Path -LiteralPath $Destination) -and (Get-Item -LiteralPath $Destination).Length -gt 1MB) {
    Write-Output "$($Module.Name) is already installed."
    continue
  }
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Destination) | Out-Null
  $Temporary = "$Destination.download"
  Write-Output "Downloading $($Module.Name)..."
  try {
    Invoke-WebRequest -Uri "$DownloadBase/$($Module.File)" -OutFile $Temporary -UseBasicParsing
    if ((Get-Item -LiteralPath $Temporary).Length -lt 1MB) { throw 'The downloaded file was incomplete.' }
    Move-Item -LiteralPath $Temporary -Destination $Destination -Force
  } catch {
    Remove-Item -LiteralPath $Temporary -Force -ErrorAction SilentlyContinue
    throw "Could not download $($Module.Name). Check your internet connection and rerun Install VOS.cmd. $($_.Exception.Message)"
  }
}

$Guide = Join-Path $Root 'VOS Platform\svansai_guide\frontend'
if ((Test-Path -LiteralPath $Guide) -and -not (Test-Path -LiteralPath (Join-Path $Guide 'node_modules'))) {
  $npm = Get-Command npm.cmd -ErrorAction SilentlyContinue
  if ($npm) {
    Write-Output 'Preparing the optional SVANSAI Guide...'
    & $npm.Source ci --prefix $Guide --omit=dev
    if ($LASTEXITCODE -ne 0) { Write-Warning 'SVANSAI Guide setup did not complete. The rest of VOS remains usable.' }
  } else {
    Write-Warning 'Node.js was not found. The optional SVANSAI Guide will remain unavailable until Node.js 20 or newer is installed and Install VOS.cmd is rerun.'
  }
}

& (Join-Path $PSScriptRoot 'register_vos_beta.ps1')
Write-Output ''
Write-Output 'VOS Founding Beta is ready. Open it from the Windows Start menu or run Start VOS.cmd.'
