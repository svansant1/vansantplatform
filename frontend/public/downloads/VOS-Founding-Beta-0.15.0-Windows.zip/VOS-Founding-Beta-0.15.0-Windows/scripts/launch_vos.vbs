Option Explicit

Dim shell, fileSystem, scriptDirectory, powerShellScript, command, launchUri
Set shell = CreateObject("WScript.Shell")
Set fileSystem = CreateObject("Scripting.FileSystemObject")
scriptDirectory = fileSystem.GetParentFolderName(WScript.ScriptFullName)
powerShellScript = fileSystem.BuildPath(scriptDirectory, "start_vos.ps1")
launchUri = ""
If WScript.Arguments.Count > 0 Then
  launchUri = Replace(WScript.Arguments(0), """", "")
End If

command = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File """ & powerShellScript & """"
If Len(launchUri) > 0 Then
  command = command & " -LaunchUri """ & launchUri & """"
End If
shell.Run command, 0, False
