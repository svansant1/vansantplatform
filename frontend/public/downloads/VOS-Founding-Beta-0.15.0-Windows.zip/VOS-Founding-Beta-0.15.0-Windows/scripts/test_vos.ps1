param([switch]$Json)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$TestScript = Join-Path $Root 'VOS Platform\lifecycle\vos_self_test.py'
$Arguments = @($TestScript)
if ($Json) { $Arguments += '--json' }
& python @Arguments
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
