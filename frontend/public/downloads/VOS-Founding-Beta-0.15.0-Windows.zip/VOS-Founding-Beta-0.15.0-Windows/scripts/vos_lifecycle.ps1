param(
  [ValidateSet('manifest','verify','backup','support-bundle','restore')]
  [string]$Action = 'verify',
  [string]$Archive = ''
)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$Manager = Join-Path $Root 'VOS Platform\lifecycle\vos_lifecycle.py'
if ($Action -eq 'restore') {
  if ([string]::IsNullOrWhiteSpace($Archive)) { throw 'Provide -Archive for restore.' }
  & python $Manager restore $Archive
} else {
  & python $Manager $Action
}
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
