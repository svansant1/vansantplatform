@echo off
cd /d "%~dp0"
python "vos\desktop.py"
