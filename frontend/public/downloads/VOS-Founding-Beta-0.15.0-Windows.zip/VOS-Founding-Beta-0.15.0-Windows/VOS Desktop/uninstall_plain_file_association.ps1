Remove-Item -Path "HKCU:\Software\Classes\.plain" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "HKCU:\Software\Classes\Svans.PlainFile" -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "Removed the Svans .plain file association for the current Windows user."
