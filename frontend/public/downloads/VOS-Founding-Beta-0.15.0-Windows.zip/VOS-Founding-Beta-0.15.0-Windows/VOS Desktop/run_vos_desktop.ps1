python "$PSScriptRoot\vos\desktop.py"
