python "$PSScriptRoot\vos\vos.py"
