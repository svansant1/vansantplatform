@echo off
python "%~dp0plain.py" run %1 --trusted
pause
