#!/usr/bin/env python3
"""
Plain: a small sentence-style programming language that transpiles to Python.

Plain is intentionally readable:

    Remember score as 10.
    Say "Score:".
    Say score.

Use `python plain.py run examples/hello.plain` to execute a program, or
`python plain.py build examples/hello.plain` to print the generated Python.
"""

from __future__ import annotations

import argparse
import ast
import shlex
import operator
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

VERSION = "2.0.0"


class PlainError(Exception):
    """An error that should be shown to the language user."""


@dataclass(frozen=True)
class SourceLine:
    number: int
    indent: int
    text: str


COMPARISONS = {
    "is equal to": "==",
    "equals": "==",
    "is not equal to": "!=",
    "does not equal": "!=",
    "is greater than or equal to": ">=",
    "is at least": ">=",
    "is less than or equal to": "<=",
    "is at most": "<=",
    "is greater than": ">",
    "is more than": ">",
    "is less than": "<",
    "is true": "is True",
    "is false": "is False",
}

BLOCK_STARTERS = (
    "Repeat",
    "For each",
    "While",
    "If",
    "Try",
    "Define",
    "Otherwise",
    "If it fails",
    "When",
    "Every",
    "In the background",
    "Run in parallel",
    "Task",
    "Test",
    "Define type",
)


SAFE_BUILTINS = {
    "__build_class__": __build_class__,
    "__import__": __import__,
    "abs": abs,
    "any": any,
    "bool": bool,
    "dict": dict,
    "float": float,
    "getattr": getattr,
    "globals": globals,
    "int": int,
    "isinstance": isinstance,
    "len": len,
    "list": list,
    "max": max,
    "min": min,
    "print": print,
    "range": range,
    "round": round,
    "RuntimeError": RuntimeError,
    "sorted": sorted,
    "str": str,
    "sum": sum,
    "SystemExit": SystemExit,
    "ValueError": ValueError,
    "object": object,
}


SAFE_MODULES = {
    "calendar",
    "collections",
    "csv",
    "datetime",
    "decimal",
    "fractions",
    "functools",
    "hashlib",
    "itertools",
    "json",
    "math",
    "operator",
    "random",
    "re",
    "statistics",
    "string",
    "textwrap",
    "time",
    "uuid",
}


VOCABULARY_TEXT = """Plain vocabulary:
  Say "hello"
  Run 2+3
  Remember score as 10
  Remember 10 as score
  Remember greeting as "Hello " + name
  Remember items as empty list
  Remember total as length of items
  Insert "red" into items
  For each item in items:
    Say item
  End
  While score is less than 100:
    Add 10 to score
  End
  If "red" is in items:
    Say "found it"
  End
  Import math
  Run math.sqrt(81)
  Scan folder "."
  Open "https://example.com"
  Write "hello\\n" to file "notes.txt"
  Read file "notes.txt"
  Copy "notes.txt" to "backup.txt"
  Move "backup.txt" to "archive.txt"
  Delete file "archive.txt"
  Run Python "print(6 * 7)" and remember output as answer
  Run JavaScript "console.log(10 + 5)" and remember output as answer
  Run PowerShell "Write-Output 42" and remember output as answer
  Stop
"""


GRID_TEXT = """Plain Grid:
  Sentence layer  -> English-like Plain commands
  Parser layer    -> turns sentences into structured actions
  Intent layer    -> maps verbs like run, open, scan, import, insert
  Grid runtime    -> routes actions to adapters
  Adapters        -> Python, JavaScript/Node, shell commands, files, modules
  Output layer    -> prints results or remembers them as variables
"""


ADAPTER_TEXT = """Plain adapters:
  native math
  Python modules
  Python command runner
  JavaScript/Node command runner
  Ruby command runner
  Perl command runner
  PHP command runner
  PowerShell command runner
  file system
  operating-system commands
"""

HELP_TOPICS = {
    "say": 'Say prints a value. Example: Say "hello".',
    "run": "Run evaluates an expression or calls another language. Example: Run 2+3.",
    "remember": 'Remember stores a value. Examples: Remember score as 10. Remember greeting as "Hello {name}".',
    "ask claude": 'Ask Claude sends a prompt to Claude using ANTHROPIC_API_KEY. Example: Ask Claude "summarize this" and remember answer as summary.',
    "fetch": 'Fetch gets a URL. Example: Fetch "https://example.com" and remember response as page.',
    "post": 'Post sends a body to a URL. Example: Post to "https://api.example.com" with body data and remember response as result.',
    "database": 'Database commands use SQLite. Example: Connect to database "app.db". Ask database "SELECT * FROM users" and remember rows as users.',
    "try": 'Try catches runtime errors. Use Try:, If it fails:, then End.',
    "import": 'Import loads a Python module. Example: Import math. Use "helpers.plain". imports Plain files.',
    "list": 'List commands include first item, last item, Remove, Sort, and Reverse.',
}


ALLOWED_MATH_BINOPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}

ALLOWED_MATH_UNARYOPS = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
}


RUNTIME_HELPERS = """
import os
import json
import inspect
import socket
import shutil
import sqlite3
import subprocess
import sys
import threading
import time
from datetime import date, datetime
import urllib.request
import webbrowser
from pathlib import Path

PLAIN_ALLOW_IMPORTS = __ALLOW_IMPORTS__
PLAIN_ALLOW_SYSTEM = __ALLOW_SYSTEM__
PLAIN_SAFE_MODULES = __SAFE_MODULES__


def _plain_format(template, values):
    frame = inspect.currentframe().f_back
    merged = {}
    merged.update(values)
    if frame is not None:
        merged.update(frame.f_locals)
        self_obj = frame.f_locals.get("self")
        if self_obj is not None:
            merged.update(getattr(self_obj, "__dict__", {}))
    return str(template).format_map(merged)


def _plain_stack():
    return []


def _plain_queue():
    return []


def _plain_push(stack, item):
    stack.append(item)


def _plain_pop(stack):
    return stack.pop()


def _plain_enqueue(queue, item):
    queue.append(item)


def _plain_dequeue(queue):
    return queue.pop(0)


_plain_background_tasks = []


def _plain_start_background(target):
    thread = threading.Thread(target=target, daemon=True)
    _plain_background_tasks.append(thread)
    thread.start()


def _plain_wait_background_tasks():
    for thread in list(_plain_background_tasks):
        thread.join()


def _plain_every(seconds, callback):
    def runner():
        while True:
            time.sleep(float(seconds))
            callback()
    thread = threading.Thread(target=runner, daemon=True)
    thread.start()
    return thread


def _plain_watch_file(path, callback, interval=1):
    def runner():
        target = Path(str(path))
        last = target.stat().st_mtime if target.exists() else None
        while True:
            time.sleep(interval)
            current = target.stat().st_mtime if target.exists() else None
            if current != last:
                last = current
                callback()
    thread = threading.Thread(target=runner, daemon=True)
    thread.start()
    return thread


def _plain_run_parallel(*callbacks):
    threads = [threading.Thread(target=callback) for callback in callbacks]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()


_plain_tests = []


def _plain_register_test(name, callback):
    _plain_tests.append((name, callback))


def _plain_run_tests():
    passed = 0
    for name, callback in _plain_tests:
        try:
            callback()
            print(f"PASS {name}")
            passed += 1
        except Exception as error:
            print(f"FAIL {name}: {error}")
    print(f"{passed}/{len(_plain_tests)} tests passed")


def _plain_make_sure(condition, message):
    if not condition:
        raise AssertionError(message)


_plain_server_connection = None


def _plain_connect_server(host, port):
    _plain_require_system("Connecting to servers")
    global _plain_server_connection
    _plain_server_connection = socket.create_connection((str(host), int(port)), timeout=10)
    return _plain_server_connection


def _plain_send_server(message):
    _plain_require_system("Sending network messages")
    if _plain_server_connection is None:
        raise RuntimeError("No server connection is open. Use Connect to server first.")
    _plain_server_connection.sendall(str(message).encode("utf-8"))


def _plain_listen_messages(port):
    _plain_require_system("Listening for network messages")
    def runner():
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
            server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server.bind(("", int(port)))
            server.listen()
            while True:
                conn, addr = server.accept()
                with conn:
                    data = conn.recv(4096)
                    if data:
                        print(data.decode("utf-8", errors="replace"))
    thread = threading.Thread(target=runner, daemon=True)
    thread.start()
    return thread


def _plain_create_window(title):
    _plain_require_system("Creating desktop windows")
    import tkinter as tk
    root = tk.Tk()
    root.title(str(title))
    return root


def _plain_add_label(window, text):
    import tkinter as tk
    label = tk.Label(window, text=str(text))
    label.pack()
    return label


def _plain_add_input(window, placeholder):
    import tkinter as tk
    entry = tk.Entry(window)
    entry.insert(0, str(placeholder))
    entry.pack()
    return entry


_plain_last_button = None


def _plain_add_button(window, text):
    import tkinter as tk
    global _plain_last_button
    button = tk.Button(window, text=str(text))
    button.pack()
    _plain_last_button = button
    return button


def _plain_set_last_button_command(callback):
    if _plain_last_button is None:
        raise RuntimeError("No button exists. Use Add button before When button is clicked.")
    _plain_last_button.configure(command=callback)


def _plain_show_window(window):
    window.mainloop()


def _plain_create_web_app(name):
    _plain_require_system("Creating web apps")
    try:
        from flask import Flask
    except ImportError as error:
        raise RuntimeError("Flask is required. Install with: pip install svans[web]") from error
    return Flask(str(name))


def _plain_send_page(text):
    return str(text)


def _plain_start_web_app(app, port):
    _plain_require_system("Starting web apps")
    app.run(port=int(port))


def _plain_import_module(module_name, alias=None):
    blocked_parts = ("..", "/", "\\\\", ":", "__")
    if any(part in module_name for part in blocked_parts):
        raise RuntimeError(f"Plain will not import suspicious module name {module_name!r}.")
    root_name = module_name.split(".")[0]
    if not PLAIN_ALLOW_IMPORTS and root_name not in PLAIN_SAFE_MODULES:
        raise RuntimeError(
            f"Importing {module_name} needs --allow-imports, or add it to Plain's safe module list."
        )
    module = __import__(module_name, fromlist=["*"])
    globals()[alias or module_name.replace(".", "_")] = module
    return module


def _plain_require_system(action):
    if not PLAIN_ALLOW_SYSTEM:
        raise RuntimeError(
            f"{action} needs system access. Run Plain with --allow-system if you trust this program."
        )


def _plain_run_command(command):
    _plain_require_system("Running a command")
    completed = subprocess.run(command, shell=True, text=True, capture_output=True)
    if completed.returncode != 0:
        raise RuntimeError(completed.stderr.strip() or f"Command failed with exit code {completed.returncode}")
    return completed.stdout.strip()


def _plain_run_language(language, code):
    _plain_require_system(f"Running {language}")
    runners = {
        "python": [sys.executable, "-c", code],
        "javascript": ["node", "-e", code],
        "node": ["node", "-e", code],
        "ruby": ["ruby", "-e", code],
        "perl": ["perl", "-e", code],
        "php": ["php", "-r", code],
        "powershell": ["powershell", "-NoProfile", "-Command", code],
    }
    key = language.lower()
    if key not in runners:
        raise RuntimeError(f"Plain does not have a built-in runner for {language}. Use 'Run command' instead.")
    completed = subprocess.run(runners[key], text=True, capture_output=True)
    if completed.returncode != 0:
        raise RuntimeError(completed.stderr.strip() or f"{language} failed with exit code {completed.returncode}")
    return completed.stdout.strip()


def _plain_open_target(target):
    _plain_require_system("Opening files, folders, apps, or websites")
    target = str(target).strip()
    if not target:
        raise RuntimeError("Open needs a file, folder, app, or URL.")
    if target.startswith(("http://", "https://")):
        webbrowser.open(target)
        return target
    if sys.platform.startswith("win"):
        os.startfile(target)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", target])
    else:
        subprocess.Popen(["xdg-open", target])
    return target


def _plain_scan_target(target="."):
    _plain_require_system("Scanning files and folders")
    target_path = Path(str(target)).expanduser()
    if not target_path.exists():
        raise RuntimeError(f"Scan target does not exist: {target}")
    if target_path.is_file():
        return str(target_path)
    names = []
    for child in sorted(target_path.iterdir(), key=lambda item: item.name.lower()):
        suffix = "/" if child.is_dir() else ""
        names.append(f"{child.name}{suffix}")
    return "\\n".join(names)


def _plain_insert_file(text, target, position="end"):
    _plain_require_system("Inserting text into files")
    target_path = Path(str(target)).expanduser()
    target_path.parent.mkdir(parents=True, exist_ok=True)
    text = str(text)
    if position in {"start", "beginning"}:
        old_text = target_path.read_text(encoding="utf-8") if target_path.exists() else ""
        target_path.write_text(text + old_text, encoding="utf-8")
    elif position == "end":
        with target_path.open("a", encoding="utf-8") as handle:
            handle.write(text)
    else:
        raise RuntimeError("Insert position must be start, beginning, or end.")
    return str(target_path)


def _plain_read_file(target):
    _plain_require_system("Reading files")
    return Path(str(target)).expanduser().read_text(encoding="utf-8")


def _plain_write_file(text, target):
    _plain_require_system("Writing files")
    target_path = Path(str(target)).expanduser()
    target_path.parent.mkdir(parents=True, exist_ok=True)
    target_path.write_text(str(text), encoding="utf-8")
    return str(target_path)


def _plain_copy_path(source, target):
    _plain_require_system("Copying files and folders")
    source_path = Path(str(source)).expanduser()
    target_path = Path(str(target)).expanduser()
    if source_path.is_dir():
        shutil.copytree(source_path, target_path, dirs_exist_ok=True)
    else:
        target_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_path, target_path)
    return str(target_path)


def _plain_move_path(source, target):
    _plain_require_system("Moving files and folders")
    target_path = Path(str(target)).expanduser()
    target_path.parent.mkdir(parents=True, exist_ok=True)
    return shutil.move(str(Path(str(source)).expanduser()), str(target_path))


def _plain_delete_path(target):
    _plain_require_system("Deleting files and folders")
    target_path = Path(str(target)).expanduser()
    if not target_path.exists():
        return str(target_path)
    if target_path.is_dir():
        shutil.rmtree(target_path)
    else:
        target_path.unlink()
    return str(target_path)


def _plain_fetch_url(url):
    _plain_require_system("Fetching web URLs")
    request = urllib.request.Request(str(url), headers={"User-Agent": "Svans/0.1"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.read().decode(response.headers.get_content_charset() or "utf-8")


def _plain_post_url(url, body):
    _plain_require_system("Posting to web URLs")
    if isinstance(body, (dict, list)):
        data = json.dumps(body).encode("utf-8")
        content_type = "application/json"
    else:
        data = str(body).encode("utf-8")
        content_type = "text/plain"
    request = urllib.request.Request(
        str(url),
        data=data,
        headers={"User-Agent": "Svans/0.1", "Content-Type": content_type},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.read().decode(response.headers.get_content_charset() or "utf-8")


def _plain_parse_json(text):
    return json.loads(str(text))


def _plain_to_json(value):
    return json.dumps(value)


def _plain_environment_variable(name):
    return os.environ.get(str(name), "")


def _plain_current_date():
    return date.today().isoformat()


def _plain_current_time():
    return datetime.now().isoformat(timespec="seconds")


_plain_database = None


def _plain_connect_database(path):
    _plain_require_system("Connecting to databases")
    global _plain_database
    _plain_database = sqlite3.connect(str(path))
    _plain_database.row_factory = sqlite3.Row
    return str(path)


def _plain_ask_database(query):
    _plain_require_system("Querying databases")
    if _plain_database is None:
        raise RuntimeError("No database is connected. Use: Connect to database \\"myapp.db\\".")
    cursor = _plain_database.execute(str(query))
    if cursor.description:
        return [dict(row) for row in cursor.fetchall()]
    _plain_database.commit()
    return []


def _plain_ask_claude(prompt, context=None):
    _plain_require_system("Calling Claude")
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise RuntimeError("ANTHROPIC_API_KEY is not set. Set it before using Ask Claude.")
    model = os.environ.get("SVANS_CLAUDE_MODEL", "claude-sonnet-4-20250514")
    full_prompt = str(prompt)
    if context is not None:
        full_prompt += "\\n\\nContext:\\n" + str(context)
    body = json.dumps(
        {
            "model": model,
            "max_tokens": 1024,
            "messages": [{"role": "user", "content": full_prompt}],
        }
    ).encode("utf-8")
    request = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=body,
        headers={
            "content-type": "application/json",
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            data = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8")
        raise RuntimeError(f"Claude API error: {error_body}")
    parts = [part.get("text", "") for part in data.get("content", []) if part.get("type") == "text"]
    return "\\\\n".join(parts).strip()
"""


def normalize_source(source: str) -> list[SourceLine]:
    lines: list[SourceLine] = []
    for number, raw in enumerate(source.splitlines(), start=1):
        if not raw.strip() or raw.strip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        if indent % 2 != 0:
            raise PlainError(
                f"Line {number}: indentation must use multiples of two spaces."
            )
        text = raw.strip()
        if text.endswith("."):
            text = text[:-1].rstrip()
        lines.append(SourceLine(number=number, indent=indent // 2, text=text))
    return lines


def expand_plain_imports(
    source: str, base_dir: Path | None, seen: set[Path] | None = None
) -> str:
    if base_dir is None:
        return source
    seen = seen or set()
    expanded: list[str] = []
    for number, raw in enumerate(source.splitlines(), start=1):
        stripped = raw.strip()
        if stripped.endswith("."):
            stripped = stripped[:-1].rstrip()
        match = re.fullmatch(
            r'Use(?: file)?\s+["\'](.+?\.plain)["\']', stripped, flags=re.IGNORECASE
        )
        if not match:
            expanded.append(raw)
            continue
        if raw[: len(raw) - len(raw.lstrip(" "))]:
            raise PlainError(
                f"Line {number}: Plain file imports must be at the top level."
            )
        import_path = (base_dir / match.group(1)).resolve()
        if import_path in seen:
            continue
        if not import_path.exists():
            raise PlainError(
                f"Line {number}: imported Plain file does not exist: {import_path}"
            )
        seen.add(import_path)
        expanded.append(
            expand_plain_imports(
                import_path.read_text(encoding="utf-8"), import_path.parent, seen
            )
        )
    return "\n".join(expanded)


def to_identifier(name: str, line_number: int) -> str:
    ident = name.strip().replace(" ", "_")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", ident):
        raise PlainError(
            f"Line {line_number}: '{name}' is not a valid variable or function name."
        )
    if ident in {"import", "exec", "eval", "open", "__import__"}:
        raise PlainError(f"Line {line_number}: '{ident}' is reserved.")
    return ident


def expression(text: str, line_number: int) -> str:
    text = text.strip()
    lowered = text.lower()
    match = re.fullmatch(r"new ([A-Za-z_][A-Za-z0-9_]*) (.+)", text)
    if match:
        type_name = to_identifier(match.group(1), line_number)
        parts = re.findall(r'"[^"]*"|\'[^\']*\'|\S+', match.group(2))
        args = ", ".join(expression(part, line_number) for part in parts)
        return f"{type_name}({args})"
    match = re.fullmatch(r"current date", text, flags=re.IGNORECASE)
    if match:
        return "_plain_current_date()"
    match = re.fullmatch(r"current time", text, flags=re.IGNORECASE)
    if match:
        return "_plain_current_time()"
    match = re.fullmatch(r"environment variable (.+)", text, flags=re.IGNORECASE)
    if match:
        return f"_plain_environment_variable({string_literal(match.group(1), line_number)})"
    match = re.fullmatch(r"parse JSON from (.+)", text, flags=re.IGNORECASE)
    if match:
        return f"_plain_parse_json({expression(match.group(1), line_number)})"
    match = re.fullmatch(r"JSON from (.+)", text, flags=re.IGNORECASE)
    if match:
        return f"_plain_to_json({expression(match.group(1), line_number)})"
    match = re.fullmatch(r"length of (.+)", text, flags=re.IGNORECASE)
    if match:
        return f"len({expression(match.group(1), line_number)})"
    match = re.fullmatch(r"first item in (.+)", text, flags=re.IGNORECASE)
    if match:
        return f"{expression(match.group(1), line_number)}[0]"
    match = re.fullmatch(r"last item in (.+)", text, flags=re.IGNORECASE)
    if match:
        return f"{expression(match.group(1), line_number)}[-1]"
    match = re.fullmatch(r"([A-Za-z_][A-Za-z0-9_]*) ([A-Za-z_][A-Za-z0-9_]*)", text)
    if match:
        return f"{to_identifier(match.group(1), line_number)}.{to_identifier(match.group(2), line_number)}()"
    match = re.fullmatch(r"square root of (.+)", text, flags=re.IGNORECASE)
    if match:
        return f"({expression(match.group(1), line_number)} ** 0.5)"
    match = re.fullmatch(r"(.+?) squared", text, flags=re.IGNORECASE)
    if match:
        return f"({expression(match.group(1), line_number)} ** 2)"
    match = re.fullmatch(r"round (.+?) to (.+?) places?", text, flags=re.IGNORECASE)
    if match:
        return f"round({expression(match.group(1), line_number)}, int({expression(match.group(2), line_number)}))"
    match = re.fullmatch(r"([A-Za-z_][A-Za-z0-9_]*) (.+)", text)
    if match and (
        (match.group(2).startswith('"') and match.group(2).endswith('"'))
        or (match.group(2).startswith("'") and match.group(2).endswith("'"))
    ):
        return f"{to_identifier(match.group(1), line_number)}[{string_literal(match.group(2), line_number)}]"
    if lowered == "true":
        return "True"
    if lowered == "false":
        return "False"
    if lowered == "nothing":
        return "None"
    if re.fullmatch(r"-?\d+(\.\d+)?", text):
        return text
    if (text.startswith('"') and text.endswith('"')) or (
        text.startswith("'") and text.endswith("'")
    ):
        try:
            value = ast.literal_eval(text)
            if isinstance(value, str) and re.search(r"\{[A-Za-z_][A-Za-z0-9_]*\}", value):
                return f"_plain_format({value!r}, globals())"
            return repr(value)
        except (SyntaxError, ValueError):
            raise PlainError(f"Line {line_number}: string is not closed correctly.")
    try:
        tree = ast.parse(text, mode="eval")
    except SyntaxError:
        raise PlainError(
            f"Line {line_number}: I do not understand the expression '{text}'."
        )

    def check(node: ast.AST) -> None:
        if isinstance(node, ast.Expression):
            check(node.body)
            return
        if isinstance(node, ast.Constant) and isinstance(
            node.value, (str, int, float, bool, type(None))
        ):
            return
        if isinstance(node, ast.Name):
            return
        if isinstance(node, ast.Attribute):
            check(node.value)
            return
        if isinstance(node, ast.Call):
            check(node.func)
            for arg in node.args:
                check(arg)
            for keyword in node.keywords:
                check(keyword.value)
            return
        if isinstance(node, ast.List):
            for item in node.elts:
                check(item)
            return
        if isinstance(node, ast.Dict):
            for item in [*node.keys, *node.values]:
                if item:
                    check(item)
            return
        if isinstance(node, ast.Tuple):
            for item in node.elts:
                check(item)
            return
        if isinstance(node, ast.Subscript):
            check(node.value)
            check(node.slice)
            return
        if isinstance(node, ast.Slice):
            for item in (node.lower, node.upper, node.step):
                if item:
                    check(item)
            return
        if isinstance(node, ast.BinOp) and type(node.op) in ALLOWED_MATH_BINOPS:
            check(node.left)
            check(node.right)
            return
        if isinstance(node, ast.UnaryOp) and type(node.op) in ALLOWED_MATH_UNARYOPS:
            check(node.operand)
            return
        raise PlainError(
            f"Line {line_number}: expressions can use text, numbers, variables, lists, function calls, "
            "+, -, *, /, //, %, **, and parentheses."
        )

    check(tree)
    return text
    raise PlainError(
        f"Line {line_number}: I do not understand the expression '{text}'."
    )


def string_literal(text: str, line_number: int) -> str:
    text = text.strip()
    if not (
        (text.startswith('"') and text.endswith('"'))
        or (text.startswith("'") and text.endswith("'"))
    ):
        raise PlainError(f"Line {line_number}: expected quoted text.")
    try:
        value = ast.literal_eval(text)
    except (SyntaxError, ValueError):
        raise PlainError(f"Line {line_number}: quoted text is not closed correctly.")
    if not isinstance(value, str):
        raise PlainError(f"Line {line_number}: expected quoted text.")
    return repr(value)


def text_value(text: str, line_number: int) -> str:
    text = text.strip()
    if (text.startswith('"') and text.endswith('"')) or (
        text.startswith("'") and text.endswith("'")
    ):
        return string_literal(text, line_number)
    return repr(text)


def module_name(text: str, line_number: int) -> str:
    text = text.strip()
    if (text.startswith('"') and text.endswith('"')) or (
        text.startswith("'") and text.endswith("'")
    ):
        value = ast.literal_eval(string_literal(text, line_number))
    else:
        value = text
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*", value):
        raise PlainError(
            f"Line {line_number}: module names must look like math or package.module."
        )
    return value


def validate_math_expression(text: str, line_number: int) -> str:
    return expression(text, line_number)


def condition(text: str, line_number: int) -> str:
    type_check = re.fullmatch(r"(.+?) is (?:a )?(number|text|list|map)", text, flags=re.IGNORECASE)
    if type_check:
        value = expression(type_check.group(1), line_number)
        type_name = type_check.group(2).lower()
        type_map = {
            "number": "(int, float)",
            "text": "str",
            "list": "list",
            "map": "dict",
        }
        return f"isinstance({value}, {type_map[type_name]})"
    membership = re.fullmatch(r"(.+?) is in (.+)", text, flags=re.IGNORECASE)
    if membership:
        return f"{expression(membership.group(1), line_number)} in {expression(membership.group(2), line_number)}"
    not_membership = re.fullmatch(r"(.+?) is not in (.+)", text, flags=re.IGNORECASE)
    if not_membership:
        return f"{expression(not_membership.group(1), line_number)} not in {expression(not_membership.group(2), line_number)}"
    for phrase in sorted(COMPARISONS, key=len, reverse=True):
        marker = f" {phrase} "
        if marker in f" {text.lower()} ":
            left, right = re.split(
                re.escape(phrase), text, maxsplit=1, flags=re.IGNORECASE
            )
            left_expr = expression(left.strip(), line_number)
            op = COMPARISONS[phrase]
            if op in {"is True", "is False"}:
                return f"{left_expr} {op}"
            return f"{left_expr} {op} {expression(right.strip(), line_number)}"
    raise PlainError(
        f"Line {line_number}: condition must use words like 'is greater than' or 'equals'."
    )


def starts_block(text: str) -> bool:
    stripped = text.strip()
    if re.fullmatch(r"(?:Otherwise|If it fails):?", stripped, flags=re.IGNORECASE):
        return False
    return any(
        stripped.lower().startswith(starter.lower()) for starter in BLOCK_STARTERS
    )


def compile_line(line: SourceLine) -> tuple[str, bool]:
    text = line.text

    match = re.fullmatch(
        r"(?:Help|Show help|What can you do)", text, flags=re.IGNORECASE
    )
    if match:
        return f"print({VOCABULARY_TEXT!r})", False

    match = re.fullmatch(r"Help (.+)", text, flags=re.IGNORECASE)
    if match:
        topic = match.group(1).strip().lower()
        message = HELP_TOPICS.get(topic, f"No focused help exists for {topic!r}. Try: Show vocabulary.")
        return f"print({message!r})", False

    match = re.fullmatch(r"Show vocabulary", text, flags=re.IGNORECASE)
    if match:
        return f"print({VOCABULARY_TEXT!r})", False

    match = re.fullmatch(r"Show grid", text, flags=re.IGNORECASE)
    if match:
        return f"print({GRID_TEXT!r})", False

    match = re.fullmatch(r"(?:Show adapters|List adapters)", text, flags=re.IGNORECASE)
    if match:
        return f"print({ADAPTER_TEXT!r})", False

    match = re.fullmatch(r"Say (.+)", text, flags=re.IGNORECASE)
    if match:
        return f"print({expression(match.group(1), line.number)})", False

    match = re.fullmatch(r"(?:Stop|Exit|Quit)", text, flags=re.IGNORECASE)
    if match:
        return "raise SystemExit", False

    match = re.fullmatch(
        r"(?:Use module|Import module|Import|Use(?! Python:)) (.+?)(?: as (.+))?",
        text,
        flags=re.IGNORECASE,
    )
    if match:
        imported_module = module_name(match.group(1), line.number)
        alias = match.group(2)
        if alias:
            alias = to_identifier(alias, line.number)
            return f"_plain_import_module({imported_module!r}, {alias!r})", False
        return f"_plain_import_module({imported_module!r})", False

    match = re.fullmatch(r"Open(?: (.+))?", text, flags=re.IGNORECASE)
    if match:
        target = text_value(match.group(1) or ".", line.number)
        return f"_plain_open_target({target})", False

    match = re.fullmatch(
        r"Fetch (.+?) and remember (?:it|response|the response) as (.+)",
        text,
        flags=re.IGNORECASE,
    )
    if match:
        url = text_value(match.group(1), line.number)
        name = to_identifier(match.group(2), line.number)
        return f"{name} = _plain_fetch_url({url})", False

    match = re.fullmatch(r"Fetch (.+)", text, flags=re.IGNORECASE)
    if match:
        url = text_value(match.group(1), line.number)
        return f"print(_plain_fetch_url({url}))", False

    match = re.fullmatch(
        r"Post to (.+?) with body (.+?) and remember response as (.+)",
        text,
        flags=re.IGNORECASE,
    )
    if match:
        url = text_value(match.group(1), line.number)
        body = expression(match.group(2), line.number)
        name = to_identifier(match.group(3), line.number)
        return f"{name} = _plain_post_url({url}, {body})", False

    match = re.fullmatch(r"Create window (.+)", text, flags=re.IGNORECASE)
    if match:
        title = string_literal(match.group(1), line.number)
        return f"window = _plain_create_window({title})", False

    match = re.fullmatch(r"Add button (.+?) to window", text, flags=re.IGNORECASE)
    if match:
        label = string_literal(match.group(1), line.number)
        return f"_plain_add_button(window, {label})", False

    match = re.fullmatch(r"When button is clicked:?", text, flags=re.IGNORECASE)
    if match:
        return f"def _plain_button_handler_{line.number}():", True

    match = re.fullmatch(r"Add input (.+?) to window as (.+)", text, flags=re.IGNORECASE)
    if match:
        placeholder = string_literal(match.group(1), line.number)
        name = to_identifier(match.group(2), line.number)
        return f"{name} = _plain_add_input(window, {placeholder})", False

    match = re.fullmatch(r"Add label (.+?) to window", text, flags=re.IGNORECASE)
    if match:
        label = string_literal(match.group(1), line.number)
        return f"_plain_add_label(window, {label})", False

    match = re.fullmatch(r"Show window", text, flags=re.IGNORECASE)
    if match:
        return "_plain_show_window(window)", False

    match = re.fullmatch(r"Create web app (.+)", text, flags=re.IGNORECASE)
    if match:
        name = string_literal(match.group(1), line.number)
        return f"web_app = _plain_create_web_app({name})", False

    match = re.fullmatch(r"When someone visits (.+):?", text, flags=re.IGNORECASE)
    if match:
        route = string_literal(match.group(1).rstrip(":").strip(), line.number)
        return f"@web_app.route({route})\ndef _plain_route_{line.number}():", True

    match = re.fullmatch(r"Send page (.+)", text, flags=re.IGNORECASE)
    if match:
        page = expression(match.group(1), line.number)
        return f"return _plain_send_page({page})", False

    match = re.fullmatch(r"Start web app on port (.+)", text, flags=re.IGNORECASE)
    if match:
        port = expression(match.group(1), line.number)
        return f"_plain_start_web_app(web_app, {port})", False

    match = re.fullmatch(r"Connect to database (.+)", text, flags=re.IGNORECASE)
    if match:
        path = text_value(match.group(1), line.number)
        return f"_plain_connect_database({path})", False

    match = re.fullmatch(
        r"Ask database (.+?) and remember (?:rows|result|answer) as (.+)",
        text,
        flags=re.IGNORECASE,
    )
    if match:
        query = string_literal(match.group(1), line.number)
        name = to_identifier(match.group(2), line.number)
        return f"{name} = _plain_ask_database({query})", False

    match = re.fullmatch(r"Ask database (.+)", text, flags=re.IGNORECASE)
    if match:
        query = string_literal(match.group(1), line.number)
        return f"print(_plain_ask_database({query}))", False

    match = re.fullmatch(
        r"Scan(?: folder| directory)?(?: (.+?))? and remember (?:it|result|the result|output|the output) as (.+)",
        text,
        flags=re.IGNORECASE,
    )
    if match:
        target = text_value(match.group(1) or ".", line.number)
        name = to_identifier(match.group(2), line.number)
        return f"{name} = _plain_scan_target({target})", False

    match = re.fullmatch(
        r"Scan(?: folder| directory)?(?: (.+))?", text, flags=re.IGNORECASE
    )
    if match:
        target = text_value(match.group(1) or ".", line.number)
        return f"print(_plain_scan_target({target}))", False

    match = re.fullmatch(
        r"Read file (.+?) and remember (?:it|text|the text|content|the content) as (.+)",
        text,
        flags=re.IGNORECASE,
    )
    if match:
        target = text_value(match.group(1), line.number)
        name = to_identifier(match.group(2), line.number)
        return f"{name} = _plain_read_file({target})", False

    match = re.fullmatch(r"Read file (.+)", text, flags=re.IGNORECASE)
    if match:
        target = text_value(match.group(1), line.number)
        return f"print(_plain_read_file({target}))", False

    match = re.fullmatch(r"Write (.+?) to file (.+)", text, flags=re.IGNORECASE)
    if match:
        value = expression(match.group(1), line.number)
        target = text_value(match.group(2), line.number)
        return f"_plain_write_file({value}, {target})", False

    match = re.fullmatch(r"Copy (.+?) to (.+)", text, flags=re.IGNORECASE)
    if match:
        source = text_value(match.group(1), line.number)
        target = text_value(match.group(2), line.number)
        return f"_plain_copy_path({source}, {target})", False

    match = re.fullmatch(r"Move (.+?) to (.+)", text, flags=re.IGNORECASE)
    if match:
        source = text_value(match.group(1), line.number)
        target = text_value(match.group(2), line.number)
        return f"_plain_move_path({source}, {target})", False

    match = re.fullmatch(
        r"Delete (?:file|folder|directory)? ?(.+)", text, flags=re.IGNORECASE
    )
    if match:
        target = text_value(match.group(1), line.number)
        return f"_plain_delete_path({target})", False

    match = re.fullmatch(
        r"Insert (.+?) into file (.+?)(?: at (start|beginning|end))?",
        text,
        flags=re.IGNORECASE,
    )
    if match:
        value = text_value(match.group(1), line.number)
        target = text_value(match.group(2), line.number)
        position = (match.group(3) or "end").lower()
        return f"_plain_insert_file({value}, {target}, {position!r})", False

    match = re.fullmatch(
        r"Insert (.+?) into (.+?) at position (.+)", text, flags=re.IGNORECASE
    )
    if match:
        value = expression(match.group(1), line.number)
        name = to_identifier(match.group(2), line.number)
        position = validate_math_expression(match.group(3), line.number)
        return f"{name}.insert(int({position}), {value})", False

    match = re.fullmatch(r"Insert (.+?) into (.+)", text, flags=re.IGNORECASE)
    if match:
        value = expression(match.group(1), line.number)
        name = to_identifier(match.group(2), line.number)
        return f"{name}.append({value})", False

    match = re.fullmatch(r"Remove (.+?) from (.+)", text, flags=re.IGNORECASE)
    if match:
        value = expression(match.group(1), line.number)
        name = to_identifier(match.group(2), line.number)
        return f"{name}.remove({value})", False

    match = re.fullmatch(r"Sort (.+)", text, flags=re.IGNORECASE)
    if match:
        name = to_identifier(match.group(1), line.number)
        return f"{name}.sort()", False

    match = re.fullmatch(r"Reverse (.+)", text, flags=re.IGNORECASE)
    if match:
        name = to_identifier(match.group(1), line.number)
        return f"{name}.reverse()", False

    match = re.fullmatch(
        r"Run command (.+?) and remember output as (.+)", text, flags=re.IGNORECASE
    )
    if match:
        command = string_literal(match.group(1), line.number)
        name = to_identifier(match.group(2), line.number)
        return f"{name} = _plain_run_command({command})", False

    match = re.fullmatch(
        r"Run (Python|JavaScript|Node|Ruby|Perl|PHP|PowerShell) (.+?) and remember output as (.+)",
        text,
        flags=re.IGNORECASE,
    )
    if match:
        language = repr(match.group(1).lower())
        code = string_literal(match.group(2), line.number)
        name = to_identifier(match.group(3), line.number)
        return f"{name} = _plain_run_language({language}, {code})", False

    match = re.fullmatch(r"Run in parallel:?", text, flags=re.IGNORECASE)
    if match:
        return "if True:", True

    match = re.fullmatch(r"Run all tests", text, flags=re.IGNORECASE)
    if match:
        return "_plain_run_tests()", False

    match = re.fullmatch(
        r"Ask Claude (.+?) using (.+?) and remember answer as (.+)",
        text,
        flags=re.IGNORECASE,
    )
    if match:
        prompt = expression(match.group(1), line.number)
        context = expression(match.group(2), line.number)
        name = to_identifier(match.group(3), line.number)
        return f"{name} = _plain_ask_claude({prompt}, {context})", False

    match = re.fullmatch(
        r"Ask Claude (.+?) and remember answer as (.+)", text, flags=re.IGNORECASE
    )
    if match:
        prompt = expression(match.group(1), line.number)
        name = to_identifier(match.group(2), line.number)
        return f"{name} = _plain_ask_claude({prompt})", False

    match = re.fullmatch(r"Ask Claude (.+)", text, flags=re.IGNORECASE)
    if match:
        prompt = expression(match.group(1), line.number)
        return f"print(_plain_ask_claude({prompt}))", False

    match = re.fullmatch(
        r"Run (.+?) and remember (?:it|the answer|the result) as (.+)",
        text,
        flags=re.IGNORECASE,
    )
    if match:
        value = validate_math_expression(match.group(1), line.number)
        name = to_identifier(match.group(2), line.number)
        return f"{name} = {value}", False

    match = re.fullmatch(r"Run (.+)", text, flags=re.IGNORECASE)
    if match:
        value = validate_math_expression(match.group(1), line.number)
        return f"print({value})", False

    match = re.fullmatch(r"Remember (.+?) as (.+)", text, flags=re.IGNORECASE)
    if match:
        left = match.group(1).strip()
        right = match.group(2).strip()
        if right.lower() in {"empty stack", "a stack", "stack"}:
            name = to_identifier(left, line.number)
            return f"{name} = _plain_stack()", False
        if right.lower() in {"empty queue", "a queue", "queue"}:
            name = to_identifier(left, line.number)
            return f"{name} = _plain_queue()", False
        if right.lower() in {"empty map", "a map", "map", "empty dictionary", "dictionary"}:
            name = to_identifier(left, line.number)
            return f"{name} = {{}}", False
        if right.lower() in {"empty list", "a list", "list"}:
            name = to_identifier(left, line.number)
            return f"{name} = []", False
        if re.fullmatch(
            r"[A-Za-z_][A-Za-z0-9_]*(\s+[A-Za-z_][A-Za-z0-9_]*)*", right
        ) and not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", left):
            name = to_identifier(right, line.number)
            return f"{name} = {expression(left, line.number)}", False
        name = to_identifier(left, line.number)
        return f"{name} = {expression(right, line.number)}", False

    match = re.fullmatch(r"Push (.+?) onto (.+)", text, flags=re.IGNORECASE)
    if match:
        value = expression(match.group(1), line.number)
        name = to_identifier(match.group(2), line.number)
        return f"_plain_push({name}, {value})", False

    match = re.fullmatch(r"Pop from (.+?) and remember it as (.+)", text, flags=re.IGNORECASE)
    if match:
        stack = to_identifier(match.group(1), line.number)
        name = to_identifier(match.group(2), line.number)
        return f"{name} = _plain_pop({stack})", False

    match = re.fullmatch(r"Enqueue (.+?) into (.+)", text, flags=re.IGNORECASE)
    if match:
        value = expression(match.group(1), line.number)
        name = to_identifier(match.group(2), line.number)
        return f"_plain_enqueue({name}, {value})", False

    match = re.fullmatch(r"Dequeue from (.+?) and remember it as (.+)", text, flags=re.IGNORECASE)
    if match:
        queue = to_identifier(match.group(1), line.number)
        name = to_identifier(match.group(2), line.number)
        return f"{name} = _plain_dequeue({queue})", False

    match = re.fullmatch(r"Set (.+?) (.+?) to (.+)", text, flags=re.IGNORECASE)
    if match:
        name = to_identifier(match.group(1), line.number)
        key = string_literal(match.group(2), line.number)
        value = expression(match.group(3), line.number)
        return f"{name}[{key}] = {value}", False

    match = re.fullmatch(r"Set (.+?) to (.+)", text, flags=re.IGNORECASE)
    if match:
        name = to_identifier(match.group(1), line.number)
        return f"{name} = {expression(match.group(2), line.number)}", False

    match = re.fullmatch(r"Make sure (.+?) is (?:a )?(number|text|list|map)", text, flags=re.IGNORECASE)
    if match:
        value = expression(match.group(1), line.number)
        type_name = match.group(2).lower()
        type_map = {
            "number": "(int, float)",
            "text": "str",
            "list": "list",
            "map": "dict",
        }
        return (
            f"({value} if isinstance({value}, {type_map[type_name]}) "
            f"else (_ for _ in ()).throw(ValueError('{match.group(1)} must be a {type_name}')))"
        ), False

    match = re.fullmatch(r"Make sure (.+)", text, flags=re.IGNORECASE)
    if match:
        return f"_plain_make_sure({condition(match.group(1), line.number)}, {match.group(1)!r})", False

    match = re.fullmatch(
        r"Ask (.+?) and remember it as (.+)", text, flags=re.IGNORECASE
    )
    if match:
        prompt = expression(match.group(1), line.number)
        name = to_identifier(match.group(2), line.number)
        return f"{name} = input({prompt})", False

    match = re.fullmatch(r"Add (.+?) to (.+)", text, flags=re.IGNORECASE)
    if match:
        value = expression(match.group(1), line.number)
        name = to_identifier(match.group(2), line.number)
        return f"{name} += {value}", False

    match = re.fullmatch(r"Subtract (.+?) from (.+)", text, flags=re.IGNORECASE)
    if match:
        value = expression(match.group(1), line.number)
        name = to_identifier(match.group(2), line.number)
        return f"{name} -= {value}", False

    match = re.fullmatch(r"Multiply (.+?) by (.+)", text, flags=re.IGNORECASE)
    if match:
        name = to_identifier(match.group(1), line.number)
        value = expression(match.group(2), line.number)
        return f"{name} *= {value}", False

    match = re.fullmatch(r"Divide (.+?) by (.+)", text, flags=re.IGNORECASE)
    if match:
        name = to_identifier(match.group(1), line.number)
        value = expression(match.group(2), line.number)
        return f"{name} /= {value}", False

    match = re.fullmatch(r"Repeat (.+?) times:?", text, flags=re.IGNORECASE)
    if match:
        count = match.group(1).rstrip(":").strip()
        return f"for _ in range(int({expression(count, line.number)})):", True

    match = re.fullmatch(r"Every (.+?) seconds:?", text, flags=re.IGNORECASE)
    if match:
        seconds = expression(match.group(1).rstrip(":").strip(), line.number)
        return f"def _plain_every_handler_{line.number}():", True

    match = re.fullmatch(r"When file (.+?) changes:?", text, flags=re.IGNORECASE)
    if match:
        return f"def _plain_file_change_handler_{line.number}():", True

    match = re.fullmatch(r"In the background:?", text, flags=re.IGNORECASE)
    if match:
        return f"def _plain_background_task_{line.number}():\n    global data", True


    match = re.fullmatch(r"Task (.+?):?", text, flags=re.IGNORECASE)
    if match:
        name = to_identifier(f"task_{match.group(1)}_{line.number}", line.number)
        return f"def _plain_{name}():", True

    match = re.fullmatch(r"Test (.+?):?", text, flags=re.IGNORECASE)
    if match:
        test_name = string_literal(match.group(1), line.number)
        return f"def _plain_test_{line.number}():", True

    match = re.fullmatch(r"For each (.+?) in (.+):?", text, flags=re.IGNORECASE)
    if match:
        name = to_identifier(match.group(1), line.number)
        items = expression(match.group(2).rstrip(":").strip(), line.number)
        return f"for {name} in {items}:", True

    match = re.fullmatch(r"While (.+):?", text, flags=re.IGNORECASE)
    if match:
        return (
            f"while {condition(match.group(1).rstrip(':').strip(), line.number)}:",
            True,
        )

    match = re.fullmatch(r"Try:?", text, flags=re.IGNORECASE)
    if match:
        return "try:", True

    match = re.fullmatch(r"Wait for background tasks", text, flags=re.IGNORECASE)
    if match:
        return "_plain_wait_background_tasks()", False


    match = re.fullmatch(r"Connect to server (.+?) on port (.+)", text, flags=re.IGNORECASE)
    if match:
        host = string_literal(match.group(1), line.number)
        port = expression(match.group(2), line.number)
        return f"_plain_connect_server({host}, {port})", False

    match = re.fullmatch(r"Send (.+?) to server", text, flags=re.IGNORECASE)
    if match:
        message = expression(match.group(1), line.number)
        return f"_plain_send_server({message})", False

    match = re.fullmatch(r"Listen for messages on port (.+)", text, flags=re.IGNORECASE)
    if match:
        port = expression(match.group(1), line.number)
        return f"_plain_listen_messages({port})", False

    match = re.fullmatch(r"If it fails:?", text, flags=re.IGNORECASE)
    if match:
        return "except Exception as error:", False

    match = re.fullmatch(r"If (.+)", text, flags=re.IGNORECASE)
    if match:
        return f"if {condition(match.group(1).rstrip(':').strip(), line.number)}:", True

    match = re.fullmatch(r"Otherwise:?", text, flags=re.IGNORECASE)
    if match:
        return "else:", False

    match = re.fullmatch(r"Define type (.+?) using (.*)", text, flags=re.IGNORECASE)
    if match:
        name = to_identifier(match.group(1), line.number)
        fields = [to_identifier(part, line.number) for part in re.split(r"\s*,\s*", match.group(2).rstrip(":").strip())]
        assigns = "\n".join(f"        self.{field} = {field}" for field in fields)
        return f"class {name}:\n    def __init__(self, {', '.join(fields)}):\n{assigns}", True

    match = re.fullmatch(r"Define (.+?) using (.*)", text, flags=re.IGNORECASE)
    if match:
        name = to_identifier(match.group(1), line.number)
        args = match.group(2).rstrip(":").strip()
        if line.indent > 0:
            if args.lower() in {"nothing", "no inputs", ""}:
                return f"def {name}(self):", True
            identifiers = [to_identifier(part, line.number) for part in re.split(r"\s*,\s*", args)]
            return f"def {name}(self, {', '.join(identifiers)}):", True
        if args.lower() in {"nothing", "no inputs", ""}:
            return f"def {name}():", True
        identifiers = [
            to_identifier(part, line.number) for part in re.split(r"\s*,\s*", args)
        ]
        return f"def {name}({', '.join(identifiers)}):", True

    match = re.fullmatch(r"Return (.+)", text, flags=re.IGNORECASE)
    if match:
        return f"return {expression(match.group(1), line.number)}", False

    match = re.fullmatch(r"Call (.+)", text, flags=re.IGNORECASE)
    if match:
        return f"{expression(match.group(1), line.number)}", False

    match = re.fullmatch(r"Use Python:?\s*(.*)", text, flags=re.IGNORECASE)
    if match:
        code = match.group(1).strip()
        if not code:
            raise PlainError(
                f"Line {line.number}: put Python code after 'Use Python:'."
            )
        forbidden = ("import ", "__", "exec(", "eval(", "open(", "subprocess", "socket")
        if any(part in code for part in forbidden):
            raise PlainError(
                f"Line {line.number}: direct Python escape cannot import modules, open files, "
                "or execute system commands in safe mode."
            )
        return code, False

    raise PlainError(
        f"Line {line.number}: I do not know how to run '{line.text}'. Try phrases like "
        "'Say \"hello\"', 'Run 2+3', 'Import math', or 'Run math.sqrt(81)'."
    )


def transpile(
    source: str,
    *,
    allow_imports: bool = False,
    allow_system: bool = False,
    base_dir: Path | None = None,
) -> str:
    source = expand_plain_imports(source, base_dir)
    lines = normalize_source(source)
    output = [
        "# Generated by Plain. Edit the .plain file, then rebuild.",
        RUNTIME_HELPERS.replace("__ALLOW_IMPORTS__", repr(allow_imports))
        .replace("__ALLOW_SYSTEM__", repr(allow_system))
        .replace("__SAFE_MODULES__", repr(sorted(SAFE_MODULES)))
        .strip(),
        "",
    ]
    block_stack: list[SourceLine] = []
    parallel_stack: list[list[str]] = []

    for line in lines:
        if line.text.lower() == "end":
            if not block_stack:
                raise PlainError(
                    f"Line {line.number}: 'End' does not match an open block."
                )
            if line.indent != block_stack[-1].indent:
                opener = block_stack[-1]
                raise PlainError(
                    f"Line {line.number}: 'End' should line up with line {opener.number}: '{opener.text}'."
                )
            opener = block_stack.pop()
            opener_text = opener.text.rstrip(":")
            lower_opener = opener_text.lower()
            if lower_opener == "when button is clicked":
                output.append(("    " * opener.indent) + f"_plain_set_last_button_command(_plain_button_handler_{opener.number})")
            elif lower_opener.startswith("every "):
                seconds = re.fullmatch(r"Every (.+?) seconds:?", opener.text, flags=re.IGNORECASE).group(1)
                output.append(("    " * opener.indent) + f"_plain_every({expression(seconds, opener.number)}, _plain_every_handler_{opener.number})")
            elif lower_opener.startswith("when file "):
                file_match = re.fullmatch(r"When file (.+?) changes:?", opener.text, flags=re.IGNORECASE)
                output.append(("    " * opener.indent) + f"_plain_watch_file({text_value(file_match.group(1), opener.number)}, _plain_file_change_handler_{opener.number})")
            elif lower_opener == "in the background":
                output.append(("    " * opener.indent) + f"_plain_start_background(_plain_background_task_{opener.number})")
            elif lower_opener.startswith("task "):
                if parallel_stack:
                    task_match = re.fullmatch(r"Task (.+?):?", opener.text, flags=re.IGNORECASE)
                    task_name = to_identifier(f"task_{task_match.group(1)}_{opener.number}", opener.number)
                    parallel_stack[-1].append(f"_plain_{task_name}")
            elif lower_opener == "run in parallel":
                tasks = parallel_stack.pop() if parallel_stack else []
                output.append(("    " * opener.indent) + f"_plain_run_parallel({', '.join(tasks)})")
            elif lower_opener.startswith("test "):
                test_match = re.fullmatch(r"Test (.+?):?", opener.text, flags=re.IGNORECASE)
                output.append(("    " * opener.indent) + f"_plain_register_test({string_literal(test_match.group(1), opener.number)}, _plain_test_{opener.number})")
            continue

        is_otherwise = (
            re.fullmatch(r"Otherwise:?", line.text, flags=re.IGNORECASE) is not None
        )
        is_failure = (
            re.fullmatch(r"If it fails:?", line.text, flags=re.IGNORECASE) is not None
        )
        if block_stack:
            opener = block_stack[-1]
            if is_otherwise or is_failure:
                if is_otherwise and not opener.text.lower().startswith("if "):
                    raise PlainError(
                        f"Line {line.number}: 'Otherwise' can only be used inside an If block."
                    )
                if is_failure and not opener.text.lower().startswith("try"):
                    raise PlainError(
                        f"Line {line.number}: 'If it fails' can only be used inside a Try block."
                    )
                if line.indent != opener.indent:
                    branch = "Otherwise" if is_otherwise else "If it fails"
                    raise PlainError(
                        f"Line {line.number}: '{branch}' should line up with line {opener.number}."
                    )
            elif line.indent <= opener.indent:
                raise PlainError(
                    f"Line {line.number}: close the block from line {opener.number} with 'End' before this sentence."
                )
            elif line.indent > opener.indent + 1:
                raise PlainError(
                    f"Line {line.number}: indentation jumped too far. Use two spaces per block level."
                )
        elif line.indent > 0:
            raise PlainError(
                f"Line {line.number}: this line is indented, but no block is open."
            )

        code, opens_block = compile_line(line)
        output.append(("    " * line.indent) + code)
        if opens_block:
            block_stack.append(line)
            if re.fullmatch(r"Run in parallel:?", line.text, flags=re.IGNORECASE):
                parallel_stack.append([])

    if block_stack:
        opener = block_stack[-1]
        raise PlainError(
            f"Program ended before the block from line {opener.number} had an 'End': '{opener.text}'."
        )
    return "\n".join(output) + "\n"


def run_plain(
    path: Path,
    *,
    unsafe: bool = False,
    allow_imports: bool = False,
    allow_system: bool = False,
) -> None:
    python_code = transpile(
        path.read_text(encoding="utf-8"),
        allow_imports=allow_imports,
        allow_system=allow_system,
        base_dir=path.parent,
    )
    globals_dict = {"__builtins__": __builtins__ if unsafe else SAFE_BUILTINS, "__name__": "__main__"}
    exec(compile(python_code, str(path), "exec"), globals_dict, globals_dict)


def run_sentence(
    sentence: str,
    *,
    unsafe: bool = False,
    allow_imports: bool = False,
    allow_system: bool = False,
) -> None:
    source = sentence.strip()
    if not source.endswith("."):
        source = f"{source}."
    python_code = transpile(
        source, allow_imports=allow_imports, allow_system=allow_system
    )
    globals_dict = {"__builtins__": __builtins__ if unsafe else SAFE_BUILTINS, "__name__": "__main__"}
    exec(compile(python_code, "<plain sentence>", "exec"), globals_dict, globals_dict)


def run_repl(
    *, unsafe: bool = False, allow_imports: bool = False, allow_system: bool = False
) -> None:
    print("Svans platform. Type sentence commands, or type Stop to leave.")
    if unsafe and allow_imports and allow_system:
        print(
            "Trusted mode is on. Svans can use system commands, imports, and full Python builtins."
        )
        print(
            "One-room mode is on. If Svans does not understand a line, it will try it as a system command."
        )
    print('Example: Say "hello Shawn".')
    globals_dict = {"__builtins__": __builtins__ if unsafe else SAFE_BUILTINS, "__name__": "__main__"}
    block_buffer: list[str] = []
    block_depth = 0

    while True:
        try:
            prompt = ".....> " if block_buffer else "Svans> "
            line = input(prompt).rstrip()
        except (EOFError, KeyboardInterrupt):
            print()
            return

        command = line.strip()
        if not command:
            continue
        if not block_buffer and command.lower() in {"exit", "exit.", "quit", "quit."}:
            return
        if (
            not block_buffer
            and re.match(r"^(python|py)\s+plain\.py\b", command, flags=re.IGNORECASE)
            and not allow_system
        ):
            print(
                "That is a PowerShell command. Restart Plain with --trusted to run it here."
            )
            continue

        if block_buffer:
            block_buffer.append(line)
            if starts_block(command):
                block_depth += 1
            if command.lower() in {"end", "end."}:
                block_depth -= 1
            if block_depth > 0:
                continue
            source = "\n".join(block_buffer)
            block_buffer = []
        elif starts_block(command):
            block_buffer = [line]
            block_depth = 1
            continue
        else:
            source = command if command.endswith(".") else f"{command}."

        try:
            python_code = transpile(
                source,
                allow_imports=allow_imports,
                allow_system=allow_system,
                base_dir=Path.cwd(),
            )
            exec(
                compile(python_code, "<plain shell>", "exec"),
                globals_dict,
                globals_dict,
            )
        except PlainError as error:
            if allow_system:
                completed = subprocess.run(
                    line, shell=True, text=True, capture_output=True
                )
                if completed.stdout:
                    print(
                        completed.stdout,
                        end="" if completed.stdout.endswith("\n") else "\n",
                    )
                if completed.stderr:
                    print(
                        completed.stderr,
                        end="" if completed.stderr.endswith("\n") else "\n",
                    )
                if completed.returncode != 0 and not completed.stderr:
                    print(f"Command failed with exit code {completed.returncode}")
            else:
                print(f"Plain error: {error}")
        except Exception as error:
            print(f"Runtime error: {error}")


def format_source(source: str) -> str:
    starters = {
        "say": "Say",
        "run": "Run",
        "remember": "Remember",
        "set": "Set",
        "add": "Add",
        "subtract": "Subtract",
        "multiply": "Multiply",
        "divide": "Divide",
        "repeat": "Repeat",
        "for each": "For each",
        "while": "While",
        "if it fails": "If it fails",
        "if": "If",
        "otherwise": "Otherwise",
        "try": "Try",
        "end": "End",
        "define": "Define",
        "return": "Return",
        "call": "Call",
        "import": "Import",
        "use": "Use",
        "open": "Open",
        "scan": "Scan",
        "fetch": "Fetch",
        "post": "Post",
        "connect": "Connect",
        "ask": "Ask",
        "write": "Write",
        "read": "Read",
        "copy": "Copy",
        "move": "Move",
        "delete": "Delete",
        "insert": "Insert",
        "remove": "Remove",
        "sort": "Sort",
        "reverse": "Reverse",
        "make sure": "Make sure",
        "help": "Help",
        "show": "Show",
        "stop": "Stop",
    }
    output: list[str] = []
    for raw in source.splitlines():
        if not raw.strip() or raw.strip().startswith("#"):
            output.append(raw.rstrip())
            continue
        indent = raw[: len(raw) - len(raw.lstrip(" "))]
        text = re.sub(r"\s+", " ", raw.strip())
        lower = text.lower()
        for key in sorted(starters, key=len, reverse=True):
            if lower == key or lower.startswith(key + " "):
                text = starters[key] + text[len(key) :]
                break
        if not text.endswith((".", ":")):
            text += "."
        output.append(indent + text)
    return "\n".join(output).rstrip() + "\n"


def check_file(path: Path, *, allow_imports: bool = True, allow_system: bool = True) -> list[str]:
    try:
        python_code = transpile(
            path.read_text(encoding="utf-8"),
            allow_imports=allow_imports,
            allow_system=allow_system,
            base_dir=path.parent,
        )
        compile(python_code, str(path), "exec")
    except PlainError as error:
        return [str(error)]
    except SyntaxError as error:
        return [f"Generated Python syntax error: {error}"]
    return []


def scaffold_project(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    (path / "helpers.plain").write_text(
        'Define greet using name:\n  Return "Hello {name}".\nEnd.\n',
        encoding="utf-8",
    )
    (path / "main.plain").write_text(
        'Use "helpers.plain".\n\nRemember name as "Svans".\n'
        'Remember message as greet(name).\nSay message.\n',
        encoding="utf-8",
    )
    (path / "README.md").write_text(
        f"# {path.name}\n\nRun this project with:\n\n```powershell\nsvans main.plain\n```\n",
        encoding="utf-8",
    )


def cli() -> int:
    return main(sys.argv[1:])


def main(argv: list[str]) -> int:
    if argv and argv[0].lower().endswith(".plain"):
        argv = ["run", *argv]

    parser = argparse.ArgumentParser(
        description="Plain sentence-style programming language"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    build = subparsers.add_parser("build", help="print generated Python")
    build.add_argument("file", type=Path)
    build.add_argument(
        "-o", "--output", type=Path, help="write generated Python to this file"
    )
    build.add_argument(
        "--trusted",
        action="store_true",
        help="enable unsafe, imports, and system access",
    )
    build.add_argument(
        "--allow-imports",
        action="store_true",
        help="allow generated Python to import any installed module",
    )
    build.add_argument(
        "--allow-system",
        action="store_true",
        help="allow generated Python to run commands",
    )

    version = subparsers.add_parser("version", help="print Svans version")

    new = subparsers.add_parser("new", help="create a starter Svans project")
    new.add_argument("folder", type=Path)

    check = subparsers.add_parser("check", help="validate a Plain file without running it")
    check.add_argument("file", type=Path)

    fmt = subparsers.add_parser("format", help="format a Plain file in place")
    fmt.add_argument("file", type=Path)

    install = subparsers.add_parser("install", help="install a Svans package marker")
    install.add_argument("package")

    publish = subparsers.add_parser("publish", help="prepare a Svans package for publishing")
    publish.add_argument("package")

    run = subparsers.add_parser("run", help="run a Plain program")
    run.add_argument("file", type=Path)
    run.add_argument(
        "--trusted",
        action="store_true",
        help="enable unsafe, imports, and system access",
    )
    run.add_argument(
        "--unsafe", action="store_true", help="allow generated Python full builtins"
    )
    run.add_argument(
        "--allow-imports",
        action="store_true",
        help="allow trusted Plain programs to import any installed module",
    )
    run.add_argument(
        "--allow-system",
        action="store_true",
        help="allow trusted Plain programs to run commands",
    )

    shell = subparsers.add_parser("shell", help="start an interactive Plain prompt")
    shell.add_argument(
        "--trusted",
        action="store_true",
        help="enable unsafe, imports, and system access",
    )
    shell.add_argument(
        "--unsafe", action="store_true", help="allow generated Python full builtins"
    )
    shell.add_argument(
        "--allow-imports",
        action="store_true",
        help="allow trusted Plain sentences to import any installed module",
    )
    shell.add_argument(
        "--allow-system",
        action="store_true",
        help="allow trusted Plain sentences to run commands",
    )

    do = subparsers.add_parser(
        "do", help="run one Plain sentence from the command line"
    )
    do.add_argument("sentence")
    do.add_argument(
        "--trusted",
        action="store_true",
        help="enable unsafe, imports, and system access",
    )
    do.add_argument(
        "--unsafe", action="store_true", help="allow generated Python full builtins"
    )
    do.add_argument(
        "--allow-imports",
        action="store_true",
        help="allow trusted Plain sentence to import any installed module",
    )
    do.add_argument(
        "--allow-system",
        action="store_true",
        help="allow trusted Plain sentence to use system access",
    )

    args = parser.parse_args(argv)
    trusted = getattr(args, "trusted", False)
    unsafe = getattr(args, "unsafe", False) or trusted
    allow_imports = getattr(args, "allow_imports", False) or trusted
    allow_system = getattr(args, "allow_system", False) or trusted
    try:
        if args.command == "version":
            print(f"Svans {VERSION}")
        elif args.command == "new":
            scaffold_project(args.folder)
            print(f"Created Svans project at {args.folder}")
        elif args.command == "check":
            errors = check_file(args.file)
            if errors:
                for error in errors:
                    print(f"Plain error: {error}", file=sys.stderr)
                return 1
            print(f"{args.file} is valid.")
        elif args.command == "format":
            args.file.write_text(format_source(args.file.read_text(encoding="utf-8")), encoding="utf-8")
            print(f"Formatted {args.file}.")
        elif args.command == "install":
            package_dir = Path.home() / ".svans" / "packages"
            package_dir.mkdir(parents=True, exist_ok=True)
            (package_dir / f"{args.package}.txt").write_text(f"{args.package}\n", encoding="utf-8")
            print(f"Installed {args.package}.")
        elif args.command == "publish":
            target = Path(args.package)
            if not target.exists():
                raise PlainError(f"Package path does not exist: {target}")
            print(f"Package {target} is ready to publish.")
        elif args.command == "build":
            python_code = transpile(
                args.file.read_text(encoding="utf-8"),
                allow_imports=allow_imports,
                allow_system=allow_system,
                base_dir=args.file.parent,
            )
            if args.output:
                args.output.write_text(python_code, encoding="utf-8")
            else:
                print(python_code, end="")
        elif args.command == "run":
            run_plain(
                args.file,
                unsafe=unsafe,
                allow_imports=allow_imports,
                allow_system=allow_system,
            )
        elif args.command == "shell":
            run_repl(
                unsafe=unsafe, allow_imports=allow_imports, allow_system=allow_system
            )
        elif args.command == "do":
            run_sentence(
                args.sentence,
                unsafe=unsafe,
                allow_imports=allow_imports,
                allow_system=allow_system,
            )
    except PlainError as error:
        print(f"Plain error: {error}", file=sys.stderr)
        return 1
    except Exception as error:
        print(f"Svans runtime error: {error}", file=sys.stderr)
        if "ANTHROPIC_API_KEY" in str(error):
            print(
                "Suggestion: set ANTHROPIC_API_KEY before using Ask Claude.",
                file=sys.stderr,
            )
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))

