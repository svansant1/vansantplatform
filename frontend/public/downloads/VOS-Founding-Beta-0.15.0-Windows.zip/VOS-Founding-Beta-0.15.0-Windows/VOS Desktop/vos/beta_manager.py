"""Local-first founding-beta enrollment, metrics, readiness, and deletion."""

from __future__ import annotations

import json
import secrets
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
CONFIG = ROOT / "config" / "beta_program.json"
TELEMETRY = ROOT / "runtime" / "beta_telemetry.jsonl"
REQUIRED_JOURNEYS = {"desktop-launch", "protection-review", "incident-review", "support-bundle", "backup-recovery"}


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load() -> dict[str, Any]:
    try:
        return json.loads(CONFIG.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def save(value: dict[str, Any]) -> None:
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    CONFIG.write_text(json.dumps(value, indent=2), encoding="utf-8")


def record(event: str, details: dict[str, Any] | None = None) -> None:
    TELEMETRY.parent.mkdir(parents=True, exist_ok=True)
    with TELEMETRY.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps({"at": now(), "event": event, "details": details or {}}) + "\n")


def enroll(privacy: bool, limitations: bool, diagnostics: bool) -> dict[str, Any]:
    if not privacy or not limitations:
        raise ValueError("Privacy notice and current product limitations must both be accepted.")
    config = load()
    config.update({
        "enrolled": True, "device_id": config.get("device_id") or secrets.token_hex(12),
        "enrolled_at": config.get("enrolled_at") or now(),
        "consent": {"privacy_notice": privacy, "limitations": limitations, "local_diagnostics": diagnostics},
        "telemetry": {"mode": "local-only", "automatic_upload": False},
    })
    save(config); record("beta-enrolled", {"local_diagnostics": diagnostics})
    return config


def events() -> list[dict[str, Any]]:
    if not TELEMETRY.exists(): return []
    output = []
    for line in TELEMETRY.read_text(encoding="utf-8", errors="replace").splitlines():
        try: output.append(json.loads(line))
        except ValueError: pass
    return output


def guardian_status() -> dict[str, Any]:
    try:
        token = (ROOT / "runtime" / "guardian.token").read_text(encoding="utf-8").strip()
        request = urllib.request.Request("http://127.0.0.1:8765/v1/health", headers={"Authorization": f"Bearer {token}"})
        with urllib.request.urlopen(request, timeout=3) as response: return json.loads(response.read().decode())
    except Exception as exc: return {"status": "unavailable", "error": str(exc)}


def readiness() -> dict[str, Any]:
    config = load(); history = events(); completed = {item.get("details", {}).get("name") for item in history if item.get("event") == "journey-completed"}
    enrolled_at = config.get("enrolled_at")
    hours = 0.0
    if enrolled_at:
        try: hours = (datetime.now(timezone.utc) - datetime.fromisoformat(enrolled_at)).total_seconds() / 3600
        except ValueError: pass
    health = guardian_status()
    gates = {
        "enrolled_with_consent": bool(config.get("enrolled") and config.get("consent", {}).get("privacy_notice") and config.get("consent", {}).get("limitations")),
        "guardian_available": bool(health.get("ok")) or health.get("status") == "ok",
        "all_journeys_completed": REQUIRED_JOURNEYS.issubset(completed),
        "minimum_72_operating_hours": hours >= 72,
        "invited_users_observed": int(config.get("invited_user_count", 0)) >= 3,
        "no_unresolved_critical_defects": int(config.get("unresolved_critical_defects", 0)) == 0,
    }
    return {
        "launch_ready": gates["enrolled_with_consent"] and gates["guardian_available"] and gates["no_unresolved_critical_defects"],
        "beta_validated": all(gates.values()),
        "gates": gates,
        "operating_hours": round(hours, 2),
        "completed_journeys": sorted(item for item in completed if item),
        "missing_journeys": sorted(REQUIRED_JOURNEYS - completed),
        "guardian": health,
    }


def delete_local_data() -> None:
    if TELEMETRY.exists(): TELEMETRY.unlink()
    save({"schema_version": 1, "enrolled": False, "invited_user_count": 0, "unresolved_critical_defects": 0})
