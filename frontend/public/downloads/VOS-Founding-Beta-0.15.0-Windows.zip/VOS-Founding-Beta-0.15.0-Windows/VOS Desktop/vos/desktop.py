#!/usr/bin/env python3
"""VOS Desktop: a graphical Vansant Operating System shell."""

from __future__ import annotations

import argparse
import contextlib
import importlib.util
import io
import json
import subprocess
import sys
import tkinter as tk
import traceback
import urllib.request
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog
from tkinter import ttk
from PIL import Image, ImageTk

ROOT = Path(__file__).resolve().parents[1]
VOS_DIR = ROOT / "vos"
USER_DIR = VOS_DIR / "user"
APPS_DIR = VOS_DIR / "apps"

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import plain
import beta_manager
import operations_ui
import store_apps
from managed_windows import WindowManager
from guardian_client import GuardianClient, GuardianError

_vos_spec = importlib.util.spec_from_file_location("vos_shell", VOS_DIR / "vos.py")
if _vos_spec is None or _vos_spec.loader is None:
    raise RuntimeError("Could not load VOS shell.")
_vos_shell = importlib.util.module_from_spec(_vos_spec)
_vos_spec.loader.exec_module(_vos_shell)
VOS = _vos_shell.VOS
VOS_VERSION = _vos_shell.VOS_VERSION

DESKTOP_VERSION = "0.15.0"

THEME = {
    "wallpaper_top": "#070910",
    "wallpaper_mid": "#0b1020",
    "wallpaper_bottom": "#15102a",
    "ink": "#f8fafc",
    "muted": "#94a3b8",
    "panel": "#0b1020",
    "surface": "#111827",
    "taskbar": "#06080d",
    "taskbar_alt": "#151a27",
    "accent": "#8b5cf6",
}

APP_TILES = {
    "Files": "#2c7be5",
    "Notes": "#f4b400",
    "Calculator": "#00a884",
    "Terminal": "#202735",
    "SVANSAI Guide": "#7c3aed",
    "SV Browser": "#0ea5e9",
    "App Store": "#ef476f",
    "Settings": "#64748b",
    "Projects": "#06b6d4",
    "Sandbox": "#22c55e",
    "Shield": "#e11d48",
    "Debugger": "#8b5cf6",
    "Guardian Core": "#0f766e",
    "Incident Center": "#b91c1c",
    "Network Armor": "#0369a1",
    "Beta Center": "#a16207",
}

PROJECT_ICONS = {
    "SVANSAI Guide": ROOT.parent / "VOS Platform" / "svansai_guide" / "frontend" / "public" / "mascot" / "sv-robot.png",
    "Sandbox": ROOT.parent / "VOS Platform" / "sandbox_armor" / "assets" / "icon.ico",
    "Shield": ROOT.parent / "VOS Platform" / "file_armor" / "desktop" / "icon.ico",
    "Debugger": ROOT.parent / "VOS Platform" / "debugger_guide" / "assets" / "icon.ico",
    "SV Browser": ROOT.parent / "SV Browser" / "Assets" / "sv-browser.ico",
}


class VOSDesktop:
    THEME = THEME

    def __init__(self) -> None:
        USER_DIR.mkdir(parents=True, exist_ok=True)
        (USER_DIR / "apps").mkdir(parents=True, exist_ok=True)
        self.vos = VOS()
        self.guardian = GuardianClient()
        self.guardian_status = "starting"
        self.guardian_error = ""
        try:
            self.guardian.ensure_started()
            self.guardian.heartbeat("vos-desktop", version=DESKTOP_VERSION)
            self.guardian_status = "online"
        except GuardianError as error:
            self.guardian_status = "offline"
            self.guardian_error = str(error)
        if beta_manager.load().get("enrolled"):
            beta_manager.record("journey-completed", {"name": "desktop-launch"})
        self.root = tk.Tk()
        self.root.report_callback_exception = self._report_callback_exception
        self.root.title("Vansant OS")
        self.root.geometry("1100x700")
        self.root.minsize(900, 560)
        self.root.configure(bg=THEME["wallpaper_top"])
        self._icon_cache: dict[tuple[str, int], ImageTk.PhotoImage] = {}
        self._start_menu: tk.Frame | None = None
        self._guide_server = None
        self.root.protocol("WM_DELETE_WINDOW", self._shutdown)
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure("Treeview", background=THEME["surface"], fieldbackground=THEME["surface"], foreground=THEME["ink"], borderwidth=0, rowheight=28)
        style.configure("Treeview.Heading", background=THEME["taskbar_alt"], foreground=THEME["ink"], relief="flat")
        style.map("Treeview", background=[("selected", THEME["accent"])], foreground=[("selected", "white")])
        self._build_shell()
        self.root.after(5000, self._guardian_tick)

    def _report_callback_exception(self, exception_type, exception, trace) -> None:
        record = {
            "at": beta_manager.now(),
            "type": getattr(exception_type, "__name__", str(exception_type)),
            "message": str(exception)[:1000],
            "traceback": "".join(traceback.format_exception(exception_type, exception, trace))[-20000:],
        }
        crash_path = ROOT.parent / "runtime" / "desktop_crashes.jsonl"
        crash_path.parent.mkdir(parents=True, exist_ok=True)
        with crash_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record) + "\n")
        beta = beta_manager.load()
        if beta.get("enrolled") and beta.get("consent", {}).get("local_diagnostics"):
            beta_manager.record("desktop-crash", {"type": record["type"], "message": record["message"]})
        messagebox.showerror("VOS Desktop", f"An unexpected error was recorded locally.\n\n{record['type']}: {record['message']}")

    def _build_shell(self) -> None:
        self.desktop = tk.Canvas(self.root, highlightthickness=0, bd=0)
        self.desktop.pack(fill="both", expand=True)
        self.desktop.bind("<Configure>", self._paint_wallpaper)

        title = tk.Label(
            self.desktop,
            text="VANSANT OS",
            bg=THEME["wallpaper_top"],
            fg="#ffffff",
            font=("Segoe UI", 32, "bold"),
        )
        title.place(x=32, y=26)

        subtitle = tk.Label(
            self.desktop,
            text="Unified security, AI, and development workspace",
            bg=THEME["wallpaper_top"],
            fg="#dce8ff",
            font=("Segoe UI", 12),
        )
        subtitle.place(x=36, y=88)

        tk.Label(
            self.desktop,
            text="Desktop apps",
            bg=THEME["wallpaper_top"],
            fg="#ffffff",
            font=("Segoe UI", 12, "bold"),
        ).place(x=40, y=128)

        apps = [
            ("Files", self.open_files),
            ("Notes", self.open_notes),
            ("Calculator", self.open_calculator),
            ("Terminal", self.open_terminal),
            ("SVANSAI Guide", self.open_svansai_guide),
            ("Sandbox", lambda: self.launch_actual_module("sandbox-armor")),
            ("Shield", lambda: self.launch_actual_module("file-armor")),
            ("Debugger", lambda: self.launch_actual_module("debugger-guide")),
            ("Guardian Core", self.open_guardian_center),
            ("Incident Center", self.open_incident_center),
            ("Network Armor", self.open_network_center),
            ("Beta Center", self.open_beta_center),
            ("Projects", self.open_actual_projects),
            ("App Store", self.open_store),
            ("Settings", self.open_settings),
            ("SV Browser", lambda: self.launch_actual_module("web-armor")),
        ]
        for index, (name, command) in enumerate(apps):
            row, col = divmod(index, 4)
            self._desktop_icon(name, 38 + (col * 158), 166 + (row * 118), command)

        self.taskbar = tk.Frame(self.root, bg=THEME["taskbar"], height=56)
        self.taskbar.pack(side="bottom", fill="x")
        self.vos_button = tk.Button(
            self.taskbar,
            text="VOS",
            command=self.open_launcher,
            bg=THEME["accent"],
            fg="white",
            activebackground="#3d8bff",
            activeforeground="white",
            relief="flat",
            font=("Segoe UI", 11, "bold"),
            width=12,
            cursor="hand2",
        )
        self.vos_button.pack(side="left", padx=12, pady=9)
        tk.Button(
            self.taskbar, text="Power", command=self._shutdown, bg="#dc3545", fg="#f6f8fb",
            activebackground="#ef476f", activeforeground="white", relief="flat", width=9, cursor="hand2",
        ).pack(side="right", padx=12, pady=9)
        self.guardian_badge = tk.Label(
            self.taskbar,
            text=f"Guardian: {self.guardian_status}",
            bg="#065f46" if self.guardian_status == "online" else "#991b1b",
            fg="white",
            font=("Segoe UI", 9, "bold"),
            padx=10,
            pady=5,
        )
        self.guardian_badge.pack(side="right", padx=6)
        self.taskbar_apps = tk.Frame(self.taskbar, bg=THEME["taskbar"])
        self.taskbar_apps.pack(side="left", fill="both", expand=True)
        self.window_manager = WindowManager(
            self.root, self.desktop, self.taskbar_apps, THEME,
            lambda text: messagebox.showerror("Vansant OS", text),
        )
        self.desktop.bind("<Configure>", lambda _event: self.root.after_idle(self.window_manager.constrain_all), add="+")
        self.desktop.bind("<Button-1>", self._desktop_background_click, add="+")

    def _paint_wallpaper(self, event) -> None:
        self.desktop.delete("wallpaper")
        width = max(event.width, 1)
        height = max(event.height, 1)
        bands = 80
        top = self._hex_to_rgb(THEME["wallpaper_top"])
        mid = self._hex_to_rgb(THEME["wallpaper_mid"])
        bottom = self._hex_to_rgb(THEME["wallpaper_bottom"])
        for i in range(bands):
            t = i / max(bands - 1, 1)
            if t < 0.58:
                color = self._mix(top, mid, t / 0.58)
            else:
                color = self._mix(mid, bottom, (t - 0.58) / 0.42)
            y0 = int(height * i / bands)
            y1 = int(height * (i + 1) / bands) + 1
            self.desktop.create_rectangle(0, y0, width, y1, fill=color, outline="", tags="wallpaper")
        self.desktop.create_oval(
            width - 360,
            30,
            width + 120,
            420,
            fill="#6d28d9",
            outline="",
            stipple="gray50",
            tags="wallpaper",
        )
        self.desktop.create_oval(
            width - 520,
            height - 260,
            width - 80,
            height + 120,
            fill="#0e7490",
            outline="",
            stipple="gray50",
            tags="wallpaper",
        )
        self.desktop.tag_lower("wallpaper")

    @staticmethod
    def _hex_to_rgb(value: str) -> tuple[int, int, int]:
        value = value.lstrip("#")
        return int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16)

    @staticmethod
    def _mix(a: tuple[int, int, int], b: tuple[int, int, int], t: float) -> str:
        return "#%02x%02x%02x" % tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

    def _desktop_icon(self, name: str, x: int, y: int, command) -> None:
        color = APP_TILES[name]
        tile = tk.Frame(self.desktop, bg=THEME["surface"], bd=0, highlightthickness=1, highlightbackground="#273047")
        tile.place(x=x, y=y, width=140, height=98)
        icon = tk.Canvas(
            tile,
            bg=color,
            width=44,
            height=34,
            highlightthickness=0,
            bd=0,
        )
        icon.pack(pady=(9, 3))
        actual_icon = self._load_project_icon(name, 36)
        if actual_icon:
            icon.create_image(22, 17, image=actual_icon)
        else:
            self._draw_app_icon(icon, name, color)
        button = tk.Button(
            tile,
            text=name,
            command=command,
            bg=THEME["surface"],
            fg=THEME["ink"],
            activebackground="#20283a",
            activeforeground=THEME["ink"],
            relief="flat",
            wraplength=122,
            font=("Segoe UI", 9, "bold"),
            cursor="hand2",
        )
        button.pack(fill="both", expand=True, padx=6, pady=(0, 6))

    def _load_project_icon(self, name: str, size: int = 32):
        path = PROJECT_ICONS.get(name)
        if not path or not path.exists():
            return None
        key = (str(path), size)
        if key not in self._icon_cache:
            image = Image.open(path).convert("RGBA")
            bounds = image.getchannel("A").getbbox()
            if bounds: image = image.crop(bounds)
            image.thumbnail((size, size), Image.Resampling.LANCZOS)
            self._icon_cache[key] = ImageTk.PhotoImage(image)
        return self._icon_cache[key]

    def _desktop_background_click(self, event) -> None:
        if self._start_menu and self._start_menu.winfo_exists():
            widget = self.root.winfo_containing(event.x_root, event.y_root)
            if widget is not self.vos_button and not self._is_descendant(widget, self._start_menu):
                self._close_start_menu()

    def _shutdown(self) -> None:
        manager = getattr(self, "window_manager", None)
        if manager:
            for window in list(manager.windows.values()): window.close()
        if self._guide_server and self._guide_server.poll() is None:
            subprocess.run(["taskkill", "/PID", str(self._guide_server.pid), "/T", "/F"], capture_output=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        self.root.destroy()

    @staticmethod
    def _is_descendant(widget, parent) -> bool:
        while widget is not None:
            if widget is parent: return True
            widget = getattr(widget, "master", None)
        return False

    def _draw_app_icon(self, canvas: tk.Canvas, name: str, color: str) -> None:
        canvas.delete("all")
        white = "#ffffff"
        soft = "#dbeafe"
        if name == "Files":
            canvas.create_polygon(6, 10, 17, 10, 21, 15, 38, 15, 38, 29, 6, 29, fill=white, outline="")
            canvas.create_rectangle(6, 15, 38, 30, fill=soft, outline="")
        elif name == "Notes":
            canvas.create_rectangle(11, 5, 34, 31, fill=white, outline="")
            for y in (11, 17, 23):
                canvas.create_line(15, y, 30, y, fill=color, width=2)
        elif name == "Calculator":
            canvas.create_rectangle(11, 4, 34, 31, fill=white, outline="")
            canvas.create_rectangle(15, 8, 30, 13, fill=color, outline="")
            for x in (16, 23, 30):
                for y in (18, 25):
                    canvas.create_oval(x - 2, y - 2, x + 2, y + 2, fill=color, outline="")
        elif name == "Terminal":
            canvas.create_rectangle(5, 6, 39, 29, fill=white, outline="")
            canvas.create_line(12, 14, 18, 18, 12, 22, fill=color, width=3)
            canvas.create_line(22, 23, 32, 23, fill=color, width=3)
        elif name == "SVANSAI Guide":
            canvas.create_oval(8, 5, 36, 31, fill=white, outline="")
            canvas.create_oval(17, 14, 27, 24, fill=color, outline="")
            for x, y in ((9, 6), (35, 6), (9, 31), (35, 31)):
                canvas.create_line(22, 19, x, y, fill=white, width=2)
        elif name == "Sandbox":
            canvas.create_rectangle(8, 11, 36, 29, fill=white, outline="")
            canvas.create_polygon(8, 11, 22, 4, 36, 11, 22, 18, fill=soft, outline="")
            canvas.create_line(22, 18, 22, 29, fill=color, width=2)
        elif name == "Shield":
            canvas.create_polygon(22, 4, 36, 9, 33, 24, 22, 32, 11, 24, 8, 9, fill=white, outline="")
            canvas.create_line(16, 18, 21, 23, 30, 13, fill=color, width=3)
        elif name == "Debugger":
            canvas.create_oval(11, 9, 33, 29, fill=white, outline="")
            canvas.create_line(22, 4, 22, 9, fill=white, width=3)
            canvas.create_line(13, 6, 17, 12, fill=white, width=3)
            canvas.create_line(31, 6, 27, 12, fill=white, width=3)
            canvas.create_line(8, 18, 36, 18, fill=color, width=2)
            canvas.create_line(16, 14, 16, 25, fill=color, width=2)
            canvas.create_line(28, 14, 28, 25, fill=color, width=2)
        elif name == "Guardian Core":
            canvas.create_polygon(22, 3, 37, 9, 34, 24, 22, 33, 10, 24, 7, 9, fill=white, outline="")
            canvas.create_oval(16, 12, 28, 24, fill=color, outline="")
            canvas.create_oval(20, 16, 24, 20, fill=white, outline="")
        elif name == "Incident Center":
            canvas.create_polygon(22, 3, 39, 31, 5, 31, fill=white, outline="")
            canvas.create_rectangle(20, 11, 24, 22, fill=color, outline="")
            canvas.create_oval(20, 25, 24, 29, fill=color, outline="")
        elif name == "Projects":
            for offset in (0, 7, 14):
                canvas.create_rectangle(9 + offset, 8 + offset // 2, 24 + offset, 22 + offset // 2, fill=white, outline="")
        elif name == "App Store":
            canvas.create_rectangle(10, 12, 34, 30, fill=white, outline="")
            canvas.create_arc(15, 4, 29, 19, start=0, extent=180, outline=white, width=3)
            canvas.create_rectangle(16, 18, 28, 24, fill=color, outline="")
        elif name == "Settings":
            canvas.create_oval(9, 5, 35, 31, fill=white, outline="")
            canvas.create_oval(17, 13, 27, 23, fill=color, outline="")
            for x1, y1, x2, y2 in ((22, 2, 22, 8), (22, 28, 22, 34), (5, 18, 11, 18), (33, 18, 39, 18)):
                canvas.create_line(x1, y1, x2, y2, fill=white, width=3)
        else:
            canvas.create_oval(8, 5, 36, 31, fill=white, outline="")
            canvas.create_line(15, 18, 20, 23, 31, 12, fill=color, width=3)

    def _window(self, title: str, width: int = 640, height: int = 440):
        self._close_start_menu()
        return self.window_manager.create(f"internal:{title.lower()}", title, width, height)

    def _text_view(self, parent, *, editable: bool = True) -> tk.Text:
        text = tk.Text(
            parent,
            wrap="word",
            bg=THEME["surface"],
            fg=THEME["ink"],
            insertbackground=THEME["ink"],
            relief="flat",
            padx=10,
            pady=10,
            font=("Consolas", 10),
        )
        text.pack(fill="both", expand=True, padx=12, pady=12)
        if not editable:
            text.configure(state="disabled")
        return text

    def _action_button(self, parent, text: str, command, *, accent: bool = False) -> tk.Button:
        return tk.Button(
            parent,
            text=text,
            command=command,
            bg=THEME["accent"] if accent else THEME["taskbar_alt"],
            fg="white" if accent else THEME["ink"],
            activebackground="#7c3aed" if accent else "#242b3a",
            activeforeground="white" if accent else THEME["ink"],
            relief="flat",
            cursor="hand2",
            padx=10,
            pady=4,
        )

    def _show_output(self, title: str, output: str) -> None:
        window = self._window(title, 720, 460)
        text = self._text_view(window)
        text.insert("1.0", output or "(No output)")
        text.configure(state="disabled")

    def _capture_sentence(self, sentence: str) -> str:
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            plain.run_sentence(
                sentence,
                unsafe=True,
                allow_imports=True,
                allow_system=True,
            )
        return buffer.getvalue().strip()

    def _capture_plain_file(self, path: Path) -> str:
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            plain.run_plain(
                path,
                unsafe=True,
                allow_imports=True,
                allow_system=True,
            )
        return buffer.getvalue().strip()

    def _run_plain_source(
        self,
        source: str,
        *,
        unsafe: bool = False,
        allow_imports: bool = False,
        allow_system: bool = False,
        filename: str = "<vos>",
    ) -> str:
        python_code = plain.transpile(
            source,
            allow_imports=allow_imports,
            allow_system=allow_system,
            base_dir=ROOT,
        )
        builtins = __builtins__ if unsafe else plain.SAFE_BUILTINS
        globals_dict = {"__builtins__": builtins, "__name__": "__main__"}
        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            exec(compile(python_code, filename, "exec"), globals_dict, globals_dict)
        return buffer.getvalue().strip()

    def _read_text_file(self, path: Path) -> str:
        try:
            return path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            return ""

    def _shield_findings(self, source: str, *, location: str = "current text") -> list[str]:
        checks = [
            ("System command", "Run command", "Can run installed programs on this computer."),
            ("File deletion", "Delete file", "Can remove local files."),
            ("File move", "Move ", "Can move or rename local files."),
            ("External app", "Open ", "Can open apps, files, folders, or URLs."),
            ("Network fetch", "Fetch ", "Can contact websites or APIs."),
            ("Network post", "Post to", "Can send data to websites or APIs."),
            ("AI call", "Ask Claude", "Can send prompt/context to Claude through your API key."),
            ("Python bridge", "Use Python:", "Can execute Python code."),
            ("Language bridge", "Run Python", "Can start another language runtime."),
            ("Language bridge", "Run JavaScript", "Can start another language runtime."),
            ("Import", "Import ", "Can load Python modules."),
            ("Module use", "Use module", "Can load Python modules."),
        ]
        findings: list[str] = []
        for number, line in enumerate(source.splitlines(), start=1):
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            lowered = stripped.lower()
            for check_name, needle, reason in checks:
                if needle.lower() in lowered:
                    findings.append(f"{location}: line {number}: {check_name} - {reason}\n  {stripped}")
                    break
        return findings

    def _shield_report(self, source: str) -> str:
        findings = self._shield_findings(source)
        if not findings:
            return "Shield scan passed. I did not find risky system, network, import, file-delete, or AI-send commands."
        return "Shield found commands that need trust:\n\n" + "\n\n".join(findings)

    def _scan_folder_with_shield(self, folder: Path) -> tuple[int, list[str]]:
        scanned = 0
        findings: list[str] = []
        for path in folder.rglob("*"):
            if path.is_dir() or path.suffix.lower() not in {".plain", ".py", ".ps1", ".cmd", ".bat"}:
                continue
            scanned += 1
            source = self._read_text_file(path)
            if not source:
                continue
            findings.extend(self._shield_findings(source, location=str(path.relative_to(folder))))
        return scanned, findings

    def open_launcher(self) -> None:
        if self._start_menu and self._start_menu.winfo_exists():
            self._close_start_menu(); return
        window = tk.Frame(self.desktop, bg=THEME["panel"], highlightthickness=1, highlightbackground="#34405a")
        self._start_menu = window
        tk.Label(
            window,
            text="VANSANT OS",
            bg=THEME["panel"],
            fg=THEME["ink"],
            font=("Segoe UI", 17, "bold"),
        ).pack(anchor="w", padx=16, pady=(14, 2))
        tk.Label(window, text="Applications", bg=THEME["panel"], fg=THEME["muted"], font=("Segoe UI", 9)).pack(anchor="w", padx=16, pady=(0, 8))
        items_frame = tk.Frame(window, bg=THEME["panel"]); items_frame.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        launcher_items = [
            ("Files", self.open_files),
            ("Notes", self.open_notes),
            ("Calculator", self.open_calculator),
            ("Terminal", self.open_terminal),
            ("SVANSAI Guide", self.open_svansai_guide),
            ("Sandbox", lambda: self.launch_actual_module("sandbox-armor")),
            ("Shield", lambda: self.launch_actual_module("file-armor")),
            ("Debugger", lambda: self.launch_actual_module("debugger-guide")),
            ("Guardian Core", self.open_guardian_center),
            ("Incident Center", self.open_incident_center),
            ("Network Armor", self.open_network_center),
            ("Beta Center", self.open_beta_center),
            ("Projects", self.open_actual_projects),
            ("App Store", self.open_store),
            ("Settings", self.open_settings),
            ("SV Browser", lambda: self.launch_actual_module("web-armor")),
        ] + store_apps.installed_launchers(self)
        for index, (name, command) in enumerate(launcher_items):
            def launch(action=command):
                self._close_start_menu(); action()
            icon = self._load_project_icon(name, 22)
            button = tk.Button(
                items_frame, text=name, image=icon or "", compound="left", anchor="w", command=launch,
                bg=THEME["surface"], fg=THEME["ink"], activebackground="#242b3a", activeforeground="white",
                relief="flat", padx=12, pady=5, cursor="hand2", font=("Segoe UI", 9),
            )
            row, column = divmod(index, 2)
            button.grid(row=row, column=column, sticky="ew", padx=2, pady=2)
            items_frame.grid_columnconfigure(column, weight=1)
        window.update_idletasks()
        height = min(window.winfo_reqheight(), max(300, self.desktop.winfo_height() - 8))
        window.place(x=8, y=max(0, self.desktop.winfo_height() - height - 4), width=440, height=height)
        window.lift()

    def _close_start_menu(self) -> None:
        if self._start_menu and self._start_menu.winfo_exists(): self._start_menu.destroy()
        self._start_menu = None

    def open_files(self) -> None:
        window = self._window("Files", 760, 500)
        state = {"folder": ROOT}
        top = tk.Frame(window, bg=THEME["panel"])
        top.pack(fill="x", padx=12, pady=(12, 0))
        path_label = tk.Label(top, text=str(state["folder"]), bg=THEME["panel"], fg=THEME["muted"], anchor="w")
        path_label.pack(side="left", fill="x", expand=True)
        listbox = tk.Listbox(
            window,
            font=("Consolas", 10),
            relief="flat",
            bg=THEME["surface"],
            fg=THEME["ink"],
            selectbackground=THEME["accent"],
            selectforeground="white",
        )
        listbox.pack(fill="both", expand=True, padx=12, pady=12)

        def refresh() -> None:
            path_label.configure(text=str(state["folder"]))
            listbox.delete(0, "end")
            if state["folder"] != ROOT:
                listbox.insert("end", "..")
            for item in sorted(state["folder"].iterdir(), key=lambda p: (p.is_file(), p.name.lower())):
                listbox.insert("end", f"{item.name}/" if item.is_dir() else item.name)

        def open_selected(_event=None) -> None:
            selected = listbox.curselection()
            if not selected:
                return
            name = listbox.get(selected[0])
            if name == "..":
                state["folder"] = state["folder"].parent
                refresh()
                return
            target = state["folder"] / name.rstrip("/")
            if target.is_dir():
                state["folder"] = target
                refresh()
                return
            try:
                target.read_text(encoding="utf-8")
                self.open_text_editor(target)
            except UnicodeDecodeError:
                messagebox.showinfo("VOS Files", "This file is not readable as text.")

        def validated_target(kind: str) -> Path | None:
            name = simpledialog.askstring(f"New {kind}", f"Enter the {kind.lower()} name:", parent=self.root)
            if not name: return None
            name = name.strip()
            if not name or name in {".", ".."} or Path(name).name != name or any(char in name for char in '<>:"/\\|?*'):
                messagebox.showerror("VOS Files", "Use a single valid Windows file or folder name."); return None
            target = state["folder"] / name
            if target.exists():
                messagebox.showerror("VOS Files", f"{name} already exists."); return None
            return target

        def new_file() -> None:
            target = validated_target("File")
            if not target: return
            try:
                target.write_text("", encoding="utf-8"); refresh(); self.open_text_editor(target)
            except OSError as error: messagebox.showerror("VOS Files", f"Could not create the file:\n{error}")

        def new_folder() -> None:
            target = validated_target("Folder")
            if not target: return
            try:
                target.mkdir(); refresh()
            except OSError as error: messagebox.showerror("VOS Files", f"Could not create the folder:\n{error}")

        def context_menu(event) -> None:
            index = listbox.nearest(event.y); listbox.selection_clear(0, "end")
            if listbox.size(): listbox.selection_set(index)
            menu = tk.Menu(window, tearoff=False, bg=THEME["surface"], fg=THEME["ink"])
            menu.add_command(label="Open", command=open_selected); menu.add_separator()
            menu.add_command(label="New File", command=new_file); menu.add_command(label="New Folder", command=new_folder)
            menu.tk_popup(event.x_root, event.y_root)

        listbox.bind("<Double-Button-1>", open_selected)
        listbox.bind("<Button-3>", context_menu)
        self._action_button(top, "Open", open_selected, accent=True).pack(side="right", padx=4)
        self._action_button(top, "New Folder", new_folder).pack(side="right", padx=4)
        self._action_button(top, "New File", new_file).pack(side="right", padx=4)
        refresh()

    def open_text_editor(self, path: Path) -> None:
        window = self._window(f"Editor — {path.name}", 820, 560)
        tk.Label(window, text=str(path), bg=THEME["panel"], fg=THEME["muted"], anchor="w").pack(fill="x", padx=12, pady=(10, 0))
        editor = self._text_view(window)
        try: editor.insert("1.0", path.read_text(encoding="utf-8"))
        except OSError as error: messagebox.showerror("VOS Editor", str(error)); return
        def save() -> None:
            try:
                path.write_text(editor.get("1.0", "end-1c"), encoding="utf-8")
                messagebox.showinfo("VOS Editor", f"Saved {path.name}")
            except OSError as error: messagebox.showerror("VOS Editor", f"Could not save:\n{error}")
        controls = tk.Frame(window, bg=THEME["panel"]); controls.pack(fill="x", padx=12, pady=(0, 12))
        self._action_button(controls, "Save", save, accent=True).pack(side="right")
        editor.bind("<Control-s>", lambda _event: (save(), "break"))

    def open_notes(self) -> None:
        window = self._window("Notepad", 860, 560)
        documents_dir = USER_DIR / "documents"
        documents_dir.mkdir(parents=True, exist_ok=True)
        state: dict[str, Path | None] = {"path": None}
        status = tk.Label(
            window,
            text=f"Documents folder: {documents_dir}",
            bg=THEME["panel"],
            fg=THEME["muted"],
            anchor="w",
            font=("Segoe UI", 10),
        )
        status.pack(fill="x", padx=12, pady=(12, 4))

        body = tk.Frame(window, bg=THEME["panel"])
        body.pack(fill="both", expand=True, padx=12, pady=8)
        files = tk.Listbox(
            body,
            font=("Consolas", 9),
            relief="flat",
            bg=THEME["surface"],
            fg=THEME["ink"],
            selectbackground=THEME["accent"],
            selectforeground="white",
            width=26,
        )
        files.pack(side="left", fill="y", padx=(0, 10))
        text = tk.Text(
            body,
            wrap="word",
            bg=THEME["surface"],
            fg=THEME["ink"],
            insertbackground=THEME["ink"],
            relief="flat",
            padx=10,
            pady=10,
            font=("Consolas", 10),
        )
        text.pack(side="left", fill="both", expand=True)
        text.insert("1.0", "Welcome to VOS Notepad.\n\nCreate your own files here and save them into VOS.")

        def refresh_files() -> None:
            files.delete(0, "end")
            for path in sorted(documents_dir.glob("*")):
                if path.is_file():
                    files.insert("end", path.name)

        def set_current(path: Path | None) -> None:
            state["path"] = path
            if path is None:
                status.configure(text=f"Documents folder: {documents_dir} | Unsaved file")
            else:
                status.configure(text=f"Current file: {path}")

        def load_file(path: Path) -> None:
            text.delete("1.0", "end")
            text.insert("1.0", self._read_text_file(path))
            set_current(path)

        def open_selected(_event=None) -> None:
            selection = files.curselection()
            if not selection:
                return
            load_file(documents_dir / files.get(selection[0]))

        def new_file() -> None:
            text.delete("1.0", "end")
            set_current(None)

        def save() -> None:
            path = state["path"] or documents_dir / "untitled.txt"
            path.write_text(text.get("1.0", "end-1c"), encoding="utf-8")
            set_current(path)
            refresh_files()
            messagebox.showinfo("VOS Notepad", f"Saved {path}")

        def save_as() -> None:
            chosen = filedialog.asksaveasfilename(
                title="Save VOS document",
                initialdir=str(documents_dir),
                initialfile=(state["path"].name if state["path"] else "untitled.txt"),
                defaultextension=".txt",
                filetypes=[("Text files", "*.txt"), ("Plain files", "*.plain"), ("Markdown files", "*.md"), ("All files", "*.*")],
            )
            if not chosen:
                return
            path = Path(chosen)
            path.write_text(text.get("1.0", "end-1c"), encoding="utf-8")
            set_current(path)
            refresh_files()
            messagebox.showinfo("VOS Notepad", f"Saved {path}")

        def open_file() -> None:
            chosen = filedialog.askopenfilename(
                title="Open document",
                initialdir=str(documents_dir),
                filetypes=[("Text files", "*.txt"), ("Plain files", "*.plain"), ("Markdown files", "*.md"), ("All files", "*.*")],
            )
            if chosen:
                load_file(Path(chosen))

        def open_folder() -> None:
            try:
                if sys.platform.startswith("win"):
                    import os

                    os.startfile(documents_dir)
                else:
                    messagebox.showinfo("VOS Notepad", str(documents_dir))
            except Exception as error:
                messagebox.showerror("VOS Notepad", f"Could not open folder: {error}")

        files.bind("<<ListboxSelect>>", open_selected)
        controls = tk.Frame(window, bg=THEME["panel"])
        controls.pack(fill="x", padx=12, pady=(0, 12))
        self._action_button(controls, "New", new_file).pack(side="left", padx=(0, 8))
        self._action_button(controls, "Open", open_file).pack(side="left", padx=(0, 8))
        self._action_button(controls, "Save", save, accent=True).pack(side="left", padx=(0, 8))
        self._action_button(controls, "Save As", save_as).pack(side="left", padx=(0, 8))
        self._action_button(controls, "Folder", open_folder).pack(side="left")
        refresh_files()
        set_current(None)
        window.after(150, lambda: text.focus_force())

    def open_calculator(self) -> None:
        window = self._window("Calculator", 430, 230)
        tk.Label(
            window,
            text="Type math the SVANS-AI way",
            bg=THEME["panel"],
            fg=THEME["ink"],
            font=("Segoe UI", 12, "bold"),
        ).pack(
            anchor="w", padx=18, pady=(18, 8)
        )
        entry = tk.Entry(window, font=("Consolas", 14), relief="flat", bg=THEME["surface"], fg=THEME["ink"])
        entry.pack(fill="x", padx=18, pady=6)
        result = tk.Label(window, text="", bg=THEME["panel"], fg=THEME["accent"], font=("Segoe UI", 18, "bold"))
        result.pack(anchor="w", padx=18, pady=14)

        def calculate(_event=None) -> None:
            expr = entry.get().strip()
            if not expr:
                return
            try:
                output = self._capture_sentence(f"Run {expr}")
                result.configure(text=output)
            except Exception as error:
                result.configure(text=f"Error: {error}")

        entry.bind("<Return>", calculate)
        self._action_button(window, "Run", calculate, accent=True).pack(anchor="e", padx=18, pady=6)

    def open_terminal(self) -> None:
        window = self._window("Terminal", 780, 520)
        output = self._text_view(window)
        output.insert("1.0", self.vos.banner() + "\n\n")
        input_bar = tk.Frame(window, bg=THEME["panel"])
        input_bar.pack(fill="x", padx=12, pady=(0, 12))
        entry = tk.Entry(input_bar, font=("Consolas", 11), relief="flat", bg=THEME["surface"], fg=THEME["ink"])
        entry.pack(side="left", fill="x", expand=True)

        def append(text: str) -> None:
            output.configure(state="normal")
            output.insert("end", text)
            output.see("end")
            output.configure(state="disabled")

        output.configure(state="disabled")

        def run_command(_event=None) -> None:
            command = entry.get().strip()
            if not command:
                return
            entry.delete(0, "end")
            append(f"VOS> {command}\n")
            try:
                buffer = io.StringIO()
                with contextlib.redirect_stdout(buffer):
                    response = self.vos.execute(command)
                printed = buffer.getvalue().strip()
                combined = "\n".join(part for part in [printed, response] if part)
                append((combined or "(done)") + "\n")
            except Exception as error:
                append(f"VOS error: {error}\n")

        entry.bind("<Return>", run_command)
        self._action_button(input_bar, "Run", run_command, accent=True).pack(side="right", padx=(8, 0))
        entry.focus_set()

    def launch_actual_module(self, module_id: str, *, extra_args: list[str] | None = None, window_key: str | None = None, title: str | None = None):
        self._close_start_menu()
        key = f"external:{window_key or module_id}"
        if self.window_manager.focus_key(key):
            return None
        try:
            self.guardian.ensure_started()
            module = dict(next(item for item in self.guardian.modules() if item.get("id") == module_id))
            if extra_args: module["launch"] = list(module.get("launch", [])) + extra_args
            process = self.guardian.launch(module)
            titles = {
                "sandbox-armor": "VOS Sandbox Armor", "file-armor": "SVANS Shield",
                "debugger-guide": "SVANSAI Debugger", "web-armor": "SV Browser",
            }
            icon_names = {"sandbox-armor": "Sandbox", "file-armor": "Shield", "debugger-guide": "Debugger", "web-armor": "SV Browser"}
            sizes = {"sandbox-armor": (1180, 680), "file-armor": (1000, 640), "debugger-guide": (1100, 680), "web-armor": (1120, 680)}
            width, height = sizes.get(module_id, (960, 600))
            host_icon_name = "SVANSAI Guide" if window_key == "svansai-guide" else icon_names.get(module_id, "")
            host = self.window_manager.create(key, title or titles.get(module_id, str(module.get("name", module_id))), width, height, external=True, icon=self._load_project_icon(host_icon_name, 20))
            host.attach_process(process)
            return process
        except (GuardianError, OSError, StopIteration) as error:
            messagebox.showerror("Vansant OS", f"Could not open the application:\n{error}")
            return None

    def open_svansai_guide(self) -> None:
        self._close_start_menu()
        guide_url = "http://127.0.0.1:3010"
        if self.window_manager.focus_key("external:svansai-guide"):
            return

        def guide_is_ready() -> bool:
            try:
                with urllib.request.urlopen(guide_url, timeout=0.5):
                    return True
            except Exception:
                return False

        if guide_is_ready():
            self.launch_actual_module("web-armor", extra_args=[f"--url={guide_url}"], window_key="svansai-guide", title="SVANSAI Guide")
            return
        try:
            module = next(item for item in self.guardian.modules() if item.get("id") == "svansai-guide")
            process = self.guardian.launch(module)
            self._guide_server = process
        except (GuardianError, OSError, StopIteration) as error:
            messagebox.showerror("SVANSAI Guide", f"Could not start the Guide:\n{error}")
            return

        def open_when_ready(attempt: int = 0) -> None:
            if guide_is_ready():
                self.launch_actual_module("web-armor", extra_args=[f"--url={guide_url}"], window_key="svansai-guide", title="SVANSAI Guide")
            elif attempt < 40 and process.poll() is None:
                self.root.after(500, lambda: open_when_ready(attempt + 1))
            else:
                messagebox.showerror("SVANSAI Guide", "The Guide server did not become ready on port 3010.")

        open_when_ready()

    def open_svans_runner(self) -> None:
        window = self._window("SVANS-AI Runner", 760, 500)
        tk.Label(
            window,
            text="Run one SVANS-AI sentence",
            bg=THEME["panel"],
            fg=THEME["ink"],
            font=("Segoe UI", 13, "bold"),
        ).pack(anchor="w", padx=12, pady=(12, 4))
        entry = tk.Entry(window, font=("Consolas", 12), relief="flat", bg=THEME["surface"], fg=THEME["ink"])
        entry.pack(fill="x", padx=12, pady=6)
        entry.insert(0, 'Say "Hello from VOS"')
        output = self._text_view(window)

        def run_sentence(_event=None) -> None:
            sentence = entry.get().strip()
            if not sentence:
                return
            output.configure(state="normal")
            output.insert("end", f"SVANS-AI> {sentence}\n")
            try:
                result = self._capture_sentence(sentence)
                output.insert("end", (result or "(done)") + "\n\n")
            except Exception as error:
                output.insert("end", f"Error: {error}\n\n")
            output.see("end")
            output.configure(state="disabled")

        output.configure(state="disabled")
        entry.bind("<Return>", run_sentence)
        self._action_button(window, "Run Sentence", run_sentence, accent=True).pack(anchor="e", padx=12, pady=(0, 12))
        window.after(150, lambda: (entry.focus_force(), entry.icursor("end")))

    def open_sandbox(self) -> None:
        window = self._window("Sandbox", 900, 620)
        sandbox_dir = USER_DIR / "sandbox"
        sandbox_dir.mkdir(parents=True, exist_ok=True)
        current_file: dict[str, Path | None] = {"path": None}
        path_label = tk.Label(
            window,
            text=f"Isolated workspace: {sandbox_dir}",
            bg=THEME["panel"],
            fg=THEME["muted"],
            font=("Segoe UI", 10),
            anchor="w",
        )
        path_label.pack(fill="x", padx=12, pady=(12, 4))
        main = tk.Frame(window, bg=THEME["panel"])
        main.pack(fill="both", expand=True, padx=12, pady=8)
        left = tk.Frame(main, bg=THEME["panel"], width=180)
        left.pack(side="left", fill="y", padx=(0, 10))
        right = tk.Frame(main, bg=THEME["panel"])
        right.pack(side="left", fill="both", expand=True)

        files = tk.Listbox(
            left,
            font=("Consolas", 9),
            relief="flat",
            bg=THEME["surface"],
            fg=THEME["ink"],
            selectbackground=THEME["accent"],
            selectforeground="white",
            width=24,
        )
        files.pack(fill="both", expand=True)
        editor = self._text_view(right)
        editor.insert("1.0", 'Say "Hello from the Sandbox".\nRun 2+3.\n')
        output = self._text_view(right)
        output.configure(height=8)

        def refresh_files() -> None:
            files.delete(0, "end")
            for path in sorted(sandbox_dir.glob("*.plain")):
                files.insert("end", path.name)

        def set_current_file(path: Path | None) -> None:
            current_file["path"] = path
            if path is None:
                path_label.configure(text=f"Isolated workspace: {sandbox_dir} | Unsaved file")
            else:
                path_label.configure(text=f"Current file: {path}")

        def load_file(path: Path) -> None:
            editor.delete("1.0", "end")
            editor.insert("1.0", self._read_text_file(path))
            set_current_file(path)
            write_output(f"Opened {path}")

        def load_selected(_event=None) -> None:
            selection = files.curselection()
            if not selection:
                return
            path = sandbox_dir / files.get(selection[0])
            load_file(path)

        def write_output(text: str) -> None:
            output.configure(state="normal")
            output.delete("1.0", "end")
            output.insert("1.0", text or "(done)")
            output.configure(state="disabled")

        def run_safe() -> None:
            try:
                result = self._run_plain_source(editor.get("1.0", "end-1c"), filename="<vos sandbox>")
                write_output(result)
            except Exception as error:
                write_output(f"Sandbox error: {error}")

        def run_trusted() -> None:
            try:
                result = self._run_plain_source(
                    editor.get("1.0", "end-1c"),
                    unsafe=True,
                    allow_imports=True,
                    allow_system=True,
                    filename="<vos trusted sandbox>",
                )
                write_output(result)
            except Exception as error:
                write_output(f"Trusted sandbox error: {error}")

        def save_sandbox() -> None:
            path = current_file["path"] or sandbox_dir / "sandbox_program.plain"
            path.write_text(editor.get("1.0", "end-1c"), encoding="utf-8")
            set_current_file(path)
            refresh_files()
            write_output(f"Saved {path}")

        def save_as() -> None:
            chosen = filedialog.asksaveasfilename(
                title="Save sandbox file",
                initialdir=str(sandbox_dir),
                initialfile=(current_file["path"].name if current_file["path"] else "sandbox_program.plain"),
                defaultextension=".plain",
                filetypes=[("Plain files", "*.plain"), ("Text files", "*.txt"), ("All files", "*.*")],
            )
            if not chosen:
                return
            path = Path(chosen)
            path.write_text(editor.get("1.0", "end-1c"), encoding="utf-8")
            set_current_file(path)
            refresh_files()
            write_output(f"Saved {path}")

        def open_file() -> None:
            chosen = filedialog.askopenfilename(
                title="Open file in sandbox",
                initialdir=str(sandbox_dir),
                filetypes=[("Plain files", "*.plain"), ("Text files", "*.txt"), ("Python files", "*.py"), ("All files", "*.*")],
            )
            if not chosen:
                return
            load_file(Path(chosen))

        def open_sandbox_folder() -> None:
            try:
                if sys.platform.startswith("win"):
                    import os

                    os.startfile(sandbox_dir)
                else:
                    write_output(f"Sandbox folder: {sandbox_dir}")
            except Exception as error:
                write_output(f"Could not open sandbox folder: {error}")

        def new_file() -> None:
            editor.delete("1.0", "end")
            editor.insert("1.0", 'Say "New sandbox program".\n')
            set_current_file(None)
            write_output("New unsaved sandbox file.")

        def reset_sandbox() -> None:
            editor.delete("1.0", "end")
            editor.insert("1.0", 'Say "Hello from the Sandbox".\nRun 2+3.\n')
            set_current_file(None)
            write_output("Sandbox reset. Safe mode is ready.")

        controls = tk.Frame(window, bg=THEME["panel"])
        controls.pack(fill="x", padx=12, pady=(0, 12))
        self._action_button(controls, "Safe Run", run_safe, accent=True).pack(side="left", padx=(0, 8))
        self._action_button(controls, "Trusted Run", run_trusted).pack(side="left", padx=(0, 8))
        self._action_button(controls, "New", new_file).pack(side="left", padx=(0, 8))
        self._action_button(controls, "Open File", open_file).pack(side="left", padx=(0, 8))
        self._action_button(controls, "Save", save_sandbox).pack(side="left", padx=(0, 8))
        self._action_button(controls, "Save As", save_as).pack(side="left", padx=(0, 8))
        self._action_button(controls, "Folder", open_sandbox_folder).pack(side="left", padx=(0, 8))
        self._action_button(controls, "Reset", reset_sandbox).pack(side="left")
        output.configure(state="disabled")
        files.bind("<<ListboxSelect>>", load_selected)
        refresh_files()
        set_current_file(None)
        window.after(150, lambda: editor.focus_force())

    def open_shield(self) -> None:
        window = self._window("Shield", 900, 620)
        tk.Label(
            window,
            text="SVANS-AI Shield scans code for commands that need trust before you run them.",
            bg=THEME["panel"],
            fg=THEME["muted"],
            font=("Segoe UI", 10),
        ).pack(anchor="w", padx=12, pady=(12, 4))
        status = tk.Label(
            window,
            text="Status: Ready",
            bg=THEME["panel"],
            fg=THEME["ink"],
            font=("Segoe UI", 14, "bold"),
            anchor="w",
        )
        status.pack(fill="x", padx=12, pady=(4, 8))

        main = tk.Frame(window, bg=THEME["panel"])
        main.pack(fill="both", expand=True, padx=12, pady=4)
        editor = tk.Text(main, wrap="word", relief="flat", bg=THEME["surface"], fg=THEME["ink"], font=("Consolas", 10))
        editor.pack(side="left", fill="both", expand=True, padx=(0, 10))
        editor.insert("1.0", 'Ask Claude "summarize this" and remember answer as summary.\nSay summary.\n')
        side = tk.Frame(main, bg=THEME["panel"], width=260)
        side.pack(side="right", fill="both")
        tk.Label(side, text="Quarantine review", bg=THEME["panel"], fg=THEME["ink"], font=("Segoe UI", 11, "bold")).pack(
            anchor="w"
        )
        quarantine = tk.Listbox(
            side,
            font=("Consolas", 9),
            relief="flat",
            bg=THEME["surface"],
            fg=THEME["ink"],
            selectbackground=THEME["accent"],
            selectforeground="white",
            width=34,
        )
        quarantine.pack(fill="both", expand=True, pady=(4, 0))
        report = tk.Text(window, wrap="word", relief="flat", bg=THEME["surface"], fg=THEME["ink"], font=("Consolas", 10), height=8)
        report.pack(fill="x", padx=12, pady=8)

        def scan_text() -> None:
            source = editor.get("1.0", "end-1c")
            findings = self._shield_findings(source)
            result = self._shield_report(source)
            quarantine.delete(0, "end")
            for finding in findings:
                first_line = finding.splitlines()[0]
                quarantine.insert("end", first_line[:90])
            status.configure(
                text=f"Status: {'Protected' if not findings else 'Review needed'} | Scanned 1 item | Findings {len(findings)}",
                fg="#0f8a4b" if not findings else "#b42318",
            )
            report.configure(state="normal")
            report.delete("1.0", "end")
            report.insert("1.0", result)
            report.configure(state="disabled")

        def scan_file() -> None:
            chosen = filedialog.askopenfilename(
                title="Choose a .plain file",
                initialdir=str(ROOT),
                filetypes=[("Plain files", "*.plain"), ("All files", "*.*")],
            )
            if not chosen:
                return
            path = Path(chosen)
            editor.delete("1.0", "end")
            editor.insert("1.0", self._read_text_file(path))
            scan_text()

        def scan_folder() -> None:
            chosen = filedialog.askdirectory(title="Choose a folder to scan", initialdir=str(ROOT))
            if not chosen:
                return
            folder = Path(chosen)
            scanned, findings = self._scan_folder_with_shield(folder)
            quarantine.delete(0, "end")
            for finding in findings:
                quarantine.insert("end", finding.splitlines()[0][:90])
            status.configure(
                text=f"Status: {'Protected' if not findings else 'Review needed'} | Scanned {scanned} files | Findings {len(findings)}",
                fg="#0f8a4b" if not findings else "#b42318",
            )
            report.configure(state="normal")
            report.delete("1.0", "end")
            if findings:
                report.insert("1.0", "Shield folder scan found commands that need trust:\n\n" + "\n\n".join(findings))
            else:
                report.insert("1.0", f"Shield folder scan passed. Scanned {scanned} files.")
            report.configure(state="disabled")

        def quick_scan() -> None:
            scanned, findings = self._scan_folder_with_shield(ROOT)
            quarantine.delete(0, "end")
            for finding in findings:
                quarantine.insert("end", finding.splitlines()[0][:90])
            status.configure(
                text=f"Status: {'Protected' if not findings else 'Review needed'} | Scanned {scanned} project files | Findings {len(findings)}",
                fg="#0f8a4b" if not findings else "#b42318",
            )
            report.configure(state="normal")
            report.delete("1.0", "end")
            report.insert("1.0", ("Shield quick scan found commands that need trust:\n\n" + "\n\n".join(findings)) if findings else "Shield quick scan passed.")
            report.configure(state="disabled")

        controls = tk.Frame(window, bg=THEME["panel"])
        controls.pack(fill="x", padx=12, pady=(0, 12))
        self._action_button(controls, "Quick Scan", quick_scan, accent=True).pack(side="left", padx=(0, 8))
        self._action_button(controls, "Scan Text", scan_text).pack(side="left", padx=(0, 8))
        self._action_button(controls, "Scan File", scan_file).pack(side="left", padx=(0, 8))
        self._action_button(controls, "Scan Folder", scan_folder).pack(side="left")
        report.configure(state="disabled")
        window.after(150, scan_text)

    def open_debugger(self) -> None:
        window = self._window("Debugger", 920, 620)
        state = {"path": None}
        label = tk.Label(
            window,
            text="Debug SVANS-AI files, generated Python, and the VOS desktop runtime.",
            bg=THEME["panel"],
            fg=THEME["muted"],
            anchor="w",
        )
        label.pack(fill="x", padx=12, pady=(12, 4))
        editor = self._text_view(window)
        output = self._text_view(window)
        output.configure(height=9)

        def set_output(text: str) -> None:
            output.configure(state="normal")
            output.delete("1.0", "end")
            output.insert("1.0", text or "(done)")
            output.configure(state="disabled")

        def choose_file() -> None:
            chosen = filedialog.askopenfilename(
                title="Choose a .plain file",
                initialdir=str(ROOT / "examples"),
                filetypes=[("Plain files", "*.plain"), ("All files", "*.*")],
            )
            if not chosen:
                return
            path = Path(chosen)
            state["path"] = path
            label.configure(text=str(path))
            editor.delete("1.0", "end")
            editor.insert("1.0", self._read_text_file(path))

        def check_code() -> None:
            try:
                plain.transpile(
                    editor.get("1.0", "end-1c"),
                    allow_imports=True,
                    allow_system=True,
                    base_dir=(state["path"].parent if state["path"] else ROOT),
                )
                set_output("Debugger check passed. The code can be translated.")
            except Exception as error:
                set_output(f"Debugger found an issue:\n{error}")

        def show_python() -> None:
            try:
                python_code = plain.transpile(
                    editor.get("1.0", "end-1c"),
                    allow_imports=True,
                    allow_system=True,
                    base_dir=(state["path"].parent if state["path"] else ROOT),
                )
                set_output(python_code)
            except Exception as error:
                set_output(f"Could not build Python:\n{error}")

        def run_code() -> None:
            try:
                result = self._run_plain_source(
                    editor.get("1.0", "end-1c"),
                    unsafe=True,
                    allow_imports=True,
                    allow_system=True,
                    filename=str(state["path"] or "<vos debugger>"),
                )
                set_output(result)
            except Exception as error:
                set_output(f"Runtime error:\n{error}")

        def health_check() -> None:
            lines = ["VOS Debugger Health Check", ""]
            required = [
                ROOT / "plain.py",
                VOS_DIR / "desktop.py",
                VOS_DIR / "vos.py",
                VOS_DIR / "apps" / "hello.plain",
                ROOT / "README.md",
                ROOT / "pyproject.toml",
            ]
            for path in required:
                lines.append(f"{'OK' if path.exists() else 'MISSING'}  {path.relative_to(ROOT)}")
            lines.append("")
            for path in [ROOT / "plain.py", VOS_DIR / "desktop.py", VOS_DIR / "vos.py"]:
                try:
                    compile(path.read_text(encoding="utf-8"), str(path), "exec")
                    lines.append(f"OK  Python compile: {path.relative_to(ROOT)}")
                except Exception as error:
                    lines.append(f"FAIL Python compile: {path.relative_to(ROOT)}")
                    lines.append(f"     {error}")
            plain_files = sorted((ROOT / "examples").glob("*.plain")) + sorted((ROOT / "stdlib").glob("*.plain"))
            failures = 0
            for path in plain_files:
                try:
                    plain.transpile(path.read_text(encoding="utf-8"), allow_imports=True, allow_system=True, base_dir=path.parent)
                except Exception as error:
                    failures += 1
                    lines.append(f"FAIL Plain check: {path.relative_to(ROOT)}")
                    lines.append(f"     {error}")
            lines.append("")
            lines.append(f"Plain files checked: {len(plain_files)}")
            lines.append(f"Plain check failures: {failures}")
            lines.append("VOS desktop import: OK")
            set_output("\n".join(lines))

        def diagnose_error() -> None:
            text = editor.get("1.0", "end-1c").strip()
            hints = ["VOS Debugger Diagnosis", ""]
            lowered = text.lower()
            if not text:
                hints.append("Paste an error message or SVANS-AI code into the editor first.")
            if "not recognized" in lowered or "commandnotfound" in lowered:
                hints.append("This looks like a command was typed into PowerShell instead of VOS/SVANS-AI.")
                hints.append("Try launching VOS Desktop or use: svans 'Run 2+3'")
            if "anthropic_api_key" in lowered or "claude" in lowered:
                hints.append("Claude needs ANTHROPIC_API_KEY set in your environment before Ask Claude can work.")
            if "permission" in lowered or "access is denied" in lowered:
                hints.append("A file may be open or locked by another process. Close older VOS windows and retry.")
            if "do not know how" in lowered or "do not understand" in lowered:
                hints.append("The sentence did not match the current SVANS-AI grammar. Use Help or Debugger Show Python to test phrasing.")
            if "import" in lowered and "not allowed" in lowered:
                hints.append("Run the code in trusted mode, or use Sandbox Trusted Run if you trust the program.")
            if len(hints) == 2:
                hints.append("No known pattern matched. Try Check, Show Python, or paste the full error output.")
            set_output("\n".join(hints))

        controls = tk.Frame(window, bg=THEME["panel"])
        controls.pack(fill="x", padx=12, pady=(0, 12))
        self._action_button(controls, "Open File", choose_file).pack(side="left", padx=(0, 8))
        self._action_button(controls, "Check", check_code, accent=True).pack(side="left", padx=(0, 8))
        self._action_button(controls, "Show Python", show_python).pack(side="left", padx=(0, 8))
        self._action_button(controls, "Run Trusted", run_code).pack(side="left", padx=(0, 8))
        self._action_button(controls, "VOS Health Check", health_check).pack(side="left", padx=(0, 8))
        self._action_button(controls, "Diagnose Error", diagnose_error).pack(side="left")
        output.configure(state="disabled")

    def open_actual_projects(self) -> None:
        window = self._window("SVANS Projects", 820, 520)
        tk.Label(
            window,
            text="Installed Vansant applications",
            bg=THEME["panel"], fg=THEME["ink"], font=("Segoe UI", 15, "bold"),
        ).pack(anchor="w", padx=18, pady=(16, 4))
        tk.Label(
            window,
            text="These entries launch the real project builds registered with Guardian Core.",
            bg=THEME["panel"], fg=THEME["muted"],
        ).pack(anchor="w", padx=18, pady=(0, 10))
        body = tk.Frame(window, bg=THEME["panel"]); body.pack(fill="both", expand=True, padx=18, pady=8)
        project_list = tk.Listbox(body, bg=THEME["surface"], fg=THEME["ink"], selectbackground=THEME["accent"], selectforeground="white", relief="flat", font=("Segoe UI", 11), width=28)
        project_list.pack(side="left", fill="y")
        detail_panel = tk.Frame(body, bg=THEME["surface"]); detail_panel.pack(side="left", fill="both", expand=True, padx=(10, 0))
        project_icon = tk.Label(detail_panel, bg=THEME["surface"]); project_icon.pack(anchor="w", padx=14, pady=(14, 0))
        details = tk.Text(detail_panel, bg=THEME["surface"], fg=THEME["ink"], relief="flat", padx=14, pady=14, font=("Consolas", 10), wrap="word")
        details.pack(fill="both", expand=True)
        visible_ids = ["svansai-guide", "debugger-guide", "file-armor", "web-armor", "sandbox-armor"]
        cache: list[dict] = []
        try:
            by_id = {item.get("id"): item for item in self.guardian.modules()}
            cache = [by_id[module_id] for module_id in visible_ids if module_id in by_id]
        except GuardianError as error:
            details.insert("1.0", f"Guardian Core is unavailable:\n{error}")
        for module in cache: project_list.insert("end", module.get("name", module.get("id")))

        def selected() -> dict | None:
            choice = project_list.curselection()
            return cache[choice[0]] if choice else None

        def show_details(_event=None) -> None:
            module = selected()
            if not module: return
            icon_name = {"svansai-guide": "SVANSAI Guide", "debugger-guide": "Debugger", "file-armor": "Shield", "web-armor": "SV Browser", "sandbox-armor": "Sandbox"}.get(str(module.get("id")), "")
            project_icon.configure(image=self._load_project_icon(icon_name, 56) or "")
            lines = [
                str(module.get("name", "")), "",
                f"Project: {module.get('id', '')}", f"Role: {module.get('role', '')}",
                f"Status: {module.get('status', 'available')}", f"Location: {module.get('path', '')}", "",
                "Capabilities:", *[f"• {item}" for item in module.get("capabilities", [])],
            ]
            details.configure(state="normal"); details.delete("1.0", "end"); details.insert("1.0", "\n".join(lines)); details.configure(state="disabled")

        def launch() -> None:
            module = selected()
            if not module:
                messagebox.showinfo("SVANS Projects", "Select a project first."); return
            if module.get("id") == "svansai-guide": self.open_svansai_guide()
            else: self.launch_actual_module(str(module.get("id")))

        actions = tk.Frame(window, bg=THEME["panel"]); actions.pack(fill="x", padx=18, pady=(0, 16))
        self._action_button(actions, "Open Project", launch, accent=True).pack(side="right")
        project_list.bind("<<ListboxSelect>>", show_details)
        project_list.bind("<Double-1>", lambda _event: launch())
        if cache: project_list.selection_set(0); show_details()

    def open_projects(self) -> None:
        window = self._window("Projects", 820, 540)
        tk.Label(
            window,
            text="All SVANS-AI project files currently wired into VOS.",
            bg=THEME["panel"],
            fg=THEME["muted"],
            font=("Segoe UI", 10),
        ).pack(anchor="w", padx=12, pady=(12, 4))
        body = tk.Frame(window, bg=THEME["panel"])
        body.pack(fill="both", expand=True, padx=12, pady=8)
        listbox = tk.Listbox(
            body,
            font=("Consolas", 10),
            relief="flat",
            bg=THEME["surface"],
            fg=THEME["ink"],
            selectbackground=THEME["accent"],
            selectforeground="white",
        )
        listbox.pack(side="left", fill="both", expand=True)
        preview = tk.Text(body, wrap="word", relief="flat", bg=THEME["surface"], fg=THEME["ink"], font=("Consolas", 10))
        preview.pack(side="right", fill="both", expand=True, padx=(10, 0))

        files = (
            sorted((ROOT / "examples").glob("*.plain"))
            + sorted((ROOT / "stdlib").glob("*.plain"))
            + sorted((ROOT / "vos" / "apps").glob("*.plain"))
        )
        for path in files:
            listbox.insert("end", str(path.relative_to(ROOT)))

        def selected_path() -> Path | None:
            selection = listbox.curselection()
            if not selection:
                return None
            return ROOT / listbox.get(selection[0])

        def preview_selected(_event=None) -> None:
            path = selected_path()
            if path is None:
                return
            preview.delete("1.0", "end")
            preview.insert("1.0", self._read_text_file(path))

        def run_selected() -> None:
            path = selected_path()
            if path is None:
                return
            try:
                self._show_output(path.name, self._capture_plain_file(path))
            except Exception as error:
                self._show_output(path.name, f"Run failed:\n{error}")

        def check_selected() -> None:
            path = selected_path()
            if path is None:
                return
            try:
                plain.transpile(path.read_text(encoding="utf-8"), allow_imports=True, allow_system=True, base_dir=path.parent)
                self._show_output(path.name, "Project check passed.")
            except Exception as error:
                self._show_output(path.name, f"Project check failed:\n{error}")

        listbox.bind("<<ListboxSelect>>", preview_selected)
        controls = tk.Frame(window, bg=THEME["panel"])
        controls.pack(fill="x", padx=12, pady=(0, 12))
        self._action_button(controls, "Run", run_selected, accent=True).pack(side="left", padx=(0, 8))
        self._action_button(controls, "Check", check_selected).pack(side="left")
        if files:
            listbox.selection_set(0)
            preview_selected()

    def open_store(self) -> None:
        store_apps.open_store(self)
        return
        window = self._window("App Store", 560, 420)
        installed_path = USER_DIR / "apps" / "installed.txt"
        apps = ["svans-notes", "svans-calculator", "svans-files", "svans-terminal", "svans-ai-lab"]
        tk.Label(window, text="VOS App Store", bg=THEME["panel"], fg=THEME["ink"], font=("Segoe UI", 16, "bold")).pack(
            anchor="w", padx=18, pady=(18, 8)
        )
        listbox = tk.Listbox(
            window,
            font=("Segoe UI", 11),
            relief="flat",
            bg=THEME["surface"],
            fg=THEME["ink"],
            selectbackground=THEME["accent"],
            selectforeground="white",
        )
        listbox.pack(fill="both", expand=True, padx=18, pady=8)
        for app in apps:
            listbox.insert("end", app)

        def install() -> None:
            selected = listbox.curselection()
            if not selected:
                return
            app = listbox.get(selected[0])
            existing = set()
            if installed_path.exists():
                existing = set(installed_path.read_text(encoding="utf-8").splitlines())
            existing.add(app)
            installed_path.write_text("\n".join(sorted(existing)) + "\n", encoding="utf-8")
            messagebox.showinfo("VOS App Store", f"Installed {app}")

        self._action_button(window, "Install Selected", install, accent=True).pack(anchor="e", padx=18, pady=(0, 18))

    def _guardian_tick(self) -> None:
        try:
            self.guardian.heartbeat(
                "vos-desktop",
                version=DESKTOP_VERSION,
                details={"shell_version": VOS_VERSION},
            )
            self.guardian_status = "online"
            self.guardian_error = ""
        except GuardianError as error:
            self.guardian_status = "offline"
            self.guardian_error = str(error)
        if hasattr(self, "guardian_badge"):
            self.guardian_badge.configure(
                text=f"Guardian: {self.guardian_status}",
                bg="#065f46" if self.guardian_status == "online" else "#991b1b",
            )
        self.root.after(10000, self._guardian_tick)

    def open_guardian_center(self) -> None:
        window = self._window("Guardian Center", 900, 540)
        intro = tk.Frame(window, bg=THEME["panel"])
        intro.pack(fill="x", padx=14, pady=(14, 8))
        status = tk.Label(
            intro,
            text="Guardian Core operational status",
            bg=THEME["panel"],
            fg=THEME["ink"],
            font=("Segoe UI", 14, "bold"),
        )
        status.pack(side="left")
        detail = tk.Label(intro, text="", bg=THEME["panel"], fg=THEME["muted"])
        detail.pack(side="right")

        columns = ("name", "role", "status", "heartbeat", "commands")
        tree = ttk.Treeview(window, columns=columns, show="headings", height=14)
        headings = {
            "name": "Module",
            "role": "VOS Role",
            "status": "Status",
            "heartbeat": "Last heartbeat",
            "commands": "Commands",
        }
        widths = {"name": 190, "role": 160, "status": 90, "heartbeat": 210, "commands": 80}
        for column in columns:
            tree.heading(column, text=headings[column])
            tree.column(column, width=widths[column], anchor="w")
        tree.pack(fill="both", expand=True, padx=14, pady=8)

        module_cache: dict[str, dict] = {}

        def selected_module() -> dict | None:
            selected = tree.selection()
            return module_cache.get(selected[0]) if selected else None

        def refresh() -> None:
            try:
                health = self.guardian.health()
                modules = self.guardian.modules()
                status.configure(text=f"Guardian Core {health.get('version', '?')} — online", fg="#047857")
                detail.configure(text=f"{len(modules)} registered modules")
                tree.delete(*tree.get_children())
                module_cache.clear()
                for module in modules:
                    module_id = str(module["id"])
                    module_cache[module_id] = module
                    heartbeat = module.get("last_heartbeat") or {}
                    tree.insert(
                        "",
                        "end",
                        iid=module_id,
                        values=(
                            module.get("name", module_id),
                            module.get("role", ""),
                            module.get("status", "unknown"),
                            heartbeat.get("observed_at", "Never"),
                            module.get("pending_commands", 0),
                        ),
                    )
            except GuardianError as error:
                status.configure(text="Guardian Core — offline", fg="#b91c1c")
                detail.configure(text=str(error))

        def launch_selected(_event=None) -> None:
            module = selected_module()
            if not module:
                messagebox.showinfo("Guardian Center", "Select a module first.")
                return
            if module.get("id") == "vos-desktop":
                messagebox.showinfo("Guardian Center", "VOS Desktop is already running.")
                return
            try:
                process = self.guardian.launch(module)
                self.guardian.command(str(module["id"]), "launch-observed", {"pid": process.pid})
                messagebox.showinfo("Guardian Center", f"Started {module.get('name')} (PID {process.pid}).")
                window.after(750, refresh)
            except (GuardianError, OSError) as error:
                messagebox.showerror("Guardian Center", f"Could not launch module:\n{error}")

        def request_status() -> None:
            module = selected_module()
            if not module:
                messagebox.showinfo("Guardian Center", "Select a module first.")
                return
            try:
                result = self.guardian.command(str(module["id"]), "report-status")
                command_id = result.get("command", {}).get("id", "queued")
                messagebox.showinfo("Guardian Center", f"Status command queued: {command_id}")
                refresh()
            except GuardianError as error:
                messagebox.showerror("Guardian Center", str(error))

        def request_diagnostic() -> None:
            module = selected_module()
            if not module or module.get("id") != "debugger-guide":
                messagebox.showinfo("Guardian Center", "Select SVANSAI Debugger to request a diagnostic.")
                return
            try:
                result = self.guardian.command("debugger-guide", "scan-network")
                command_id = result.get("command", {}).get("id", "queued")
                messagebox.showinfo("Guardian Center", f"Network diagnostic queued: {command_id}")
                refresh()
            except GuardianError as error:
                messagebox.showerror("Guardian Center", str(error))

        def request_guide() -> None:
            module = selected_module()
            if not module or module.get("id") != "svansai-guide":
                messagebox.showinfo("Guardian Center", "Select SVANSAI Guide to request an explanation.")
                return
            try:
                result = self.guardian.command(
                    "svansai-guide",
                    "explain-incident",
                    {"summary": "Review the latest VOS operational evidence and prepare user guidance."},
                )
                command_id = result.get("command", {}).get("id", "queued")
                messagebox.showinfo("Guardian Center", f"Guide explanation queued: {command_id}")
                refresh()
            except GuardianError as error:
                messagebox.showerror("Guardian Center", str(error))

        def open_log() -> None:
            path = self.guardian.RUNTIME_DIR / "guardian.log" if hasattr(self.guardian, "RUNTIME_DIR") else ROOT.parent / "runtime" / "guardian.log"
            try:
                lines = path.read_text(encoding="utf-8").splitlines()[-200:]
                self._show_output("Guardian Core Log", "\n".join(lines))
            except OSError as error:
                messagebox.showerror("Guardian Center", f"Could not read log:\n{error}")

        actions = tk.Frame(window, bg=THEME["panel"])
        actions.pack(fill="x", padx=14, pady=(0, 14))
        self._action_button(actions, "Refresh", refresh).pack(side="left", padx=(0, 6))
        self._action_button(actions, "Launch Module", launch_selected, accent=True).pack(side="left", padx=6)
        self._action_button(actions, "Request Status", request_status).pack(side="left", padx=6)
        self._action_button(actions, "Run Network Diagnostic", request_diagnostic).pack(side="left", padx=6)
        self._action_button(actions, "Ask Guide", request_guide).pack(side="left", padx=6)
        self._action_button(actions, "View Guardian Log", open_log).pack(side="right")
        tree.bind("<Double-1>", launch_selected)
        refresh()

    def open_network_center(self) -> None:
        operations_ui.open_network_center(self)

    def open_beta_center(self) -> None:
        operations_ui.open_beta_center(self)

    def open_incident_center(self) -> None:
        if beta_manager.load().get("enrolled"):
            beta_manager.record("journey-completed", {"name": "incident-review"})
        window = self._window("Incident Center", 1040, 620)
        header = tk.Frame(window, bg=THEME["panel"])
        header.pack(fill="x", padx=14, pady=(14, 8))
        title = tk.Label(
            header,
            text="Unified VOS incidents",
            bg=THEME["panel"],
            fg=THEME["ink"],
            font=("Segoe UI", 14, "bold"),
        )
        title.pack(side="left")
        summary = tk.Label(header, text="", bg=THEME["panel"], fg=THEME["muted"])
        summary.pack(side="right")

        columns = ("severity", "status", "module", "kind", "summary", "updated")
        tree = ttk.Treeview(window, columns=columns, show="headings", height=17)
        labels = {
            "severity": "Severity", "status": "Status", "module": "Source",
            "kind": "Type", "summary": "Latest summary", "updated": "Updated",
        }
        widths = {"severity": 75, "status": 100, "module": 120, "kind": 145, "summary": 380, "updated": 170}
        for column in columns:
            tree.heading(column, text=labels[column])
            tree.column(column, width=widths[column], anchor="w")
        tree.pack(fill="both", expand=True, padx=14, pady=8)

        cache: dict[str, dict] = {}

        def selected() -> dict | None:
            selection = tree.selection()
            return cache.get(selection[0]) if selection else None

        def refresh() -> None:
            try:
                incidents = self.guardian.incidents(limit=200)
                cache.clear()
                tree.delete(*tree.get_children())
                for incident in incidents:
                    incident_id = str(incident["id"])
                    cache[incident_id] = incident
                    tree.insert("", "end", iid=incident_id, values=(
                        incident.get("severity", ""), incident.get("status", ""),
                        incident.get("module_id", ""), incident.get("kind", ""),
                        incident.get("summary", ""), incident.get("updated_at", ""),
                    ))
                open_count = sum(1 for item in incidents if item.get("status") in {"open", "acknowledged"})
                summary.configure(text=f"{open_count} active · {len(incidents)} total")
            except GuardianError as error:
                summary.configure(text=f"Guardian unavailable: {error}")

        def apply(action: str) -> None:
            incident = selected()
            if not incident:
                messagebox.showinfo("Incident Center", "Select an incident first.")
                return
            try:
                self.guardian.incident_action(str(incident["id"]), action)
                refresh()
            except GuardianError as error:
                messagebox.showerror("Incident Center", str(error))

        def show_evidence() -> None:
            try:
                records = self.guardian.evidence_feed(limit=200)
                lines = ["VOS Evidence Timeline", ""]
                for item in records:
                    lines.append(
                        f"[{item.get('observed_at', '')}] {str(item.get('severity', '')).upper()} "
                        f"{item.get('module_id', '')} / {item.get('kind', '')}\n{item.get('summary', '')}\n"
                    )
                self._show_output("Evidence Timeline", "\n".join(lines) if len(lines) > 2 else "No evidence recorded.")
            except GuardianError as error:
                messagebox.showerror("Incident Center", str(error))

        actions = tk.Frame(window, bg=THEME["panel"])
        actions.pack(fill="x", padx=14, pady=(0, 14))
        self._action_button(actions, "Refresh", refresh).pack(side="left", padx=(0, 5))
        self._action_button(actions, "Acknowledge", lambda: apply("acknowledge"), accent=True).pack(side="left", padx=5)
        self._action_button(actions, "Resolve", lambda: apply("resolve")).pack(side="left", padx=5)
        self._action_button(actions, "Ask Guide", lambda: apply("ask-guide")).pack(side="left", padx=5)
        self._action_button(actions, "Run Diagnostic", lambda: apply("run-diagnostic")).pack(side="left", padx=5)
        self._action_button(actions, "Rescan Files", lambda: apply("rescan-files")).pack(side="left", padx=5)
        self._action_button(actions, "Evidence Timeline", show_evidence).pack(side="right")
        refresh()

    def open_settings(self) -> None:
        window = self._window("Settings", 560, 360)
        values = [
            ("System", "Vansant Operating System"),
            ("VOS Shell", VOS_VERSION),
            ("VOS Desktop", DESKTOP_VERSION),
            ("SVANS-AI", plain.VERSION),
            ("Guardian Core", self.guardian_status),
            ("Guardian URL", self.guardian.base_url),
            ("Project", str(ROOT)),
            ("User files", str(USER_DIR)),
        ]
        tk.Label(window, text="Settings", bg=THEME["panel"], fg=THEME["ink"], font=("Segoe UI", 16, "bold")).pack(
            anchor="w", padx=18, pady=(18, 10)
        )
        for label, value in values:
            row = tk.Frame(window, bg=THEME["panel"])
            row.pack(fill="x", padx=18, pady=4)
            tk.Label(row, text=label, bg=THEME["panel"], fg=THEME["ink"], width=14, anchor="w", font=("Segoe UI", 10, "bold")).pack(
                side="left"
            )
            tk.Label(row, text=value, bg=THEME["panel"], fg=THEME["muted"], anchor="w", wraplength=360).pack(side="left", fill="x", expand=True)

    def run_hello_app(self) -> None:
        app = APPS_DIR / "hello.plain"
        try:
            output = self._capture_plain_file(app)
        except Exception as error:
            output = f"Could not run {app}: {error}"
        self._show_output("Hello App", output)

    def run(self) -> int:
        self.root.mainloop()
        return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="VOS Desktop")
    parser.add_argument("--smoke", action="store_true", help="verify the desktop can load without opening a window")
    args = parser.parse_args(argv)
    USER_DIR.mkdir(parents=True, exist_ok=True)
    if args.smoke:
        print(f"VOS Desktop {DESKTOP_VERSION} ready | SVANS-AI {plain.VERSION}")
        return 0
    return VOSDesktop().run()


if __name__ == "__main__":
    raise SystemExit(main())
