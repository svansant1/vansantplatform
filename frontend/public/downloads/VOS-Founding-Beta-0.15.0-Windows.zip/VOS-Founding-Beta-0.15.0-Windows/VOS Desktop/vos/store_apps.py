"""Functional local applications distributed through the VOS App Store."""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tkinter as tk
import zipfile
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from PIL import ImageGrab

IDENTITY = Path(__file__).resolve().parents[2]
CATALOG_PATH = IDENTITY / "config" / "app_catalog.json"
INSTALLED_PATH = IDENTITY / "VOS Desktop" / "vos" / "user" / "apps" / "installed.json"


def catalog() -> list[dict]:
    return json.loads(CATALOG_PATH.read_text(encoding="utf-8")).get("apps", [])


def installed() -> set[str]:
    try: return set(json.loads(INSTALLED_PATH.read_text(encoding="utf-8")).get("apps", []))
    except (OSError, ValueError): return set()


def save_installed(values: set[str]) -> None:
    INSTALLED_PATH.parent.mkdir(parents=True, exist_ok=True)
    INSTALLED_PATH.write_text(json.dumps({"schema_version": 1, "apps": sorted(values)}, indent=2), encoding="utf-8")


def installed_launchers(app) -> list[tuple[str, object]]:
    by_id = {item["id"]: item for item in catalog()}
    return [(by_id[item_id]["name"], lambda value=item_id: launch(app, value)) for item_id in sorted(installed()) if item_id in by_id]


def launch(app, app_id: str) -> None:
    handlers = {
        "system-monitor": system_monitor, "log-viewer": log_viewer, "backup-center": backup_center,
        "archive-manager": archive_manager, "screenshot-tool": screenshot_tool,
        "clipboard-history": clipboard_history, "document-reader": document_reader, "theme-center": theme_center,
    }
    handler = handlers.get(app_id)
    if handler: handler(app)
    else: messagebox.showerror("VOS App Store", "This application handler is unavailable.")


def open_store(app) -> None:
    window = app._window("App Store", 820, 560); theme = app.THEME
    tk.Label(window, text="VOS App Store", bg=theme["panel"], fg=theme["ink"], font=("Segoe UI", 17, "bold")).pack(anchor="w", padx=18, pady=(14, 2))
    tk.Label(window, text="Trusted local applications that extend the Vansant OS experience.", bg=theme["panel"], fg=theme["muted"]).pack(anchor="w", padx=18, pady=(0, 10))
    body = tk.Frame(window, bg=theme["panel"]); body.pack(fill="both", expand=True, padx=18)
    apps = catalog(); values = installed()
    listbox = tk.Listbox(body, bg=theme["surface"], fg=theme["ink"], selectbackground=theme["accent"], relief="flat", font=("Segoe UI", 10), width=30)
    listbox.pack(side="left", fill="y")
    details = tk.Text(body, bg=theme["surface"], fg=theme["ink"], relief="flat", padx=14, pady=14, wrap="word", font=("Segoe UI", 10)); details.pack(side="left", fill="both", expand=True, padx=(10, 0))

    def refill() -> None:
        listbox.delete(0, "end")
        for item in apps: listbox.insert("end", f"{'✓ ' if item['id'] in values else ''}{item['name']}")

    def selected() -> dict | None:
        choice = listbox.curselection(); return apps[choice[0]] if choice else None

    def show(_event=None) -> None:
        item = selected()
        if not item: return
        lines = [item["name"], "", item["description"], "", f"Category: {item['category']}", f"Status: {'Installed' if item['id'] in values else 'Available'}", "", "Permissions:", *[f"• {value}" for value in item.get("permissions", [])]]
        details.configure(state="normal"); details.delete("1.0", "end"); details.insert("1.0", "\n".join(lines)); details.configure(state="disabled")

    def install() -> None:
        item = selected()
        if not item: return
        permission_text = "\n".join(f"• {value}" for value in item.get("permissions", [])) or "No special permissions."
        if messagebox.askyesno("Install application", f"Install {item['name']}?\n\nPermissions:\n{permission_text}"):
            values.add(item["id"]); save_installed(values); refill(); show()

    def remove() -> None:
        item = selected()
        if item and item["id"] in values and messagebox.askyesno("Uninstall application", f"Uninstall {item['name']}?"):
            values.remove(item["id"]); save_installed(values); refill(); show()

    def open_selected() -> None:
        item = selected()
        if not item: return
        if item["id"] not in values: messagebox.showinfo("VOS App Store", "Install this application first."); return
        launch(app, item["id"])

    actions = tk.Frame(window, bg=theme["panel"]); actions.pack(fill="x", padx=18, pady=14)
    app._action_button(actions, "Install", install, accent=True).pack(side="left", padx=(0, 6)); app._action_button(actions, "Open", open_selected).pack(side="left", padx=6); app._action_button(actions, "Uninstall", remove).pack(side="left", padx=6)
    listbox.bind("<<ListboxSelect>>", show); listbox.bind("<Double-1>", lambda _e: open_selected()); refill()
    if apps: listbox.selection_set(0); show()


def system_monitor(app) -> None:
    window = app._window("System Monitor", 760, 520); output = app._text_view(window, editable=False)
    def refresh() -> None:
        script = "$os=Get-CimInstance Win32_OperatingSystem;$cpu=(Get-CimInstance Win32_Processor|Measure-Object LoadPercentage -Average).Average;$top=Get-Process|Sort-Object CPU -Descending|Select-Object -First 8 Name,Id,CPU,WorkingSet64;[pscustomobject]@{cpu=$cpu;total_memory=$os.TotalVisibleMemorySize;free_memory=$os.FreePhysicalMemory;uptime_seconds=((Get-Date)-$os.LastBootUpTime).TotalSeconds;top_processes=$top}|ConvertTo-Json -Depth 5 -Compress"
        result = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], capture_output=True, text=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        try:
            data = json.loads(result.stdout); used = (data["total_memory"] - data["free_memory"]) / data["total_memory"] * 100
            lines = [f"CPU load: {data['cpu']}%", f"Memory used: {used:.1f}%", f"System uptime: {data['uptime_seconds']/3600:.1f} hours", "", "Top processes:"]
            lines.extend(f"{item['Name']:<28} PID {item['Id']:<7} Memory {item['WorkingSet64']/1048576:>7.1f} MB" for item in data.get("top_processes", []))
        except Exception: lines = ["System information unavailable.", result.stderr]
        output.configure(state="normal"); output.delete("1.0", "end"); output.insert("1.0", "\n".join(lines)); output.configure(state="disabled")
    controls = tk.Frame(window, bg=app.THEME["panel"]); controls.pack(fill="x", padx=12, pady=10); app._action_button(controls, "Refresh", refresh, accent=True).pack(side="right"); refresh()


def log_viewer(app) -> None:
    window = app._window("VOS Log Viewer", 860, 560); runtime = IDENTITY / "runtime"
    paths = [path for path in runtime.iterdir() if path.is_file() and path.suffix in {".log", ".jsonl", ".json"}]
    choice = tk.StringVar(value=paths[0].name if paths else ""); selector = ttk.Combobox(window, textvariable=choice, values=[p.name for p in paths], state="readonly"); selector.pack(fill="x", padx=12, pady=10)
    output = app._text_view(window, editable=False)
    def refresh(_event=None) -> None:
        path = runtime / choice.get(); content = path.read_text(encoding="utf-8", errors="replace")[-300000:] if path.exists() else "No log selected."
        output.configure(state="normal"); output.delete("1.0", "end"); output.insert("1.0", content); output.configure(state="disabled")
    selector.bind("<<ComboboxSelected>>", refresh); refresh()


def backup_center(app) -> None:
    window = app._window("Backup Center", 720, 470); output = app._text_view(window, editable=False); manager = IDENTITY / "VOS Platform" / "lifecycle" / "vos_lifecycle.py"
    def run(action: str) -> None:
        result = subprocess.run([sys.executable, str(manager), action], capture_output=True, text=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        output.configure(state="normal"); output.delete("1.0", "end"); output.insert("1.0", result.stdout or result.stderr); output.configure(state="disabled")
    controls = tk.Frame(window, bg=app.THEME["panel"]); controls.pack(fill="x", padx=12, pady=10)
    for text, action in (("Verify", "verify"), ("Create Backup", "backup"), ("Support Bundle", "support-bundle")): app._action_button(controls, text, lambda value=action: run(value), accent=action == "backup").pack(side="left", padx=4)
    run("verify")


def archive_manager(app) -> None:
    window = app._window("Archive Manager", 650, 360); status = tk.Label(window, text="Create or extract ZIP archives using folders you select.", bg=app.THEME["panel"], fg=app.THEME["muted"], wraplength=580); status.pack(padx=18, pady=30)
    def create() -> None:
        folder = filedialog.askdirectory(title="Choose folder to archive")
        if not folder: return
        destination = filedialog.asksaveasfilename(title="Save ZIP archive", defaultextension=".zip", filetypes=[("ZIP archive", "*.zip")])
        if destination: shutil.make_archive(str(Path(destination).with_suffix("")), "zip", folder); status.configure(text=f"Created {destination}")
    def extract() -> None:
        archive = filedialog.askopenfilename(title="Choose ZIP archive", filetypes=[("ZIP archive", "*.zip")]); destination = filedialog.askdirectory(title="Choose extraction folder") if archive else ""
        if archive and destination:
            with zipfile.ZipFile(archive) as source:
                root = Path(destination).resolve()
                if any(root not in (root / name).resolve().parents and (root / name).resolve() != root for name in source.namelist()): raise ValueError("Unsafe archive entry")
                source.extractall(root)
            status.configure(text=f"Extracted to {destination}")
    controls = tk.Frame(window, bg=app.THEME["panel"]); controls.pack(); app._action_button(controls, "Create ZIP", create, accent=True).pack(side="left", padx=6); app._action_button(controls, "Extract ZIP", extract).pack(side="left", padx=6)


def screenshot_tool(app) -> None:
    app.root.update_idletasks(); x=app.root.winfo_rootx(); y=app.root.winfo_rooty(); width=app.root.winfo_width(); height=app.root.winfo_height()
    folder = IDENTITY / "VOS Desktop" / "vos" / "user" / "screenshots"; folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"vos-{datetime.now():%Y%m%d-%H%M%S}.png"; ImageGrab.grab((x, y, x+width, y+height)).save(path); messagebox.showinfo("Screenshot Tool", f"Saved:\n{path}")


def clipboard_history(app) -> None:
    window=app._window("Clipboard History", 600, 470); values=[]; listbox=tk.Listbox(window,bg=app.THEME["surface"],fg=app.THEME["ink"],selectbackground=app.THEME["accent"]); listbox.pack(fill="both",expand=True,padx=12,pady=12)
    def poll() -> None:
        if not window.winfo_exists(): return
        try:
            value=app.root.clipboard_get()
            if value and (not values or values[0] != value): values.insert(0,value); del values[50:]; listbox.delete(0,"end"); [listbox.insert("end",item[:160].replace("\n"," ")) for item in values]
        except tk.TclError: pass
        window.after(1000,poll)
    controls=tk.Frame(window,bg=app.THEME["panel"]); controls.pack(fill="x",padx=12,pady=(0,12)); app._action_button(controls,"Clear",lambda:(values.clear(),listbox.delete(0,"end"))).pack(side="right"); poll()


def document_reader(app) -> None:
    path=filedialog.askopenfilename(title="Open document",filetypes=[("Readable documents","*.txt *.md *.json *.py *.js *.ts *.ps1 *.csv"),("All files","*.*")])
    if not path:return
    window=app._window(f"Reader — {Path(path).name}",820,560); output=app._text_view(window,editable=False); output.configure(state="normal"); output.insert("1.0",Path(path).read_text(encoding="utf-8",errors="replace")); output.configure(state="disabled")


def theme_center(app) -> None:
    window=app._window("Theme Center",600,380); tk.Label(window,text="Choose a VOS accent",bg=app.THEME["panel"],fg=app.THEME["ink"],font=("Segoe UI",15,"bold")).pack(pady=24)
    choices=[("Violet","#8b5cf6"),("Blue","#2563eb"),("Teal","#0d9488"),("Orange","#ea580c"),("Rose","#e11d48")]
    row=tk.Frame(window,bg=app.THEME["panel"]); row.pack()
    def apply(color:str)->None: app.THEME["accent"]=color; app.vos_button.configure(bg=color); messagebox.showinfo("Theme Center","Accent applied to new and primary VOS controls.")
    for name,color in choices: tk.Button(row,text=name,command=lambda value=color:apply(value),bg=color,fg="white",relief="flat",padx=14,pady=10).pack(side="left",padx=5)
