"""Small standard-library client used by VOS Desktop to control Guardian Core."""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

DESKTOP_ROOT = Path(__file__).resolve().parents[1]
IDENTITY_ROOT = DESKTOP_ROOT.parent
RUNTIME_DIR = IDENTITY_ROOT / "runtime"
TOKEN_PATH = RUNTIME_DIR / "guardian.token"
CORE_SCRIPT = IDENTITY_ROOT / "VOS Platform" / "guardian_core" / "vos_guardian.py"
BASE_URL = "http://127.0.0.1:8765"


class GuardianError(RuntimeError):
    pass


class GuardianClient:
    def __init__(self, base_url: str = BASE_URL) -> None:
        self.base_url = base_url.rstrip("/")
        self.process: subprocess.Popen[Any] | None = None

    def _token(self) -> str:
        return TOKEN_PATH.read_text(encoding="utf-8").strip() if TOKEN_PATH.exists() else ""

    def request(self, method: str, path: str, payload: dict[str, Any] | None = None, *, authenticated: bool = True) -> dict[str, Any]:
        data = json.dumps(payload).encode("utf-8") if payload is not None else None
        headers = {"Accept": "application/json"}
        if data is not None:
            headers["Content-Type"] = "application/json"
        if authenticated:
            headers["Authorization"] = f"Bearer {self._token()}"
        request = urllib.request.Request(self.base_url + path, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(request, timeout=1.5) as response:
                return json.loads(response.read().decode("utf-8"))
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as error:
            raise GuardianError(str(error)) from error

    def health(self) -> dict[str, Any]:
        return self.request("GET", "/v1/health", authenticated=False)

    def ensure_started(self, timeout: float = 5.0) -> dict[str, Any]:
        try:
            health = self.health()
            self.modules()
            return health
        except GuardianError:
            pass
        if not CORE_SCRIPT.exists():
            raise GuardianError(f"Guardian Core not found: {CORE_SCRIPT}")
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        self.process = subprocess.Popen(
            [sys.executable, str(CORE_SCRIPT)],
            cwd=str(CORE_SCRIPT.parent),
            creationflags=creationflags,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            time.sleep(0.15)
            try:
                health = self.health()
                self.modules()
                return health
            except GuardianError:
                if self.process.poll() is not None:
                    break
        raise GuardianError("Guardian Core did not start with this installation's security token; inspect runtime/guardian.log")

    def modules(self) -> list[dict[str, Any]]:
        return list(self.request("GET", "/v1/modules").get("modules", []))

    def heartbeat(self, module_id: str, *, version: str, state: str = "running", details: dict[str, Any] | None = None) -> dict[str, Any]:
        return self.request("POST", f"/v1/modules/{module_id}/heartbeat", {
            "version": version,
            "state": state,
            "details": details or {},
        })

    def command(self, module_id: str, action: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        return self.request("POST", f"/v1/modules/{module_id}/commands", {"action": action, "payload": payload or {}})

    def evidence(self, module_id: str, summary: str, *, kind: str = "operational", severity: str = "info", details: dict[str, Any] | None = None) -> dict[str, Any]:
        return self.request("POST", "/v1/evidence", {
            "module_id": module_id,
            "kind": kind,
            "severity": severity,
            "summary": summary,
            "details": details or {},
        })

    def evidence_feed(self, *, limit: int = 100, severity: str = "") -> list[dict[str, Any]]:
        query = urllib.parse.urlencode({"limit": limit, **({"severity": severity} if severity else {})})
        return list(self.request("GET", f"/v1/evidence?{query}").get("evidence", []))

    def incidents(self, *, status: str = "", limit: int = 100) -> list[dict[str, Any]]:
        query = urllib.parse.urlencode({"limit": limit, **({"status": status} if status else {})})
        return list(self.request("GET", f"/v1/incidents?{query}").get("incidents", []))

    def incident_action(self, incident_id: str, action: str) -> dict[str, Any]:
        return self.request("POST", f"/v1/incidents/{incident_id}/actions", {"action": action})

    def launch(self, module: dict[str, Any]) -> subprocess.Popen[Any]:
        relative = Path(str(module.get("path", "")))
        cwd = (IDENTITY_ROOT / relative).resolve()
        if IDENTITY_ROOT.resolve() not in cwd.parents and cwd != IDENTITY_ROOT.resolve():
            raise GuardianError("Module path leaves the VOS Identity workspace")
        command = [str(part) for part in module.get("launch", [])]
        if not command:
            raise GuardianError("Module does not define a launch command")
        executable = Path(command[0])
        if not executable.is_absolute() and (cwd / executable).exists():
            command[0] = str(cwd / executable)
        module_environment = os.environ.copy()
        module_environment.update({
            "VOS_GUARDIAN_URL": self.base_url,
            "VOS_GUARDIAN_TOKEN": self._token(),
            "VOS_IDENTITY_ROOT": str(IDENTITY_ROOT),
            "VOS_MODULE_ID": str(module.get("id", "")),
        })
        background_command = Path(command[0]).name.lower() in {"npm", "npm.cmd", "node", "node.exe", "python", "python.exe"}
        process = subprocess.Popen(
            command,
            cwd=str(cwd),
            env=module_environment,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if background_command else 0,
        )
        self.evidence("vos-desktop", f"Launched {module.get('name', module.get('id'))}", details={"module_id": module.get("id"), "pid": process.pid})
        return process
