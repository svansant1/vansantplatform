#!/usr/bin/env python3
"""VOS: Vansant Operating System environment powered by SVANS-AI."""

from __future__ import annotations

import argparse
import datetime as _dt
import os
import shlex
import subprocess
import sys
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import plain

VOS_VERSION = "0.1.0"


class VOS:
    def __init__(self) -> None:
        self.cwd = Path.cwd()
        self.running = True

    def banner(self) -> str:
        return (
            "V.O.S - Vansant Operating System\n"
            f"Version {VOS_VERSION} | Powered by SVANS-AI {plain.VERSION}\n"
            "Type help to see commands. Type exit to leave."
        )

    def help(self) -> str:
        return """VOS commands:
  help                         Show this screen
  about                        Show VOS identity
  time                         Show current time
  date                         Show current date
  where                        Show current folder
  cd <folder>                  Change VOS folder
  scan [folder]                List files
  read <file>                  Read a text file
  write <file> <text>          Write text to a file
  open <target>                Open a file, folder, app, or URL
  run <Svans sentence>         Run a Svans sentence
  svans <Svans sentence>       Same as run
  system <command>             Run a system command
  app hello                    Run the starter VOS app
  exit                         Leave VOS
"""

    def execute(self, raw: str) -> str:
        raw = raw.strip()
        if not raw:
            return ""
        try:
            parts = shlex.split(raw)
        except ValueError as error:
            return f"Could not read command: {error}"

        command = parts[0].lower()
        args = parts[1:]

        try:
            if command in {"exit", "quit", "stop"}:
                self.running = False
                return "Shutting down VOS."
            if command == "help":
                return self.help()
            if command == "about":
                return "VOS is an SVANS-AI-powered operating environment for files, apps, automation, and sentence commands."
            if command == "time":
                return _dt.datetime.now().strftime("%I:%M:%S %p")
            if command == "date":
                return _dt.date.today().isoformat()
            if command == "where":
                return str(self.cwd)
            if command == "cd":
                if not args:
                    return "Usage: cd <folder>"
                target = (self.cwd / args[0]).resolve()
                if not target.exists() or not target.is_dir():
                    return f"Folder not found: {target}"
                self.cwd = target
                return str(self.cwd)
            if command == "scan":
                target = (self.cwd / args[0]).resolve() if args else self.cwd
                if not target.exists():
                    return f"Not found: {target}"
                if target.is_file():
                    return target.name
                names = [f"{item.name}/" if item.is_dir() else item.name for item in sorted(target.iterdir())]
                return "\n".join(names)
            if command == "read":
                if not args:
                    return "Usage: read <file>"
                return (self.cwd / args[0]).read_text(encoding="utf-8")
            if command == "write":
                if len(args) < 2:
                    return "Usage: write <file> <text>"
                target = self.cwd / args[0]
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(" ".join(args[1:]), encoding="utf-8")
                return f"Wrote {target}"
            if command == "open":
                if not args:
                    return "Usage: open <target>"
                target = args[0]
                if target.startswith(("http://", "https://")):
                    webbrowser.open(target)
                    return f"Opened {target}"
                os.startfile(str((self.cwd / target).resolve()) if os.name == "nt" else target)
                return f"Opened {target}"
            if command in {"run", "svans"}:
                if not args:
                    return "Usage: run <Svans sentence>"
                sentence = raw.split(" ", 1)[1]
                plain.run_sentence(sentence, unsafe=True, allow_imports=True, allow_system=True)
                return ""
            if command == "system":
                if not args:
                    return "Usage: system <command>"
                completed = subprocess.run(
                    raw.split(" ", 1)[1],
                    cwd=self.cwd,
                    shell=True,
                    text=True,
                    capture_output=True,
                )
                return (completed.stdout + completed.stderr).strip()
            if command == "app" and args == ["hello"]:
                app = ROOT / "vos" / "apps" / "hello.plain"
                plain.run_plain(app, unsafe=True, allow_imports=True, allow_system=True)
                return ""
            return f"Unknown VOS command: {command}. Type help."
        except Exception as error:
            return f"VOS error: {error}"

    def loop(self) -> int:
        print(self.banner())
        while self.running:
            try:
                raw = input("VOS> ")
            except (EOFError, KeyboardInterrupt):
                print()
                break
            output = self.execute(raw)
            if output:
                print(output)
        return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="VOS - Vansant Operating System")
    parser.add_argument("-c", "--command", help="run one VOS command and exit")
    parser.add_argument("--no-banner", action="store_true", help="do not print the boot banner")
    args = parser.parse_args(argv)

    vos = VOS()
    if args.command:
        if not args.no_banner:
            print(vos.banner())
        output = vos.execute(args.command)
        if output:
            print(output)
        return 0
    return vos.loop()


if __name__ == "__main__":
    raise SystemExit(main())
