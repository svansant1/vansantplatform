"""Phase 11-13 Network Armor and Founding Beta windows."""

from __future__ import annotations

import json
import subprocess
import sys
import tkinter as tk
from pathlib import Path
from tkinter import messagebox

import beta_manager
from guardian_client import GuardianError


def open_network_center(app) -> None:
    theme = app.THEME
    window = app._window("Network Armor", 760, 530)
    identity = Path(__file__).resolve().parents[2]
    config_path = identity / "config" / "network_armor.json"
    state_path = identity / "runtime" / "network_armor_state.json"
    config = json.loads(config_path.read_text(encoding="utf-8"))
    consent = tk.BooleanVar(value=bool(config.get("consent", {}).get("accepted")))
    tk.Label(window, text="Network posture and tunnel readiness", bg=theme["panel"], fg=theme["ink"], font=("Segoe UI", 15, "bold")).pack(anchor="w", padx=18, pady=(16, 4))
    tk.Label(window, text="Monitors Windows Firewall, DNS, and process connection counts. This release is not a VPN and does not claim anonymity.", bg=theme["panel"], fg=theme["muted"], wraplength=710, justify="left").pack(anchor="w", padx=18, pady=(0, 10))
    output = tk.Text(window, height=14, bg=theme["surface"], fg=theme["ink"], relief="flat", padx=10, pady=10, font=("Consolas", 9))
    output.pack(fill="both", expand=True, padx=18, pady=8)

    def refresh() -> None:
        state = {}
        try: state = json.loads(state_path.read_text(encoding="utf-8"))
        except (OSError, ValueError): pass
        status = state.get("status", {})
        lines = [
            f"Consent: {'accepted' if consent.get() else 'required'}",
            f"Tunnel provider: {status.get('tunnel_provider', 'not-configured')}",
            f"Tunnel connected: {status.get('tunnel_connected', False)}",
            f"Protective DNS: {status.get('protective_dns_mode', 'observe-only')}",
            f"Emergency bypass: {status.get('emergency_bypass', False)}",
            f"DNS interfaces: {status.get('dns_interface_count', 'not measured')}",
            f"Established connections: {status.get('established_connection_count', 'not measured')}",
            "Remote destinations retained: false", "",
            "Open tunnel gates: provider, kill switch, split tunneling, DNS leak protection, and reconnect testing.",
        ]
        output.configure(state="normal"); output.delete("1.0", "end"); output.insert("1.0", "\n".join(lines)); output.configure(state="disabled")

    def save_consent() -> None:
        current = json.loads(config_path.read_text(encoding="utf-8"))
        current.setdefault("consent", {})["accepted"] = consent.get()
        current["consent"]["accepted_at"] = beta_manager.now() if consent.get() else None
        config_path.write_text(json.dumps(current, indent=2), encoding="utf-8")
        messagebox.showinfo("Network Armor", "Network monitoring consent updated."); refresh()

    def start_agent() -> None:
        try:
            module = next(item for item in app.guardian.modules() if item.get("id") == "network-armor")
            process = app.guardian.launch(module)
            messagebox.showinfo("Network Armor", f"Network Armor started (PID {process.pid})."); window.after(1000, refresh)
        except (GuardianError, OSError, StopIteration) as error: messagebox.showerror("Network Armor", str(error))

    def command(action: str) -> None:
        try:
            app.guardian.command("network-armor", action)
            messagebox.showinfo("Network Armor", f"{action} queued."); window.after(1500, refresh)
        except GuardianError as error: messagebox.showerror("Network Armor", str(error))

    row = tk.Frame(window, bg=theme["panel"]); row.pack(fill="x", padx=18)
    tk.Checkbutton(row, text="Allow local network posture monitoring", variable=consent, bg=theme["panel"], fg=theme["ink"], activebackground=theme["panel"], activeforeground=theme["ink"], selectcolor=theme["surface"]).pack(side="left")
    app._action_button(row, "Save Consent", save_consent).pack(side="right")
    actions = tk.Frame(window, bg=theme["panel"]); actions.pack(fill="x", padx=18, pady=12)
    app._action_button(actions, "Start Armor", start_agent, accent=True).pack(side="left", padx=(0, 5))
    app._action_button(actions, "Snapshot", lambda: command("network-snapshot")).pack(side="left", padx=5)
    app._action_button(actions, "Emergency Bypass", lambda: command("emergency-bypass")).pack(side="left", padx=5)
    app._action_button(actions, "Resume", lambda: command("resume-monitoring")).pack(side="left", padx=5)
    app._action_button(actions, "Refresh", refresh).pack(side="right")
    if beta_manager.load().get("enrolled"): beta_manager.record("journey-completed", {"name": "protection-review"})
    refresh()


def open_beta_center(app) -> None:
    theme = app.THEME
    window = app._window("Founding Beta Center", 780, 590)
    identity = Path(__file__).resolve().parents[2]
    current = beta_manager.load()
    privacy = tk.BooleanVar(value=bool(current.get("consent", {}).get("privacy_notice")))
    limitations = tk.BooleanVar(value=bool(current.get("consent", {}).get("limitations")))
    diagnostics = tk.BooleanVar(value=bool(current.get("consent", {}).get("local_diagnostics")))
    tk.Label(window, text="VOS Founding Beta", bg=theme["panel"], fg=theme["ink"], font=("Segoe UI", 15, "bold")).pack(anchor="w", padx=18, pady=(16, 4))
    tk.Label(window, text="Enrollment is local-first. Launch-ready is not the same as a validated live beta.", bg=theme["panel"], fg=theme["muted"]).pack(anchor="w", padx=18, pady=(0, 8))
    checks = tk.Frame(window, bg=theme["panel"]); checks.pack(fill="x", padx=18)
    tk.Checkbutton(checks, text="I accept the privacy notice", variable=privacy, bg=theme["panel"], fg=theme["ink"], activebackground=theme["panel"], activeforeground=theme["ink"], selectcolor=theme["surface"]).pack(anchor="w")
    tk.Checkbutton(checks, text="I understand the VPN, signing, and beta limitations", variable=limitations, bg=theme["panel"], fg=theme["ink"], activebackground=theme["panel"], activeforeground=theme["ink"], selectcolor=theme["surface"]).pack(anchor="w")
    tk.Checkbutton(checks, text="Keep local diagnostics (no automatic upload)", variable=diagnostics, bg=theme["panel"], fg=theme["ink"], activebackground=theme["panel"], activeforeground=theme["ink"], selectcolor=theme["surface"]).pack(anchor="w")
    status = tk.Text(window, height=16, bg=theme["surface"], fg=theme["ink"], relief="flat", padx=10, pady=10, font=("Consolas", 9))
    status.pack(fill="both", expand=True, padx=18, pady=10)

    def refresh() -> None:
        report = beta_manager.readiness()
        lines = [f"Launch ready: {report['launch_ready']}", f"Live beta validated: {report['beta_validated']}", f"Observed operating hours: {report['operating_hours']}", "", "Readiness gates:"]
        lines.extend(f"  [{'PASS' if value else 'OPEN'}] {key.replace('_', ' ')}" for key, value in report["gates"].items())
        lines.extend(["", "Missing user journeys:", *[f"  - {name}" for name in report["missing_journeys"]]])
        status.configure(state="normal"); status.delete("1.0", "end"); status.insert("1.0", "\n".join(lines)); status.configure(state="disabled")

    def enroll() -> None:
        try:
            beta_manager.enroll(privacy.get(), limitations.get(), diagnostics.get())
            messagebox.showinfo("Founding Beta", "This device is enrolled in the local founding beta."); refresh()
        except ValueError as error: messagebox.showerror("Founding Beta", str(error))

    def lifecycle(action: str, journey: str) -> None:
        manager = identity / "VOS Platform" / "lifecycle" / "vos_lifecycle.py"
        completed = subprocess.run([sys.executable, str(manager), action], capture_output=True, text=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if completed.returncode: messagebox.showerror("VOS Lifecycle", completed.stderr or completed.stdout); return
        if beta_manager.load().get("enrolled"): beta_manager.record("journey-completed", {"name": journey})
        app._show_output("VOS Lifecycle", completed.stdout); refresh()

    def self_test() -> None:
        test_script = identity / "VOS Platform" / "lifecycle" / "vos_self_test.py"
        completed = subprocess.run([sys.executable, str(test_script)], capture_output=True, text=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if beta_manager.load().get("enrolled"):
            beta_manager.record("self-test", {"passed": completed.returncode == 0})
        app._show_output("VOS Self-Test", completed.stdout or completed.stderr)
        refresh()

    def delete_data() -> None:
        if messagebox.askyesno("Founding Beta", "Delete local beta enrollment and telemetry?"):
            beta_manager.delete_local_data(); privacy.set(False); limitations.set(False); diagnostics.set(False); refresh()

    actions = tk.Frame(window, bg=theme["panel"]); actions.pack(fill="x", padx=18, pady=(0, 14))
    app._action_button(actions, "Enroll / Update", enroll, accent=True).pack(side="left", padx=(0, 5))
    app._action_button(actions, "Support Bundle", lambda: lifecycle("support-bundle", "support-bundle")).pack(side="left", padx=5)
    app._action_button(actions, "Backup", lambda: lifecycle("backup", "backup-recovery")).pack(side="left", padx=5)
    app._action_button(actions, "System Check", self_test).pack(side="left", padx=5)
    app._action_button(actions, "Delete My Data", delete_data).pack(side="right")
    refresh()
