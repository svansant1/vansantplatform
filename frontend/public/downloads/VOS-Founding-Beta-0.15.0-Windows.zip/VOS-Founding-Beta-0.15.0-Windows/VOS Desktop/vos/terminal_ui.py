"""Interactive PowerShell terminal hosted inside the VOS desktop."""

from __future__ import annotations

import os
import queue
import re
import shutil
import threading
import tkinter as tk
from pathlib import Path

try:
    from winpty import PtyProcess
except ImportError:
    PtyProcess = None


ANSI_OSC = re.compile(r"\x1b\].*?(?:\x07|\x1b\\)")
ANSI_CSI = re.compile(r"\x1b(?:\[[0-?]*[ -/]*[@-~]|[@-_])")


class InteractiveTerminal(tk.Frame):
    """A persistent Windows pseudo-terminal with a VOS-native interface."""

    def __init__(self, parent, theme: dict[str, str], cwd: Path | None = None):
        super().__init__(parent, bg=theme["panel"])
        self.theme = theme
        self.cwd = Path(cwd or Path.home())
        self.process = None
        self.history: list[str] = []
        self.history_index = 0
        self.output_queue: queue.Queue[str | None] = queue.Queue()
        self.reader_thread: threading.Thread | None = None
        self.resize_job = None
        self._closed = False

        toolbar = tk.Frame(self, bg=theme["panel"])
        toolbar.pack(fill="x", padx=12, pady=(10, 6))
        self.session_label = tk.Label(
            toolbar,
            text="PowerShell • starting",
            bg=theme["panel"],
            fg=theme.get("cyan", "#22d3ee"),
            font=("Segoe UI", 9, "bold"),
        )
        self.session_label.pack(side="left")
        tk.Label(
            toolbar,
            text="Commands run on this computer",
            bg=theme["panel"],
            fg=theme["muted"],
            font=("Segoe UI", 8),
        ).pack(side="left", padx=10)
        self._button(toolbar, "New session", self.start_session).pack(side="right", padx=(6, 0))
        self._button(toolbar, "Clear", self.clear).pack(side="right", padx=(6, 0))
        self._button(toolbar, "Stop command", self.interrupt).pack(side="right")

        terminal_body = tk.Frame(
            self,
            bg="#050814",
            highlightbackground="#253858",
            highlightthickness=1,
        )
        terminal_body.pack(fill="both", expand=True, padx=12, pady=(0, 8))
        scrollbar = tk.Scrollbar(terminal_body)
        scrollbar.pack(side="right", fill="y")
        self.output = tk.Text(
            terminal_body,
            bg="#050814",
            fg="#e5edf9",
            insertbackground="white",
            selectbackground="#334a70",
            relief="flat",
            wrap="word",
            font=("Cascadia Mono", 10),
            padx=10,
            pady=10,
            state="disabled",
            yscrollcommand=scrollbar.set,
        )
        self.output.pack(fill="both", expand=True)
        scrollbar.configure(command=self.output.yview)

        input_bar = tk.Frame(self, bg=theme["panel"])
        input_bar.pack(fill="x", padx=12, pady=(0, 12))
        tk.Label(
            input_bar,
            text="PS›",
            bg=theme["panel"],
            fg=theme.get("cyan", "#22d3ee"),
            font=("Cascadia Mono", 11, "bold"),
        ).pack(side="left", padx=(0, 8))
        self.entry = tk.Entry(
            input_bar,
            bg=theme["surface"],
            fg=theme["ink"],
            insertbackground="white",
            relief="flat",
            font=("Cascadia Mono", 11),
        )
        self.entry.pack(side="left", fill="x", expand=True, ipady=7)
        self._button(input_bar, "Run", self.send_command, accent=True).pack(side="right", padx=(8, 0))

        self.entry.bind("<Return>", self.send_command)
        self.entry.bind("<Up>", self._history_previous)
        self.entry.bind("<Down>", self._history_next)
        self.entry.bind("<Control-l>", lambda _event: self.clear())
        self.bind("<Configure>", self._schedule_terminal_resize)
        self.bind("<Destroy>", self._on_destroy)
        self.after(50, self._drain_output)
        self.start_session()
        self.after(150, self.entry.focus_force)

    def _button(self, parent, text: str, command, *, accent: bool = False) -> tk.Button:
        return tk.Button(
            parent,
            text=text,
            command=command,
            bg=self.theme["accent"] if accent else self.theme["taskbar_alt"],
            fg="white",
            activebackground="#7c3aed" if accent else "#334a70",
            activeforeground="white",
            relief="flat",
            cursor="hand2",
            padx=10,
            pady=5,
            font=("Segoe UI", 8, "bold"),
        )

    @staticmethod
    def _shell_command() -> list[str]:
        pwsh = shutil.which("pwsh.exe") or shutil.which("pwsh")
        if pwsh:
            return [
                pwsh,
                "-NoLogo",
                "-NoProfile",
                "-NoExit",
                "-Command",
                "$PSStyle.OutputRendering='PlainText'; "
                "Remove-Module PSReadLine -ErrorAction SilentlyContinue",
            ]
        powershell = shutil.which("powershell.exe") or "powershell.exe"
        return [
            powershell,
            "-NoLogo",
            "-NoProfile",
            "-NoExit",
            "-Command",
            "Remove-Module PSReadLine -ErrorAction SilentlyContinue",
        ]

    def start_session(self) -> None:
        self._stop_session()
        self.clear()
        if PtyProcess is None:
            self._append(
                "The interactive terminal component is missing.\n"
                "Run Install VOS.cmd again while connected to the internet.\n"
            )
            self.session_label.configure(text="PowerShell • unavailable", fg="#fb7185")
            return
        try:
            environment = dict(os.environ)
            environment["TERM"] = "dumb"
            environment["NO_COLOR"] = "1"
            self.process = PtyProcess.spawn(
                self._shell_command(),
                cwd=str(self.cwd),
                env=environment,
                dimensions=(24, 100),
            )
            self.session_label.configure(
                text="PowerShell • interactive",
                fg=self.theme.get("success", "#34d399"),
            )
            self.reader_thread = threading.Thread(target=self._read_session, daemon=True)
            self.reader_thread.start()
        except Exception as error:
            self.process = None
            self.session_label.configure(text="PowerShell • failed", fg="#fb7185")
            self._append(f"Could not start the PowerShell session: {error}\n")

    def _read_session(self) -> None:
        process = self.process
        while process and process.isalive() and not self._closed:
            try:
                chunk = process.read(4096)
            except (EOFError, OSError):
                break
            if chunk:
                self.output_queue.put(chunk)
        self.output_queue.put(None)

    def _drain_output(self) -> None:
        if self._closed or not self.winfo_exists():
            return
        while True:
            try:
                chunk = self.output_queue.get_nowait()
            except queue.Empty:
                break
            if chunk is None:
                if not self.process or not self.process.isalive():
                    self.session_label.configure(text="PowerShell • session ended", fg="#fbbf24")
                continue
            self._append(self._clean_terminal_text(chunk))
        self.after(35, self._drain_output)

    @staticmethod
    def _clean_terminal_text(text: str) -> str:
        text = ANSI_OSC.sub("", text)
        text = ANSI_CSI.sub("", text)
        return text.replace("\r\n", "\n").replace("\r", "").replace("\x00", "")

    def _append(self, text: str) -> None:
        if not text:
            return
        self.output.configure(state="normal")
        self.output.insert("end", text)
        self.output.see("end")
        self.output.configure(state="disabled")

    def send_command(self, _event=None):
        command = self.entry.get()
        if not command.strip():
            return "break"
        self.entry.delete(0, "end")
        if not self.process or not self.process.isalive():
            self.start_session()
        if not self.process or not self.process.isalive():
            return "break"
        self.history.append(command)
        self.history_index = len(self.history)
        try:
            self.process.write(command + "\r\n")
        except Exception as error:
            self._append(f"\nCould not send command: {error}\n")
        return "break"

    def interrupt(self) -> None:
        if self.process and self.process.isalive():
            try:
                self.process.sendcontrol("c")
            except Exception as error:
                self._append(f"\nCould not stop the command: {error}\n")

    def clear(self):
        self.output.configure(state="normal")
        self.output.delete("1.0", "end")
        self.output.configure(state="disabled")
        return "break"

    def _history_previous(self, _event=None):
        if self.history:
            self.history_index = max(0, self.history_index - 1)
            self._set_entry(self.history[self.history_index])
        return "break"

    def _history_next(self, _event=None):
        if self.history:
            self.history_index = min(len(self.history), self.history_index + 1)
            self._set_entry("" if self.history_index == len(self.history) else self.history[self.history_index])
        return "break"

    def _set_entry(self, value: str) -> None:
        self.entry.delete(0, "end")
        self.entry.insert(0, value)
        self.entry.icursor("end")

    def _schedule_terminal_resize(self, _event=None) -> None:
        if self.resize_job:
            self.after_cancel(self.resize_job)
        self.resize_job = self.after(80, self._resize_terminal)

    def _resize_terminal(self) -> None:
        self.resize_job = None
        if not self.process or not self.process.isalive():
            return
        columns = max(40, (self.output.winfo_width() - 20) // 8)
        rows = max(10, (self.output.winfo_height() - 20) // 18)
        try:
            self.process.setwinsize(rows, columns)
        except Exception:
            pass

    def _stop_session(self) -> None:
        process = self.process
        self.process = None
        if process:
            try:
                process.close(force=True)
            except Exception:
                pass

    def _on_destroy(self, event) -> None:
        if event.widget is self:
            self._closed = True
            self._stop_session()
