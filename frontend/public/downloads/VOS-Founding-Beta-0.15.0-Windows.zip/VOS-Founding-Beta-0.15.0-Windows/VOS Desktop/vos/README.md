# V.O.S - Vansant Operating System

VOS is an SVANS-AI-powered operating environment. It is not a bare-metal kernel yet. It is the first practical layer: a command platform that can manage files, run apps, execute SVANS-AI sentences, and call system tools.

VOS is still a work in progress. Each desktop pass is turning more pieces from prototype panels into real tools.

## Boot The Desktop

From the project root:

```powershell
python vos/desktop.py
```

Or use the launcher:

```powershell
.\run_vos_desktop.ps1
```

The desktop opens a VOS window with Files, Notepad, Calculator, Terminal, SVANS-AI Runner, Sandbox, Shield, Debugger, Projects, App Store, Settings, and the starter Hello App.

Desktop platform apps:

- `SVANS-AI Runner` runs one sentence at a time.
- `Notepad` creates, opens, saves, and stores documents under `vos/user/documents/`.
- `Sandbox` is an isolated workspace under `vos/user/sandbox/` with safe run, trusted run, new file, open file, save, save as, folder open, reset, and saved `.plain` files.
- `Shield` works like a VOS antivirus scanner: quick scan, text scan, file scan, folder scan, findings count, and quarantine review list.
- `Debugger` opens `.plain` files, checks them, shows generated Python, runs trusted code, diagnoses common errors, and runs VOS health checks.
- `Projects` lists all current examples, standard library files, and VOS apps in one place.

## Boot The Terminal

From the project root:

```powershell
python vos/vos.py
```

Run one command:

```powershell
python vos/vos.py --command "run Run 2+3"
```

## Commands

```text
help
about
time
date
where
scan
read <file>
write <file> <text>
open <target>
run <SVANS-AI sentence>
system <command>
app hello
exit
```

## Vision

VOS can grow in layers:

1. VOS shell and app launcher
2. VOS desktop with SVANS-AI UI commands
3. VOS package manager
4. VOS services, settings, and permissions
5. A bootable Linux-based distribution
6. A real hobby kernel, if you want to go that far

The current desktop is an operating environment hosted by Windows/Python. The app layer is where SVANS-AI owns the experience: VOS apps can be `.plain` programs, and the built-in SVANS-AI Runner, Sandbox, Shield, Debugger, and Projects tools make the language usable from one desktop.
