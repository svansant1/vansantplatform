"""Vansant OS internal window and external application host manager."""

from __future__ import annotations

import ctypes
import subprocess
import tkinter as tk
from ctypes import wintypes
from typing import Callable


user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32
WS_CHILD = 0x40000000
WS_CAPTION = 0x00C00000
WS_THICKFRAME = 0x00040000
WS_POPUP = 0x80000000
GWL_STYLE = -16
WM_CLOSE = 0x0010
TH32CS_SNAPPROCESS = 0x00000002


class PROCESSENTRY32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD), ("th32DefaultHeapID", ctypes.c_size_t),
        ("th32ModuleID", wintypes.DWORD), ("cntThreads", wintypes.DWORD),
        ("th32ParentProcessID", wintypes.DWORD), ("pcPriClassBase", wintypes.LONG),
        ("dwFlags", wintypes.DWORD), ("szExeFile", wintypes.WCHAR * 260),
    ]


def process_family(root_pid: int) -> set[int]:
    family = {root_pid}
    snapshot = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if snapshot == wintypes.HANDLE(-1).value:
        return family
    entry = PROCESSENTRY32W(); entry.dwSize = ctypes.sizeof(entry)
    parents: list[tuple[int, int]] = []
    if kernel32.Process32FirstW(snapshot, ctypes.byref(entry)):
        while True:
            parents.append((int(entry.th32ProcessID), int(entry.th32ParentProcessID)))
            if not kernel32.Process32NextW(snapshot, ctypes.byref(entry)):
                break
    kernel32.CloseHandle(snapshot)
    changed = True
    while changed:
        changed = False
        for pid, parent in parents:
            if parent in family and pid not in family:
                family.add(pid); changed = True
    return family


def visible_window_for_process(root_pid: int) -> int | None:
    family = process_family(root_pid)
    candidates: list[tuple[int, int]] = []
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    @callback_type
    def callback(hwnd, _lparam):
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if int(pid.value) not in family or not user32.IsWindowVisible(hwnd):
            return True
        length = user32.GetWindowTextLengthW(hwnd)
        if length <= 0:
            return True
        rect = wintypes.RECT(); user32.GetWindowRect(hwnd, ctypes.byref(rect))
        area = max(0, rect.right - rect.left) * max(0, rect.bottom - rect.top)
        candidates.append((area, int(hwnd)))
        return True

    user32.EnumWindows(callback, 0)
    return max(candidates, default=(0, 0))[1] or None


class ManagedWindow(tk.Frame):
    def __init__(self, manager: "WindowManager", key: str, title: str, width: int, height: int, *, external: bool = False, icon=None):
        super().__init__(
            manager.desktop, bg=manager.theme["panel"], highlightthickness=2,
            highlightbackground="#3b4f73",
        )
        self.manager = manager; self.key = key; self.window_title = title
        self.external = external; self.external_hwnd: int | None = None
        self.process: subprocess.Popen | None = None; self.minimized = False; self.maximized = False
        self.restore_bounds = (0, 0, width, height)
        x, y = manager.next_position(width, height)
        self.place(x=x, y=y, width=width, height=height)
        self.restore_bounds = (x, y, width, height)

        self.titlebar = tk.Frame(self, bg="#0d1a30", height=44, cursor="fleur")
        self.titlebar.pack(fill="x"); self.titlebar.pack_propagate(False)
        accent = tk.Frame(self.titlebar, bg=manager.theme.get("cyan", "#22d3ee"), width=3)
        accent.pack(side="left", fill="y")
        self.icon = icon
        self.title_label = tk.Label(
            self.titlebar, text=title, image=icon or "", compound="left",
            bg="#0d1a30", fg=manager.theme["ink"], font=("Segoe UI", 10, "bold"),
        )
        self.title_label.pack(side="left", padx=12)
        tk.Label(
            self.titlebar, text="VOS APP", bg="#0d1a30", fg=manager.theme["muted"],
            font=("Segoe UI", 7, "bold"),
        ).pack(side="left", padx=4)
        for text, command, color, hover in (
            ("×", self.close, "#0d1a30", "#b91c1c"),
            ("□", self.toggle_maximize, "#0d1a30", "#253858"),
            ("—", self.minimize, "#0d1a30", "#253858"),
        ):
            button = tk.Button(
                self.titlebar, text=text, command=command, bg=color, fg="#dce8ff",
                activebackground=hover, activeforeground="white", relief="flat",
                width=5, cursor="hand2", font=("Segoe UI", 10),
            )
            button.pack(side="right", fill="y")
        self._drag_origin = (0, 0, 0, 0)
        for widget in (self.titlebar, self.title_label):
            widget.bind("<ButtonPress-1>", self._start_drag); widget.bind("<B1-Motion>", self._drag); widget.bind("<Button-1>", lambda _e: self.focus_window(), add="+")
        self.bind("<Button-1>", lambda _e: self.focus_window(), add="+")
        self.resize_grip = tk.Label(self, text="◢", bg=manager.theme["panel"], fg=manager.theme["muted"], cursor="size_nw_se")
        self.resize_grip.place(relx=1, rely=1, anchor="se")
        self.resize_grip.bind("<ButtonPress-1>", self._start_resize); self.resize_grip.bind("<B1-Motion>", self._resize)
        self.task_button = manager.add_task(self)
        self.focus_window()

    def _start_drag(self, event) -> None:
        info = self.place_info(); self._drag_origin = (event.x_root, event.y_root, int(info.get("x", 0)), int(info.get("y", 0)))

    def _drag(self, event) -> None:
        if self.maximized: return
        ox, oy, x, y = self._drag_origin
        self.manager.place_clamped(self, x + event.x_root - ox, y + event.y_root - oy, self.winfo_width(), self.winfo_height())

    def _start_resize(self, event) -> None:
        self._resize_origin = (event.x_root, event.y_root, self.winfo_width(), self.winfo_height())

    def _resize(self, event) -> None:
        if self.maximized: return
        ox, oy, width, height = self._resize_origin
        info = self.place_info()
        self.manager.place_clamped(self, int(info.get("x", 0)), int(info.get("y", 0)), max(360, width + event.x_root - ox), max(220, height + event.y_root - oy))
        self.resize_external()

    def focus_window(self) -> None:
        if self.minimized:
            self.place(x=self.restore_bounds[0], y=self.restore_bounds[1], width=self.restore_bounds[2], height=self.restore_bounds[3]); self.minimized = False
        self.lift(); self.manager.set_active(self)
        if self.external_hwnd: user32.SetFocus(self.external_hwnd)

    def minimize(self) -> None:
        if not self.minimized:
            info = self.place_info(); self.restore_bounds = tuple(int(info.get(k, 0)) for k in ("x", "y", "width", "height"))
            self.place_forget(); self.minimized = True; self.manager.set_active(None)

    def toggle_maximize(self) -> None:
        if self.maximized:
            x, y, width, height = self.restore_bounds; self.place(x=x, y=y, width=width, height=height); self.maximized = False
        else:
            info = self.place_info(); self.restore_bounds = tuple(int(info.get(k, 0)) for k in ("x", "y", "width", "height"))
            self.place(x=0, y=0, width=max(600, self.manager.desktop.winfo_width()), height=max(400, self.manager.desktop.winfo_height())); self.maximized = True
        self.lift(); self.update_idletasks(); self.resize_external()

    def attach_process(self, process: subprocess.Popen) -> None:
        self.process = process; self.after(120, lambda: self._find_and_attach(0))

    def _find_and_attach(self, attempt: int) -> None:
        if not self.winfo_exists() or not self.process: return
        hwnd = visible_window_for_process(self.process.pid)
        if hwnd:
            self.external_hwnd = hwnd; self.update_idletasks()
            user32.SetParent(hwnd, self.winfo_id())
            style = user32.GetWindowLongW(hwnd, GWL_STYLE)
            user32.SetWindowLongW(hwnd, GWL_STYLE, (style | WS_CHILD) & ~WS_CAPTION & ~WS_THICKFRAME & ~WS_POPUP)
            self.resize_external(); self.bind("<Configure>", lambda _event: self.resize_external(), add="+")
            self.after(500, self._monitor_external); return
        if self.process.poll() is None and attempt < 150:
            self.after(100, lambda: self._find_and_attach(attempt + 1))
        else:
            self.manager.show_error(f"{self.window_title} did not provide a window that VOS could contain.")
            self.close()

    def resize_external(self) -> None:
        if self.external_hwnd and user32.IsWindow(self.external_hwnd):
            self.update_idletasks(); top = self.titlebar.winfo_height()
            user32.MoveWindow(self.external_hwnd, 0, top, max(1, self.winfo_width()), max(1, self.winfo_height() - top), True)

    def _monitor_external(self) -> None:
        if not self.winfo_exists(): return
        if self.external_hwnd and user32.IsWindow(self.external_hwnd): self.after(750, self._monitor_external)
        else: self.destroy()

    def close(self) -> None:
        if self.external_hwnd and user32.IsWindow(self.external_hwnd): user32.PostMessageW(self.external_hwnd, WM_CLOSE, 0, 0)
        self.destroy()

    def destroy(self) -> None:
        if getattr(self, "manager", None): self.manager.remove(self)
        super().destroy()


class WindowManager:
    def __init__(self, root: tk.Tk, desktop: tk.Widget, taskbar_apps: tk.Frame, theme: dict[str, str], show_error: Callable[[str], None]):
        self.root = root; self.desktop = desktop; self.taskbar_apps = taskbar_apps; self.theme = theme; self.show_error = show_error
        self.windows: dict[str, ManagedWindow] = {}; self.sequence = 0; self.active: ManagedWindow | None = None

    def next_position(self, width: int, height: int) -> tuple[int, int]:
        self.desktop.update_idletasks(); offset = (self.sequence % 8) * 24; self.sequence += 1
        max_x = max(0, self.desktop.winfo_width() - width); max_y = max(0, self.desktop.winfo_height() - height)
        return min(40 + offset, max_x), min(35 + offset, max_y)

    def place_clamped(self, window: ManagedWindow, x: int, y: int, width: int, height: int) -> None:
        max_width = max(360, self.desktop.winfo_width()); max_height = max(220, self.desktop.winfo_height())
        width = min(width, max_width); height = min(height, max_height)
        x = min(max(0, x), max(0, max_width - width)); y = min(max(0, y), max(0, max_height - height))
        window.place(x=x, y=y, width=width, height=height); window.update_idletasks(); window.resize_external()

    def create(self, key: str, title: str, width: int, height: int, *, external: bool = False, icon=None) -> ManagedWindow:
        existing = self.windows.get(key)
        if existing and existing.winfo_exists(): existing.destroy()
        self.desktop.update_idletasks()
        width = min(width, max(600, self.desktop.winfo_width()))
        height = min(height, max(400, self.desktop.winfo_height()))
        window = ManagedWindow(self, key, title, width, height, external=external, icon=icon); self.windows[key] = window
        return window

    def focus_key(self, key: str) -> bool:
        window = self.windows.get(key)
        if window and window.winfo_exists(): window.focus_window(); return True
        return False

    def add_task(self, window: ManagedWindow) -> tk.Button:
        button = tk.Button(
            self.taskbar_apps, text=window.window_title, image=window.icon or "",
            compound="left", command=window.focus_window,
            bg=self.theme["taskbar_alt"], fg=self.theme["ink"],
            activebackground="#334a70", activeforeground="white", relief="flat",
            padx=12, cursor="hand2", font=("Segoe UI", 9, "bold"),
        )
        button.pack(side="left", padx=3, pady=10); return button

    def set_active(self, window: ManagedWindow | None) -> None:
        self.active = window
        for item in self.windows.values():
            if hasattr(item, "task_button") and item.task_button.winfo_exists(): item.task_button.configure(bg=self.theme["accent"] if item is window else self.theme["taskbar_alt"])

    def remove(self, window: ManagedWindow) -> None:
        if self.windows.get(window.key) is window: self.windows.pop(window.key, None)
        if hasattr(window, "task_button") and window.task_button.winfo_exists(): window.task_button.destroy()
        if self.active is window: self.active = None

    def constrain_all(self) -> None:
        for window in list(self.windows.values()):
            if not window.winfo_exists() or window.minimized: continue
            if window.maximized:
                window.place(x=0, y=0, width=max(1, self.desktop.winfo_width()), height=max(1, self.desktop.winfo_height()))
                window.resize_external(); continue
            info = window.place_info()
            self.place_clamped(window, int(info.get("x", 0)), int(info.get("y", 0)), int(info.get("width", window.winfo_width())), int(info.get("height", window.winfo_height())))
