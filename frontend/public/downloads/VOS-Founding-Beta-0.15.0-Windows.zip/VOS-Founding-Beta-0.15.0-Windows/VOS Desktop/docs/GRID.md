# Plain Grid Architecture

Plain is designed as a sentence-based programming language and a routing layer between languages, tools, and systems.

The core idea is the grid:

```text
Plain sentence
    |
    v
Lexer and parser
    |
    v
Intent layer
    |
    v
Plain Grid runtime
    |
    +--> Native math
    +--> Python modules
    +--> Python programs
    +--> JavaScript / Node programs
    +--> PowerShell scripts
    +--> Shell commands
    +--> Files and folders
    +--> Future adapters: Rust, Java, C#, Go, APIs, databases
```

## Design Goal

Plain should let someone write:

```plain
Scan folder ".".
Import math.
Run math.sqrt(81).
Write "hello\n" to file "notes.txt".
```

and have those sentences become real computer actions.

## The Layers

**Sentence Layer**

This is what the user writes. It should feel like direct instructions, not symbolic code.

**Parser Layer**

The parser converts sentences into structured actions. Plain currently uses explicit phrase patterns. A later version can move to a formal grammar.

**Intent Layer**

The intent layer decides what the user is asking for:

- `Run` means calculate, call a module, or call another language
- `Import` means load a module
- `Scan` means inspect files
- `Open` means ask the operating system to open a target
- `Insert` means add to a list or add text to a file

**Grid Runtime**

The runtime routes intent to adapters. This is the power-grid idea: every language or tool is a power line, and Plain is the routing station.

**Adapters**

Adapters translate Plain values into another system's values:

- Plain text -> Python string
- Plain list -> Python list or JavaScript array
- Plain number -> Python, JavaScript, or shell argument
- Plain file path -> operating-system path

## Mastery Roadmap

1. Formal grammar
2. Better ambiguity rules
3. Stronger error messages
4. A real AST instead of direct line compilation
5. Adapter interface for new languages
6. Type bridge between Plain, Python, JavaScript, and future languages
7. Package system for adding vocabulary
8. Editor tooling and autocomplete
9. Tests for every phrase pattern
10. Documentation for safe and trusted modes

## Boundaries

Plain can access what the user, operating system, installed tools, accounts, and permissions allow. It should not bypass security systems, passwords, paywalls, or access controls.
