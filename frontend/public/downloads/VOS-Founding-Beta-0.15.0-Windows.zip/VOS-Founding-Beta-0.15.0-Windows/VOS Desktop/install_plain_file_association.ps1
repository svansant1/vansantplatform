$ProjectRoot = $PSScriptRoot
$Runner = Join-Path $ProjectRoot "run_plain_file.cmd"
$PlainPy = Join-Path $ProjectRoot "plain.py"

@"
@echo off
python "$PlainPy" run %1 --trusted
pause
"@ | Set-Content -Path $Runner -Encoding ASCII

New-Item -Path "HKCU:\Software\Classes\.plain" -Force | Out-Null
Set-ItemProperty -Path "HKCU:\Software\Classes\.plain" -Name "(default)" -Value "Svans.PlainFile"

New-Item -Path "HKCU:\Software\Classes\Svans.PlainFile" -Force | Out-Null
Set-ItemProperty -Path "HKCU:\Software\Classes\Svans.PlainFile" -Name "(default)" -Value "Svans Plain Program"

New-Item -Path "HKCU:\Software\Classes\Svans.PlainFile\shell\open\command" -Force | Out-Null
Set-ItemProperty -Path "HKCU:\Software\Classes\Svans.PlainFile\shell\open\command" -Name "(default)" -Value "`"$Runner`" `"%1`""

Write-Host ".plain files are now associated with Svans for the current Windows user."
Write-Host "Double-clicking a .plain file will run it in trusted mode and pause the window."
