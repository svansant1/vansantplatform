param(
    [string]$Do,
    [switch]$Trusted,
    [switch]$AllowSystem,
    [switch]$AllowImports,
    [switch]$Unsafe
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ArgsList = @()

if ($Do) {
    $ArgsList += "do"
    $ArgsList += $Do
} else {
    $ArgsList += "shell"
}

if ($Trusted) {
    $ArgsList += "--trusted"
}

if ($AllowSystem) {
    $ArgsList += "--allow-system"
}

if ($AllowImports) {
    $ArgsList += "--allow-imports"
}

if ($Unsafe) {
    $ArgsList += "--unsafe"
}

python (Join-Path $ScriptDir "plain.py") @ArgsList
