# Changelog

## Svans 2.0.0 - 2026-05-27

- Added desktop UI commands backed by tkinter: windows, labels, inputs, buttons, click handlers, and `Show window`.
- Added Flask-backed web app commands: create app, route handlers, send pages, and start server.
- Added object/type definitions with constructors and methods.
- Added stacks and queues.
- Added timers, file-watch events, background tasks, and parallel task blocks.
- Added built-in testing with `Test` and `Run all tests`.
- Added basic socket networking commands.
- Added package-manager CLI stubs: `svans install` and `svans publish`.
- Added a Plain standard library under `stdlib/`.
- Added Svans 2.0 example programs for UI, web, objects, data structures, events, background tasks, parallel tasks, testing, and networking.
- Updated package metadata to version 2.0.0 with optional `web`, `ui`, and `all` extras.

## Svans 1.0.0 - 2026-05-27

- Sentence-style programming with `Say`, `Remember`, `Run`, `If`, `Repeat`, `For each`, `While`, functions, and returns.
- One-room trusted shell with `Svans>` prompt.
- Python transpilation and direct `.plain` execution.
- Python, JavaScript/Node, Ruby, Perl, PHP, and PowerShell adapters.
- File, folder, shell command, web fetch, HTTP POST, SQLite database, and Claude adapters.
- Plain file imports with `Use "helpers.plain"`.
- Error handling with `Try` / `If it fails`.
- String formatting, math shortcuts, list operations, maps, date/time, type checks, input validation, JSON, and environment variables.
- CLI commands: `version`, `new`, `check`, `format`, `run`, `build`, `shell`, and `do`.
- Windows PowerShell profile helper and `.plain` file association scripts.
