# Plain

Plain is a tiny sentence-style programming language that translates into Python.
Its long-term goal is to become a simple phrase layer that can call other programming languages through clear, permissioned bridges.

Plain's larger architecture is the **Grid**: Plain reads sentence-like commands, understands the intent, then routes the work to adapters for Python, JavaScript, files, shell commands, modules, and future languages.

See [docs/GRID.md](docs/GRID.md) for the full architecture and mastery roadmap.

## Install

From this project folder:

```powershell
pip install -e .
```

After installation:

```powershell
svans version
svans shell --trusted
svans run examples/hello.plain
svans examples/language_features.plain
```

Install optional platform dependencies:

```powershell
pip install -e ".[all]"
```

Build for publishing:

```powershell
python -m build
python -m twine upload dist/*
```

The PyPI package name is `svans`, and the console command is `svans`.

It is designed to feel like writing short instructions:

```plain
Remember score as 10.
Add 5 to score.
Say score.
```

## Run It

```powershell
python plain.py run examples/hello.plain
```

CLI commands:

```powershell
python plain.py version
python plain.py new myproject
python plain.py check examples/hello.plain
python plain.py format examples/hello.plain
python plain.py install svans-web
python plain.py publish .
python plain.py run examples/hello.plain
python plain.py build examples/hello.plain -o hello.py
python plain.py shell --trusted
python plain.py do 'Run 2+3'
```

Start the interactive Svans platform:

```powershell
python plain.py shell
```

Then type sentence commands directly:

```plain
Say "hello Shawn".
Remember score as 10.
Add 5 to score.
Say score.
Show grid.
Show adapters.
Exit.
```

On PowerShell, you can also use the launcher:

```powershell
.\plain.ps1
```

If PowerShell blocks scripts on your computer, use `python plain.py shell` instead.

Run one Plain sentence directly from PowerShell:

```powershell
python plain.py do 'Run 2+3'
python plain.py do 'Read file "notes.txt"' --trusted
```

Or with the launcher:

```powershell
.\plain.ps1 -Do 'Run 2+3'
.\plain.ps1 -Trusted -Do 'Read file "notes.txt"'
```

If the `svans` PowerShell profile function is installed, you can start the trusted Svans platform from any folder:

```powershell
svans
```

Or run one trusted Plain sentence from any folder:

```powershell
svans 'Run 2+3'
svans 'Read file "notes.txt"'
```

Run a `.plain` file directly:

```powershell
svans examples/language_features.plain
```

Install Windows double-click support for `.plain` files:

```powershell
powershell -ExecutionPolicy Bypass -File .\install_plain_file_association.ps1
```

Remove it:

```powershell
powershell -ExecutionPolicy Bypass -File .\uninstall_plain_file_association.ps1
```

The older form still works:

```powershell
svans plain
svans plain 'Run 2+3'
svans plain examples/language_features.plain
```

Trusted mode turns on every Plain capability that can affect your machine:

```powershell
python plain.py shell --trusted
```

That is the same as using `--unsafe`, `--allow-imports`, and `--allow-system` together. Use it only for programs you trust.

Trusted shell is also one-room mode: at `Svans>`, Svans tries your sentence first. If it does not understand the line, it tries the line as a normal system command.

```plain
Run 2+3
Read file "notes.txt"
python --version
dir
```

Print the generated Python:

```powershell
python plain.py build examples/hello.plain
```

Write the generated Python to a `.py` file:

```powershell
python plain.py build examples/hello.plain -o hello_generated.py
python hello_generated.py
```

## What Plain Can Say

```plain
Help.
Show vocabulary.
Show grid.
Show adapters.
Say "hello".
Remember score as 10.
Remember 10 as score.
Set score to 20.
Run 2 + 3.
Run score * 2 and remember the answer as doubled score.
Remember name as "Shawn".
Remember greeting as "Hello " + name.
Remember total as length of colors.
Add 5 to score.
Subtract 2 from score.
Multiply score by 3.
Divide score by 2.
Remember score as 10 squared.
Remember root as square root of 81.
Remember rounded as round 3.7 to 2 places.
```

Formatting, maps, dates, JSON, and environment variables:

```plain
Remember name as "Shawn".
Remember greeting as "Hello {name}".
Remember person as empty map.
Set person "name" to "Shawn".
Remember saved_name as person "name".
Remember today as current date.
Remember now as current time.
Remember data as parse JSON from response.
Remember text as JSON from data.
Remember key as environment variable "API_KEY".
```

List operations:

```plain
Remember colors as ["red", "blue", "green"].
Remember first as first item in colors.
Remember last as last item in colors.
Remove "red" from colors.
Sort colors.
Reverse colors.
```

Type checks and validation:

```plain
If score is a number:
  Say "score is a number".
End.

Make sure age is a number.
```

Plain also has direct verbs for system-style work:

```plain
Import math.
Run math.sqrt(81).
Remember colors as empty list.
Insert "red" into colors.
Insert "green" into colors at position 0.
Scan folder ".".
Open "https://example.com".
Stop.
```

File access verbs:

```plain
Write "hello\n" to file "notes.txt".
Read file "notes.txt" and remember the content as notes.
Copy "notes.txt" to "backup.txt".
Move "backup.txt" to "archive.txt".
Delete file "archive.txt".
```

`Open`, `Scan`, external language calls, and `Run command` need system access:

```powershell
python plain.py shell --allow-system
```

or:

```powershell
python plain.py run examples/system_tools.plain --allow-system
```

Or use trusted mode:

```powershell
python plain.py run examples/trusted_access.plain --trusted
```

`Insert` can add values to lists without system access:

```plain
Remember colors as empty list.
Insert "red" into colors.
Insert "blue" into colors.
Say colors.
```

It can also insert text into files with system access:

```plain
Insert "hello\n" into file "notes.txt".
Insert "title\n" into file "notes.txt" at start.
```

Blocks use two-space indentation and end with `End.`

```plain
Repeat 3 times:
  Say "again"
End.

For each color in colors:
  Say color.
End.

While score is less than 100:
  Add 10 to score.
End.

If score is greater than 5:
  Say "big"
Otherwise:
  Say "small"
End.

If "red" is in colors:
  Say "found red"
End.
```

Functions are simple:

```plain
Define greet using name:
  Return "Hello " + name.
End.

Remember message as greet("Shawn").
Say message.
```

## Python Bridge

Plain can integrate with regular Python one line at a time:

```plain
Remember number as 9.
Use Python: root = round(number ** 0.5, 2)
Say root.
```

By default, this bridge blocks imports, file access, system commands, and similar escape hatches. That is intentional: a language should respect the operating system, accounts, permissions, and security boundaries around it.

For your own local experiments, `python plain.py run file.plain --unsafe` gives the generated Python normal Python builtins. Only use that with Plain programs you trust.

## Imports

Plain has phrase-based imports, so you do not need to write raw Python imports:

```plain
Use module "math".
Run math.sqrt(81).

Use module "random" as rng.
Run rng.randint(1, 10) and remember the answer as lucky number.
Say lucky_number.
```

These shorter forms also work:

```plain
Import math.
Use random as rng.
Run rng.randint(1, 10).
```

Run the example:

```powershell
python plain.py run examples/imports.plain
```

Plain allows common safe standard-library modules by default, including `math`, `random`, `datetime`, `json`, `statistics`, `re`, `csv`, and a few others.

For trusted local experiments with any installed Python module:

```powershell
python plain.py shell --allow-imports
```

Then:

```plain
Use module "your_package".
```

Use `--allow-imports` only with Plain programs you trust, because Python packages can run code when imported.

## Talking To Other Languages

Plain can communicate with other languages by running installed interpreters and capturing their output.

```plain
Run Python "print(6 * 7)" and remember output as python answer.
Say python_answer.

Run JavaScript "console.log(10 + 5)" and remember output as javascript answer.
Say javascript_answer.

Run PowerShell "Write-Output 42" and remember output as powershell answer.
Say powershell_answer.
```

Those commands need system access because they start external programs:

```powershell
python plain.py run examples/interoperability.plain --allow-system
```

Plain currently has built-in runners for:

- Python
- JavaScript / Node
- Ruby
- Perl
- PHP
- PowerShell

## Error Handling

```plain
Try:
  Read file "data.txt" and remember it as content.
If it fails:
  Say "File not found".
End.
```

## Plain File Imports

```plain
Use "helpers.plain".

Remember message as shout("hello").
Say message.
```

Run:

```powershell
svans examples/package_import.plain
```

## Web And Database Adapters

```plain
Fetch "https://example.com" and remember response as page.
Post to "https://api.example.com" with body data and remember response as result.

Connect to database "myapp.db".
Ask database "SELECT * FROM users" and remember rows as users.
Say users.
```

These need trusted/system access:

```powershell
svans examples/web_database.plain
```

## Claude Adapter

Svans can ask Claude if `ANTHROPIC_API_KEY` is set in your environment:

```plain
Ask Claude "what is the capital of France?" and remember answer as result.
Say result.
```

You can pass context too:

```plain
Ask Claude "turn this list into a summary" using items and remember answer as summary.
```

Run:

```powershell
svans examples/claude.plain
```

Focused help:

```plain
Help Say.
Help Ask Claude.
Help Fetch.
```

## Example Programs

- `examples/web_scraper.plain`
- `examples/todo_app.plain`
- `examples/ai_assistant.plain`
- `examples/file_organizer.plain`
- `examples/daily_news.plain`
- `examples/prepublish_features.plain`

## Application Platform Features

Desktop UI:

```plain
Create window "My App".
Add label "Welcome" to window.
Add input "Enter name" to window as name_field.
Add button "Click me" to window.
When button is clicked:
  Say "Hello!".
End.
Show window.
```

Web apps:

```plain
Create web app "My Site".
When someone visits "/":
  Send page "Hello World".
End.
Start web app on port 8080.
```

Objects:

```plain
Define type Person using name, age:
  Define greet using nothing:
    Return "Hi I am {name}".
  End.
End.

Remember shawn as new Person "Shawn" 35.
Say shawn greet.
```

Stacks and queues:

```plain
Remember stack as empty stack.
Push "item" onto stack.
Pop from stack and remember it as item.

Remember queue as empty queue.
Enqueue "item" into queue.
Dequeue from queue and remember it as item.
```

Events, background, and parallel work:

```plain
Every 5 seconds:
  Say "Still running".
End.

In the background:
  Fetch "https://example.com" and remember response as data.
End.
Wait for background tasks.

Run in parallel:
  Task one:
    Say "doing thing one".
  End.
  Task two:
    Say "doing thing two".
  End.
End.
```

Testing:

```plain
Test "score starts at zero":
  Remember score as 0.
  Make sure score equals 0.
End.

Run all tests.
```

Standard library files live in `stdlib/`:

- `stdlib/strings.plain`
- `stdlib/lists.plain`
- `stdlib/math.plain`
- `stdlib/files.plain`
- `stdlib/time.plain`

## V.O.S - Vansant Operating System

VOS is an SVANS-AI-powered operating environment included in `vos/`.

VOS is still a work in progress. It runs as a Windows/Python-hosted desktop environment while the SVANS-AI app layer becomes more complete.

Boot the VOS desktop:

```powershell
python vos/desktop.py
```

Or:

```powershell
.\run_vos_desktop.ps1
```

Boot it:

```powershell
python vos/vos.py
```

Run one VOS command:

```powershell
python vos/vos.py --command "run Run 2+3"
```

Run the starter VOS app:

```powershell
python vos/vos.py --command "app hello"
```

The desktop includes Files, Notepad, Calculator, Terminal, SVANS-AI Runner, Sandbox, Shield, Debugger, Projects, App Store, Settings, and Hello App. VOS is currently an operating environment on top of Windows/Python. It can grow toward a deeper desktop shell, package system, services, and eventually a bootable OS distribution.

The desktop platform tools are:

- `SVANS-AI Runner` for one sentence at a time.
- `Notepad` for creating, opening, saving, and storing documents under `vos/user/documents/`.
- `Sandbox` for isolated safe/trusted experiments in `vos/user/sandbox/`, with new/open/save/save as/folder controls.
- `Shield` as an antivirus-style scanner with quick scan, folder scan, findings, and quarantine review.
- `Debugger` for `.plain` files, generated Python, common error diagnosis, and VOS health checks.
- `Projects` for browsing examples, standard library files, and VOS apps from one place.

You can also call an installed command directly:

```plain
Run command "python --version" and remember output as python version.
Say python_version.
```

This is how Plain can grow toward communicating with many languages: not by replacing them, but by becoming a readable control layer over them.

## Philosophy

Plain can become more powerful by adding capabilities deliberately:

- file commands like `Read file "notes.txt" into notes`
- web commands like `Get "https://example.com" and remember it as page`
- package commands that call approved Python libraries
- an LLM-assisted mode that translates flexible human requests into Plain or Python
- language bridges that call Java, C#, Go, Rust, C/C++, or other installed tools

The key is permissioned power: Plain can automate your computer, but it should not bypass protections, credentials, paywalls, access controls, or other people’s systems.

## Mastery Roadmap

To become a serious language, Plain needs:

- a formal grammar for sentence patterns
- an AST instead of direct line-by-line compilation
- ambiguity rules for unclear sentences
- a standard vocabulary for data, files, APIs, apps, and language bridges
- adapter interfaces for Python, JavaScript, Rust, Java, C#, Go, databases, and web APIs
- type bridging so Plain values can move between languages
- plain-English error messages
- a package/module system for extending the vocabulary
- an editor/LSP layer for autocomplete
- tests for every phrase pattern
