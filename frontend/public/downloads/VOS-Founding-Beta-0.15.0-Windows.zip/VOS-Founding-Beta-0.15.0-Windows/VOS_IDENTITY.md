# VOS Identity

This workspace is the canonical development home for the Vansant Operating System.

## Product roles

- **VOS Desktop** — the operating environment and command center.
- **VOS Guardian Core** — the trusted background service and shared evidence layer.
- **SVANSAI Guide** — the intelligence, explanation, coordination, and recovery guide.
- **SVANSAI Debugger / VOS Device Guide** — evidence-based device, app, network, file, and site diagnostics.
- **SVANS Shield / VOS File Armor** — file inspection, quarantine, restoration, and future endpoint protection.
- **SV Browser / VOS Web Armor** — protected browsing, web diagnostics, privacy, and safe downloads.
- **VOS Sandbox Armor** — isolated building, execution, testing, and investigation.

The established product brands remain visible while their VOS roles define how they work together.

## Canonical module folders

- `VOS Platform/vos_desktop_shell`
- `VOS Platform/vos_desktop_host`
- `VOS Platform/guardian_core`
- `VOS Platform/svansai_guide`
- `VOS Platform/debugger_guide`
- `VOS Platform/file_armor`
- `VOS Platform/sandbox_armor`
- `SV Browser`
- `VOS Desktop`

Archived code is kept under names ending in `_legacy` and is not part of the active runtime.

## Operational roadmap

Use `VOS_OPERATIONAL_PHASES.md` to build VOS in runnable stages. Each phase ends with an operational milestone before the next integration begins.

## Current operational foundation

The first three requested implementation phases are built:

- The canonical workspace identity is defined by `vos_identity.json` and `config/modules.json`.
- VOS Desktop 0.15.0 is the command center and includes contained application windows, running-app taskbar management, an attached Start menu, actual project icons, file creation, a functional local App Store, Guardian Center, Incident Center, Network Armor, Founding Beta Center, one-click system checks, and local crash capture.
- Guardian Core 0.13.1 provides authenticated health, seven-module coordination, evidence, incident correlation, and safe action routing.
- Network Armor 0.13.1 provides consent-gated firewall, DNS, and connection-process posture monitoring with single-instance startup. It truthfully reports that no VPN tunnel is configured.
- Lifecycle 0.13.1 provides release integrity, self-testing, backup/recovery, redacted support bundles, and an unsigned-update deny policy.
- VOS Module SDK 0.4.0 defines the shared Guide/Armor contracts.
- SVANSAI Guide and SVANSAI Debugger are connected modules with live heartbeats, evidence, and command handling.
- SVANS Shield, SV Browser, and VOS Sandbox are connected Armors with privacy-bounded evidence and command handling.

Start the integrated system with `Start VOS.cmd`. VOS Desktop automatically starts or reconnects to Guardian Core.
